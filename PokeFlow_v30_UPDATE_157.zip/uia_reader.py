"""Reads FansMetric's fan list straight from Windows' accessibility tree (no screenshots, no text recognition).

FansMetric is a Chromium app; Windows UI Automation exposes its page text with exact screen rectangles.
Probe on the user's PC: ~1200 elements, ids like '@u5625284' with positions. This module turns that into
badge positions. Everything is in physical screen pixels.
"""
from __future__ import annotations

import re
import time

_ID = re.compile(r"@([A-Za-z0-9][A-Za-z0-9_.\-]{2,40})\s*$")
_PROFILE_LINK = re.compile(r"^https?://(?:www\.)?onlyfans\.com/(?!my/)(?!api)([A-Za-z0-9_.\-]{2,40})/?$", re.I)
_TAB = re.compile(r"^(all|active|expired|restricted|blocked|fan stats)\b", re.I)


def parse(elements, window_rect):
    """elements: [(name, left, top, right, bottom)], window_rect: (l, t, r, b).
    Returns {'cards': [{'id','x','cy','h'}], 'clip_top', 'bottom', 'band': (l, r)} for the FANS panel, or None."""
    wl, wt, wr, wb = window_rect
    els = [(str(n or "").strip(), l, t, r, b) for n, l, t, r, b in elements if r > l and b > t]

    def header(name):
        return [e for e in els if e[0].lower() == name and wt <= e[2] < wt + 400]
    fans = sorted(header("fans"), key=lambda e: e[2])             # smallest top = the FANS header (not the 'Fans' collection entry)
    if not fans:
        return None
    hdr = fans[0]
    left = hdr[1] - 16
    right = wr
    notif = [e for e in header("notifications") if e[1] > left + 200]
    if notif:
        right = min(e[1] for e in notif) - 60
    tabs = [e for e in els if _TAB.match(e[0]) and left <= e[1] <= right and abs(e[2] - hdr[2]) < 260]
    clip_top = (max(e[4] for e in tabs) + 6) if tabs else (hdr[4] + 150)
    bottom = wb - 4
    cards, seen = [], set()
    for name, l, t, r, b in els:
        m = _ID.search(name)
        if not m:
            continue
        pid = m.group(1).lower()
        if pid in seen:
            continue
        if l < left or r > right + 4 or b < clip_top - 60 or t > bottom + 60:
            continue                                   # other panel, or far outside what is on screen
        seen.add(pid)
        cards.append({"id": pid, "x": r + 10, "cy": (t + b) / 2.0, "h": float(b - t), "rect": (l, t, r, b)})
    cards.sort(key=lambda c: (c["cy"], c["x"]))
    notifs, nseen = [], set()
    if notif:
        nh = sorted(notif, key=lambda e: e[2])[0]
        nl = nh[1] - 30
        for name, l, t, r, b in els:
            m = _ID.search(name)
            if not m or l < nl or t < nh[4] - 4 or b > wb + 4 or t < wt:
                continue                               # only what is really on screen in the NOTIFICATIONS column
            pid = m.group(1).lower()
            if pid in nseen:
                continue
            nseen.add(pid)
            notifs.append({"id": pid, "cy": (t + b) / 2.0, "rect": (l, t, r, b)})
        notifs.sort(key=lambda c: c["cy"])
    return {"cards": cards, "clip_top": clip_top, "bottom": bottom, "band": (left + 4, right), "notifs": notifs}


def resolve_card(items, x, y):
    """items: [(l, t, r, b, name)] of everything below the list pane. Returns (id, (l, t, r, b)) of the FANS card under the
    point (a 250-450 wide, 200+ high box that contains exactly one @id) - worked out in memory, no hit-testing needed."""
    cands = []
    for l, t, r, b, _n in items:
        w, h = r - l, b - t
        if 250 <= w <= 450 and h >= 200 and l <= x <= r and t <= y <= b:
            cands.append((w * h, l, t, r, b))
    cands.sort()
    idrects = []
    for l, t, r, b, n in items:
        m = _ID.search(str(n or ""))
        if m:
            idrects.append((m.group(1).lower(), l, t, r, b))
    for _a, l, t, r, b in cands[:12]:
        ids = set(pid for pid, il, it, ir, ib in idrects if il >= l - 2 and ir <= r + 2 and it >= t - 2 and ib <= b + 2)
        if len(ids) == 1:
            return next(iter(ids)), (l, t, r, b)
        if len(ids) > 1:
            return None
    return None



_REPLY_HEAD_RX = re.compile(r",\s*(?:today|yesterday|(?:mon|tue|wed|thu|fri|sat|sun)\w*|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\.?\s*\d{1,2})\b", re.I)
_HEAD_TIME_RX = re.compile(r"^(?:today|yesterday|(?:mon|tue|wed|thu|fri|sat|sun)\w*|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\.?\s*\d{1,2}(?:,\s*\d{4})?)\s+\d{1,2}:\d{2}", re.I)
_STAMP_RX = re.compile(r"^\s*\d{1,2}:\d{2}\s*(?:a\.?m\.?|p\.?m\.?)?\s*$", re.I)
_SKIP_RX = re.compile(r"^\s*(?:split window|play video|\d+\s*/\s*\d+|\$\s*\d[\d.,]*\s*(?:paid|not paid yet)?\s*,?|fansmetric ai|bump message|mark as (?:un)?read|copy|reply|delete|pin|unpin|today|yesterday|tags|•|type a message\.*|view message|new|paid|not paid yet|"
                      r"(?:mon|tue|wed|thu|fri|sat|sun)\w*|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\.? \d{1,2}(?:, \d{4})?)\s*$", re.I)


def chat_messages(texts, title, box):
    """The chat's bubbles, oldest first: [{'side': 'fan'|'me', 'text', 'top'}]. FansMetric shows HIS messages on the left
    (next to his avatar), the creator's on the right. Scrolled-up messages are still in the tree, so this sees more than
    the screen. Times, sender names, tag rows and avatar initials are left out."""
    tl, tt, tr, tb = title
    if box:
        cl, cr, bottom = box[0], box[2], box[1]
    else:
        cl, cr, bottom = tl - 50, tl + 600, 10 ** 6
    width = max(200, cr - cl)
    rows = [(r, t) for r, t in texts if cl - 10 <= r[0] and r[2] <= cr + 10 and r[3] <= bottom and not (tt - 40 <= r[1] <= tb + 30)]
    stamps = [r for r, t in rows if _STAMP_RX.match(t)]
    tag_rows = [r[1] for r, t in rows if t.strip().lower() == "tags"]
    head_rows = [r[1] for r, t in rows if _REPLY_HEAD_RX.search(t) or _HEAD_TIME_RX.match(t.strip())]
    items = []
    for r, t in rows:
        txt = t.strip()
        if not txt or _STAMP_RX.match(txt) or _SKIP_RX.match(txt) or re.fullmatch(r"[\s\d.,/\u2022:;!?()\-\u00a0]*", txt):
            continue
        if any(abs(r[1] - s[1]) <= 4 and r[0] >= s[2] - 2 for s in stamps):
            continue                                                  # 'Nemanja Jovasevic' next to the time = sender name
        if any(abs(r[1] - y) <= 5 for y in tag_rows):
            continue                                                  # 'Tags • Kamryn' row of a mass message
        if len(txt) <= 3 and r[0] < cl + 60:
            continue                                                  # avatar initials
        if txt[:1] in '\u201c\u201d"' or _REPLY_HEAD_RX.search(txt) or any(abs(r[1] - y) <= 4 for y in head_rows):
            continue                                                  # reply-to block: 'Hope, Today 4:30 pm' + quote of an older message
        side = "fan" if (r[0] - cl) < 0.18 * width else "me"
        items.append({"side": side, "text": t, "rect": r})
    items.sort(key=lambda i: (i["rect"][1], i["rect"][0]))
    lines = []                                                        # pieces on one line ('I can't believe what ' '@miley' ...)
    for it in items:
        if lines and lines[-1]["side"] == it["side"] and lines[-1]["rect"][1] - 4 <= it["rect"][1] < lines[-1]["rect"][3] - 4:
            l = lines[-1]
            l["text"] = (l["text"] + it["text"]) if it["rect"][0] >= l["rect"][0] else (it["text"] + l["text"])
            l["rect"] = (min(l["rect"][0], it["rect"][0]), l["rect"][1], max(l["rect"][2], it["rect"][2]), max(l["rect"][3], it["rect"][3]))
        else:
            lines.append(dict(it))
    out = []
    for ln in lines:                                                  # lines of one bubble -> one message
        prev = out[-1] if out else None
        if prev and prev["side"] == ln["side"] and 0 <= ln["rect"][1] - prev["bottom"] <= 12 \
                and not any(prev["bottom"] - 2 <= s[1] <= ln["rect"][1] + 2 for s in stamps):
            prev["text"] = prev["text"].rstrip() + " " + ln["text"].strip()
            prev["bottom"] = ln["rect"][3]
        else:
            out.append({"side": ln["side"], "text": ln["text"].strip(), "top": ln["rect"][1], "bottom": ln["rect"][3]})
    return [{"side": m["side"], "text": " ".join(m["text"].split()), "top": m["top"]} for m in out if m["text"].strip()]


_ALERT_RX = re.compile(r"\bbanned\b|\b(?:3|three)\s*-?\s*seconds?\b", re.I)


def read_alerts(alerts, texts):
    """FansMetric's red warnings near the message box, read as text:
    banned = the line with 'Banned: ...' (its row is joined, the words can be separate pieces), three_sec = the
    'wait 3 seconds' block is showing."""
    banned, three, three_list = "", False, []
    for r, t in alerts:
        if re.search(r"(?:3|three)\s*-?\s*seconds?", t, re.I):
            three = True
            three_list.append(t.strip()[:120])
        if re.search(r"\bbanned\b", t, re.I) and not banned:
            row = sorted([(rr, tt) for rr, tt in texts if abs(rr[1] - r[1]) <= 4 and rr[0] >= r[0] - 2], key=lambda x: x[0][0])
            joined = "".join(tt for rr, tt in row) if row else t
            banned = joined if len(joined) >= len(t) else t
    return {"banned": banned.strip(), "three_sec": three, "three_list": three_list}


_SUB_RX = re.compile(
    r"subscribed to your|suscri(?:t[oa]s?|bió|bio|be)|inscrit|inscreveu|assinou|abonn|abone|iscritt|geabonneerd|"   # EN ES PT FR DE IT TR NL
    r"subskryb|zasubskryb|подписал|підписав|абонира|předplat|predplat|feliratkozott|pretplat|"               # PL RU UA BG CZ SK HU SR/HR
    r"prenumer|abonnere|abonnerte|tilas|εγγράφ|συνδρομ|נרשם|اشترك|اشتراك|सदस्यता|"                              # SE DK/NO FI GR HE AR HI
    r"đăng ký|đã đăng ký|สมัคร|berlangganan|melanggan|nag-subscribe|"                                         # VI TH ID MY TL
    r"订阅|訂閱|购阅|購読|登録しました|구독",                                                                      # ZH (both) JA KO
    re.I)
_AGO_RX = re.compile(r"\b(a few seconds|seconds|(?:\d+|an?)\s+(?:second|minute|hour|day|week|month|year)s?)\s+ago\b|"
                     r"^\s*(just now|now|moments? ago|less than a minute ago)\s*$", re.I)
_UNIT_S = {"second": 1, "minute": 60, "hour": 3600, "day": 86400, "week": 604800, "month": 2592000, "year": 31536000}


def ago_seconds(text):
    """'2 minutes ago' -> 120, 'a few seconds ago' -> 10, 'an hour ago' -> 3600; None if there is no '... ago'."""
    m = _AGO_RX.search(text or "")
    if not m:
        return None
    t = (m.group(1) or m.group(2) or "").lower()
    if t == "seconds" or "few seconds" in t or "now" in t or "moment" in t or "less than" in t:
        return 10
    n, unit = t.split()[0], re.sub(r"s$", "", t.split()[1])
    return (1 if n in ("a", "an") else int(n)) * _UNIT_S[unit]


_CT_SHORT = {50020: "T", 50005: "L", 50004: "Edit", 50000: "Btn", 50006: "Img", 50026: "Grp", 50007: "LI"}


def notif_cards(items):
    """Cards of FansMetric's NOTIFICATIONS panel. items = [(rect, controltype, name, element)] of that panel.
    Each card starts at the fan's @username link; returns [{'id', 'name', 'sub', 'replied', 'ago', 'edit', 'send', 'top'}]:
    sub = 'subscribed to your profile!' (other languages too), replied = 'Reply sent by ...' is shown,
    edit / send = the card's own 'Send a quick reply...' box and Send button."""
    ids = sorted([it for it in items if it[1] == 50005 and re.fullmatch(r"@[A-Za-z0-9_.\-]{2,40}", (it[2] or "").strip())],
                 key=lambda it: it[0][1])
    out = []
    pos = {id(it): n for n, it in enumerate(items)}
    for k, idl in enumerate(ids):
        y0 = idl[0][1] - 8
        y1 = ids[k + 1][0][1] - 8 if k + 1 < len(ids) else y0 + 260
        reg = [it for it in items if y0 <= it[0][1] < y1]
        texts = [(it[2] or "").strip() for it in reg if it[1] == 50020]
        left = [it for it in reg if it[1] == 50005 and abs(it[0][1] - idl[0][1]) <= 5 and it[0][0] < idl[0][0]
                and not (it[2] or "").startswith("@")]
        name = ""
        n0 = pos.get(id(idl))
        if n0 is not None:                                # FansMetric's own order: the name link comes right before @id
            for it in reversed(items[max(0, n0 - 8):n0]):  # (screen position lies when the card slides under the header)
                if it[1] == 50005 and (it[2] or "").strip() and not (it[2] or "").startswith("@") \
                        and abs(it[0][1] - idl[0][1]) <= 30:
                    name = it[2]
                    break
        if not name and left:
            name = max(left, key=lambda it: it[0][0])[2]  # the link right before @id (not the avatar)
        ago_it = next((it for it in reg if it[1] == 50020 and _AGO_RX.search((it[2] or "").strip())), None)
        edits = [it for it in reg if it[1] == 50004]
        edit = next((it for it in edits if "quick reply" in (it[2] or "").lower()), None) or (edits[0] if edits else None)
        sends = [it for it in reg if it[1] == 50000 and (it[2] or "").strip().lower() == "send"]   # only the real Send
        nlink = max(left, key=lambda it: it[0][0]) if left else idl
        chats = [it for it in reg if it[1] == 50005 and not (it[2] or "").strip() and it[0][0] > nlink[0][0] + 100
                 and 0 < it[0][2] - it[0][0] <= 44 and 0 < it[0][3] - it[0][1] <= 44]          # the little message icon
        out.append({
            "id": idl[2].strip()[1:], "name": (name or "").strip(), "top": idl[0][1], "id_el": idl[3], "y_end": y1,
            "sub": any(_SUB_RX.search(t) for t in texts),
            "line": " | ".join(t for t in texts if t and not _AGO_RX.search(t) and not t.startswith("@") and t != (name or "").strip())[:120],
            "replied": any(t.lower().startswith("reply sent") for t in texts),
            "ago": ago_seconds(ago_it[2]) if ago_it else None,
            "ago_rect": ago_it[0] if ago_it else None,
            "ago_el": ago_it[3] if ago_it else None,
            "edit": edit[3] if edit else None,
            "send": sends[0][3] if sends else None,
            "chat": chats[-1][3] if chats else None,
            "dump": ("BOXES/BUTTONS: " + ", ".join(f"{_CT_SHORT.get(it[1], it[1])}:{(it[2] or '')[:20]!r}@{it[0][0]},{it[0][1]}"
                                               for it in reg if it[1] in (50004, 50000)) +
                     " | ALL: " + "; ".join(f"{_CT_SHORT.get(it[1], it[1])}:{(it[2] or '')[:18]}" for it in reg))[:700],
        })
    return out


def panel_chat_parse(items, doc_rect):
    """items = [(rect, controltype, name, class, enabled, element)] of the panel page (visible only)."""
    L, T, R, B = doc_rect
    items = [(r, ct, nm or "", cl or "", en, e) for r, ct, nm, cl, en, e in items]
    edits = [it for it in items if (it[1] == 50004 or re.search(r"text-editor|textarea|tiptap|ProseMirror", it[3], re.I)
             or re.match(r"type a message|textbox field", it[2], re.I)) and not re.search(r"search|quick reply", it[2], re.I)]
    edit = max(edits, key=lambda it: it[0][1]) if edits else None
    btns = [it for it in items if it[1] == 50000]
    sends = [it for it in btns if it[2].lower() == "send" or re.search(r"send", it[3], re.I)]
    if edit is not None and sends:
        sends.sort(key=lambda it: abs(it[0][1] - edit[0][1]))
    tops = [it for it in btns if it[0][1] < T + 70 and it[0][0] < L + 90 and not it[2]]   # the <- arrow left of his name
    back = min(tops, key=lambda it: it[0][0]) if tops else None
    texts = [it[2] for it in items if it[1] == 50020 and it[2]]
    dump = "; ".join(f"{_CT_SHORT.get(it[1], it[1])}:{it[2][:22]!r}{'' if it[4] else '(off)'}"
                     f"[{it[3][:24]}]@{it[0][0]},{it[0][1]}" for it in items if it[1] in (50004, 50000, 50005, 50030))
    return {"edit": edit[5] if edit else None, "send": sends[0][5] if sends else None,
            "send_on": sends[0][4] if sends else False, "back": back[5] if back else None,
            "texts": texts, "dump": dump[:1500]}


_CHAT_LINK = re.compile(r"onlyfans\.com/my/chats/chat/(\d{3,15})(?:[/?#]|$)", re.I)


def title_fallback(t, links, chatlinks):
    """The chat header has no profile link (FansMetric's narrower layout). Who is it then:
    1) his avatar links next to his messages carry exactly the title's name -> their profile link (@id / custom name);
    2) else the header's Gallery / pinned links: /my/chats/chat/405427577/ -> 'u405427577'."""
    tl, tt, tr, tb = t["rect"]
    nm = re.sub(r"\s+Edit\s*$", "", (t.get("text") or "").strip()).strip()
    if nm:
        same = [l for l in links if l["name"].strip() == nm and tl - 120 <= l["rect"][0] < tr]   # in THIS chat, not the list
        ids = {l["id"].lower() for l in same}
        if len(ids) == 1:
            return {"name": nm, "id": same[0]["id"], "rect": same[0]["rect"], "how": "avatar"}
    near = [c for c in chatlinks if tb - 4 <= c["rect"][1] <= tb + 40 and tl - 40 <= c["rect"][0] <= tr + 40]
    nums = {c["num"] for c in near}
    if len(nums) == 1 and nm:
        return {"name": nm, "id": "u" + nums.pop(), "rect": t["rect"], "how": "chat number"}
    return None


_REL_UNITS = {"second": 1, "minute": 60, "hour": 3600, "day": 86400, "week": 604800, "month": 2592000, "year": 31536000}


def parse_last_spend(s):
    """'$35.00 (a month ago)' / '$3.00 (7 days ago)' -> {'amount': 35.0, 'ago': seconds, 'res': seconds} (res = how rough
    the 'ago' is: '2 hours ago' can be 1h31m..2h29m). Unknown parts are None."""
    s = str(s or "")
    out = {"amount": None, "ago": None, "res": None}
    m = re.search(r"\$\s*([\d,]+(?:\.\d+)?)", s)
    if m:
        try:
            out["amount"] = float(m.group(1).replace(",", ""))
        except ValueError:
            pass
    low = s.lower()
    if re.search(r"\b(a few seconds|just now|seconds?) ago", low) or "just now" in low:
        out["ago"], out["res"] = 30, 60
        return out
    m = re.search(r"\b(\d+|an?)\s+(second|minute|hour|day|week|month|year)s?\s+ago", low)
    if m:
        unit = _REL_UNITS[m.group(2)]
        n = 1 if m.group(1) in ("a", "an") else int(m.group(1))
        out["ago"], out["res"] = n * unit, unit
    return out


def _num(t):
    m = re.search(r"-?\d[\d,]*(?:\.\d+)?", t or "")
    return float(m.group(0).replace(",", "")) if m else None


def fan_stats(texts):
    """Numbers from the Fan Info panel of the open chat: spent on THIS model, tips, months, and the platform-wide last spend."""
    out = {}
    def value_above(label):
        lab = next((r for r, t in texts if t.strip().lower() == label.lower()), None)
        if not lab:
            return None
        cands = [(r, t) for r, t in texts if abs(r[0] - lab[0]) <= 6 and lab[1] - 26 <= r[1] <= lab[1] - 10]
        return cands[0][1].strip() if cands else None
    for key, label in (("total", "Total Spent ($)"), ("messages", "Messages ($)"), ("tips", "Tips ($)"), ("subscribed", "Subscribed For")):
        v = value_above(label)
        if v is not None:
            out[key] = _num(v) if key != "subscribed" else v
    for key, label in (("platform_total", "total spent:"), ("platform_avg", "avg spend:")):   # Platform-Wide Stats rows
        lab = next((r for r, t in texts if t.strip().lower() == label), None)
        if lab:
            row = sorted([(r, t) for r, t in texts if abs(r[1] - lab[1]) <= 4 and r[0] > lab[2] - 4], key=lambda x: x[0][0])
            v = _num("".join(t for r, t in row)) if row else None
            if v is not None:
                out[key] = v
    lab = next((r for r, t in texts if t.strip().lower() == "last spend:"), None)
    if lab:
        row = sorted([(r, t) for r, t in texts if lab[1] + 8 <= r[1] <= lab[1] + 30 and r[0] >= lab[0] - 4], key=lambda x: (x[0][1], x[0][0]))
        if row:
            y0 = row[0][0][1]
            out["last_spend"] = "".join(t for r, t in row if abs(r[1] - y0) <= 3).strip()
    return out


class UiaReader:
    def __init__(self):
        self.auto = None
        self.failed = 0
        self.disabled = False
        self._off_until = 0.0
        self.mode = None
        self.last_ms = 0
        self.last_n = 0
        self.fast_failed = False
        self.why = ''
        self.fast_miss = 0
        self.fast_wrong = 0
        self._uia = None
        self.iuia_src = ''
        self.fast_error = ''
        self.cached_error = ''
        self.hit = None
        self._cache = None
        self._true = None
        self._walker = None

    def _load(self):
        if self.auto is None:
            import uiautomation as auto            # installed by START.bat; if missing the OCR method is used
            self.auto = auto
        return self.auto

    def _iuia(self):
        """The raw IUIAutomation COM object. Where the 'uiautomation' package keeps it depends on its version:
        module-level _AutomationClient (older), inside uiautomation.uiautomation (2.x - your PC), or - last resort - created directly."""
        if getattr(self, "_uia", None) is None:
            auto = self._load()
            holder = None
            for mod in (auto, getattr(auto, "uiautomation", None)):
                if mod is not None and hasattr(mod, "_AutomationClient"):
                    holder = mod
                    break
            if holder is not None:
                self._uia = holder._AutomationClient.instance().IUIAutomation
                self.iuia_src = "package"
            else:
                import comtypes.client
                from comtypes.gen import UIAutomationClient as U
                self._uia = comtypes.client.CreateObject(U.CUIAutomation._reg_clsid_, interface=U.IUIAutomation)
                self.iuia_src = "direct"
        return self._uia

    def _cached_all(self, hwnd):
        auto = self._load()
        ctrl = auto.ControlFromHandle(hwnd)
        el = ctrl.Element
        uia = self._iuia()
        cache = uia.CreateCacheRequest()
        for pid in (30005, 30001):                 # Name, BoundingRectangle
            cache.AddProperty(pid)
        arr = el.FindAllBuildCache(4, uia.CreateTrueCondition(), cache)    # 4 = all descendants, one call
        out = []
        for i in range(arr.Length):
            e = arr.GetElement(i)
            r = e.CachedBoundingRectangle
            out.append((e.CachedName or "", r.left, r.top, r.right, r.bottom))
        return out

    def _walk_all(self, hwnd):
        auto = self._load()
        root = auto.ControlFromHandle(hwnd)
        out, stack = [], [root]
        while stack and len(out) < 8000:
            c = stack.pop()
            try:
                kids = c.GetChildren()
            except Exception:
                continue
            for k in kids:
                try:
                    r = k.BoundingRectangle
                    out.append((k.Name or "", r.left, r.top, r.right, r.bottom))
                except Exception:
                    pass
                stack.append(k)
        return out

    def _ids_in(self, node, budget=90):
        """Distinct @ids found in this element and below it (breadth first, small budget)."""
        found, queue, n = set(), [(node, 0)], 0
        while queue and n < budget:
            c, d = queue.pop(0)
            n += 1
            try:
                m = _ID.search(str(c.Name or ""))
            except Exception:
                m = None
            if m:
                found.add(m.group(1).lower())
                if len(found) > 1:
                    return found
            if d < 5:
                try:
                    for k in c.GetChildren():
                        queue.append((k, d + 1))
                except Exception:
                    pass
        return found

    def read_chat(self, hwnd):
        """Ctrl+Q without OCR: the open chat(s) as FansMetric exposes them.
        Returns {'chats': [{'name', 'id', 'title', 'composer', 'composer_el'}], 'focus': (x, y) or None, 'n': elements}.
        name  = text of the chat title ('David Bro'), id = from the title's profile link (https://onlyfans.com/u305271820 ->
        'u305271820', custom names too), composer = the chat's message box ('Textbox field') - its element can be focused."""
        auto = self._load()
        uia = self._iuia()
        el = auto.ControlFromHandle(hwnd).Element
        cache = uia.CreateCacheRequest()
        for pid in (30005, 30001, 30003, 30012, 30045, 30093):   # Name, Rect, ControlType, ClassName, Value, LegacyValue
            cache.AddProperty(pid)
        arr = el.FindAllBuildCache(4, uia.CreateTrueCondition(), cache)
        titles, links, boxes, texts, alerts, chatlinks = [], [], [], [], [], []

        def cp(e, pid):
            try:
                v = e.GetCachedPropertyValue(pid)
                return v if isinstance(v, str) else ""
            except Exception:
                return ""
        for i in range(arr.Length):
            e = arr.GetElement(i)
            try:
                r = e.CachedBoundingRectangle
                rect = (r.left, r.top, r.right, r.bottom)
                ct = e.CachedControlType
            except Exception:
                continue
            if rect[2] <= rect[0] or rect[3] <= rect[1]:
                continue
            cls = cp(e, 30012)
            name = (e.CachedName or "").strip()
            if ct == 50020 and "m-chat-title" in cls:                       # Text: the chat header title
                titles.append({"rect": rect, "text": name})
            elif ct == 50005:                                                # Hyperlink
                href = cp(e, 30045) or cp(e, 30093)
                m = _PROFILE_LINK.match(href or "")
                if m and name:
                    links.append({"rect": rect, "name": name, "id": m.group(1)})
                mc = _CHAT_LINK.search(href or "")
                if mc:
                    chatlinks.append({"rect": rect, "num": mc.group(1)})
            elif ct == 50004 and (name.lower() == "textbox field" or "b-text-editor" in cls):   # Edit: chat message box
                boxes.append({"rect": rect, "el": e})
            if ct == 50020 and name:                                         # every text: chat bubbles + Fan Info numbers
                texts.append((rect, e.CachedName or ""))
            if name and _ALERT_RX.search(name) and len(name) < 300:          # 'Banned: "little"' / 'please wait 3 seconds' banners
                alerts.append((rect, e.CachedName or ""))
        chats = []
        for t in titles:
            tl, tt, tr, tb = t["rect"]
            ln = next((l for l in links if tl - 4 <= l["rect"][0] <= tr and tt - 6 <= l["rect"][1] <= tb + 6), None)
            if not ln:
                ln = title_fallback(t, links, chatlinks)     # narrow layout: no profile link in the header
            if not ln:
                continue
            box = None                                                       # the message box under this chat's title
            for b in boxes:
                bl, bt, br, bb = b["rect"]
                if bt > tb and bl - 60 <= tl <= br and (box is None or bt < box["rect"][1]):
                    box = b
            chats.append({"name": ln["name"], "id": ln["id"], "title": t["rect"],
                          "composer": box["rect"] if box else None, "composer_el": box["el"] if box else None,
                          "messages": chat_messages(texts, t["rect"], box["rect"] if box else None)})
        focus = None
        try:
            f = uia.GetFocusedElement()
            fr = f.CurrentBoundingRectangle
            focus = ((fr.left + fr.right) // 2, (fr.top + fr.bottom) // 2)
        except Exception:
            pass
        return {"chats": chats, "focus": focus, "n": arr.Length, "stats": fan_stats(texts), "alerts": read_alerts(alerts, texts)}

    def account_name(self, hwnd):
        """The OnlyFans account shown in this FansMetric window ('Select Account jessicareed1' button). Checked once a minute."""
        now = time.time()
        if getattr(self, "_acct_at", 0) + 60 > now and getattr(self, "_acct_hwnd", None) == hwnd:
            return self._acct
        acct = ""
        try:
            auto = self._load()
            uia = self._iuia()
            el = auto.ControlFromHandle(hwnd).Element
            btns = el.FindAll(4, uia.CreatePropertyCondition(30003, 50000))
            for i in range(btns.Length if btns is not None else 0):
                nm = btns.GetElement(i).CurrentName or ""
                m = re.search(r"select account\s+(\S+)\s*$", nm, re.I)
                if m:
                    acct = m.group(1)
                    break
        except Exception:
            pass
        self._acct, self._acct_at, self._acct_hwnd = acct, now, hwnd
        return acct

    def _notif_doc_find(self, hwnd):
        """The NOTIFICATIONS panel (its own web page inside FansMetric). Remembered, so later reads only touch that
        panel (~100 elements) instead of the whole FansMetric window (~1000) - much lighter."""
        auto = self._load()
        uia = self._iuia()
        doc = getattr(self, "_notif_doc", None)
        if doc is not None:
            try:
                r = doc.CurrentBoundingRectangle
                if (doc.CurrentName or "").lower().startswith("notifications") and r.right > r.left and r.bottom > r.top:
                    return doc, (r.left, r.top, r.right, r.bottom)
            except Exception:
                pass
            self._notif_doc = None
        el = auto.ControlFromHandle(hwnd).Element
        try:
            self._fm_pid = el.CurrentProcessId                # only elements of FansMetric itself count (not PokeFlow on top)
        except Exception:
            self._fm_pid = None
        docs = el.FindAll(4, uia.CreatePropertyCondition(30003, 50030))
        for i in range(docs.Length if docs is not None else 0):
            d = docs.GetElement(i)
            try:
                if (d.CurrentName or "").lower().startswith("notifications"):
                    r = d.CurrentBoundingRectangle
                    if r.right > r.left and r.bottom > r.top:
                        self._notif_doc = d
                        return d, (r.left, r.top, r.right, r.bottom)
            except Exception:
                continue
        return None, None

    def notif_subs(self, hwnd):
        """The NOTIFICATIONS panel's cards (see notif_cards), or None when that panel is not open in FansMetric."""
        uia = self._iuia()
        doc, rect = self._notif_doc_find(hwnd)
        if doc is None:
            return None
        cache = uia.CreateCacheRequest()
        for pid in (30005, 30001, 30003):
            cache.AddProperty(pid)
        arr = doc.FindAllBuildCache(4, uia.CreateTrueCondition(), cache)
        items = []
        for i in range(arr.Length if arr is not None else 0):
            e = arr.GetElement(i)
            try:
                r = e.CachedBoundingRectangle
                items.append(((r.left, r.top, r.right, r.bottom), e.CachedControlType, e.CachedName or "", e))
            except Exception:
                continue
        L, T, R, B = rect
        self.notif_rect = rect
        cards = notif_cards(items)
        acct = self.account_name(hwnd)
        for c in cards:                                   # who was welcomed is remembered per ACCOUNT + fan
            c["fan_id"] = c["id"]
            c["account"] = acct
            if acct:
                c["id"] = f"{acct}:{c['id']}"
        now = time.time()
        tries = getattr(self, "_box_tries", None)
        if tries is None:
            tries = self._box_tries = {}
        for c in cards:                                   # box missing from the list: ask what is AT its place on screen
            if c["sub"] and not c["replied"] and (c["edit"] is None or c["send"] is None):
                n, last = tries.get(c["id"], (0, 0.0))
                if n >= 3 and now - last < 30:
                    c["search_skipped"] = True            # searched 3x ON SCREEN for nothing (no box for him): rest 30 s -
                    continue                              # these searches every second were a big part of the lag
            if c["sub"] and not c["replied"] and (c["edit"] is None or c["send"] is None) and c.get("ago_el") is not None:
                self._from_card(c)                        # 1st: search inside the card itself (works even if covered)
            if c["sub"] and not c["replied"] and (c["edit"] is None or c["send"] is None) and c.get("ago_rect"):
                a = c["ago_rect"]
                if not (T <= a[1] and a[3] + 50 <= B):
                    continue                              # not on screen: can't be asked by position
                k = max(0.6, (a[3] - a[1]) / 17.0)
                if c["edit"] is None:
                    c["edit"] = self._at_point(a[0] + int(30 * k), a[3] + int(20 * k), 50004) or \
                                self._at_point(a[0] + int(82 * k), a[3] + int(20 * k), 50004)
                if c["send"] is None:
                    c["send"] = self._at_point(a[0] + int(200 * k), a[3] + int(19 * k), 50000)
                c["by_point"] = True
        for c in cards:
            if c.get("search_skipped") or not c["sub"] or c["replied"]:
                continue
            if c["edit"] is None or c["send"] is None:
                a = c.get("ago_rect")
                if not (a and T <= a[1] and a[3] + 50 <= B):
                    continue                              # off screen: no box is normal there - not a try
                n, _l = tries.get(c["id"], (0, 0.0))
                tries[c["id"]] = (min(n + 1, 3), now)
            else:
                tries.pop(c["id"], None)
        if len(tries) > 300:
            tries.clear()
        return cards

    def _from_card(self, c):
        """Ask the card's container (parents of its '... ago' line) for its box and Send button - ONLY elements that lie
        inside THIS fan's card count (a parent can be the whole list - never another fan's box)."""
        try:
            uia = self._iuia()
            walker = uia.RawViewWalker
            y0, y1 = c.get("top", 0) - 10, c.get("y_end", c.get("top", 0) + 200)
            def inside(e):
                try:
                    r = e.CurrentBoundingRectangle
                    return y0 <= r.top < y1 and r.bottom > r.top
                except Exception:
                    return False
            e = c["ago_el"]
            for _ in range(3):
                e = walker.GetParentElement(e)
                if e is None:
                    return
                if c["edit"] is None:
                    eds = e.FindAll(4, uia.CreatePropertyCondition(30003, 50004))
                    for i in range(eds.Length if eds is not None else 0):
                        ed = eds.GetElement(i)
                        if inside(ed) and ("quick reply" in (ed.CurrentName or "").lower() or not (ed.CurrentName or "")):
                            c["edit"] = ed
                            break
                if c["send"] is None:
                    btns = e.FindAll(4, uia.CreatePropertyCondition(30003, 50000))
                    for i in range(btns.Length if btns is not None else 0):
                        b = btns.GetElement(i)
                        if (b.CurrentName or "").strip().lower() == "send" and inside(b):
                            c["send"] = b
                            break
                if c["edit"] is not None and c["send"] is not None:
                    c["by_card"] = True
                    return
        except Exception:
            return

    def _at_point(self, x, y, want_type):
        """The element of `want_type` (Edit / Button) at screen point x, y - or one of its 3 parents. Asking by position
        makes Chromium hand over that exact element even when it left it out of the full list."""
        try:
            from ctypes.wintypes import POINT
            e = self._iuia().ElementFromPoint(POINT(int(x), int(y)))
            if e is None or (getattr(self, "_fm_pid", None) and e.CurrentProcessId != self._fm_pid):
                return None                                   # another window (e.g. PokeFlow) is covering that spot
            walker = self._iuia().ControlViewWalker
            rect = getattr(self, "notif_rect", None)
            for _ in range(4):
                if e is None:
                    return None
                if e.CurrentControlType == want_type:
                    nm = (e.CurrentName or "").strip().lower()
                    if want_type == 50000 and nm != "send":
                        return None                       # never press any other FansMetric button
                    if want_type == 50004 and nm and "quick reply" not in nm:
                        return None
                    if rect:
                        r = e.CurrentBoundingRectangle
                        if not (rect[0] - 2 <= r.left and r.right <= rect[2] + 2 and rect[1] <= r.top and r.bottom <= rect[3] + 2):
                            return None                   # outside the Notifications panel
                    return e
                e = walker.GetParentElement(e)
        except Exception:
            return None
        return None

    def button_at(self, x, y):
        """Name of the FansMetric BUTTON under screen point x, y (the element itself or its 2 parents), else None.
        Used so a grey button tooltip ("More" on the chat's 3-dot button) is not taken for a fan-name tooltip.
        Fan names are links / text, never buttons."""
        try:
            from ctypes.wintypes import POINT
            e = self._iuia().ElementFromPoint(POINT(int(x), int(y)))
            walker = self._iuia().ControlViewWalker
            for _ in range(3):
                if e is None:
                    return None
                ct = e.CurrentControlType
                if ct == 50005:                                # a link (fan names are links): not a button
                    return None
                if ct == 50000:
                    r = e.CurrentBoundingRectangle
                    if r.right - r.left > 60 or r.bottom - r.top > 60:
                        return None                            # a big clickable card/row (could hold a name): not an icon
                    return (e.CurrentName or "").strip() or "(button)"
                e = walker.GetParentElement(e)
        except Exception:
            return None
        return None

    def set_value(self, element, text):
        """Types into a plain input field without the keyboard (UI Automation Value pattern). True when it holds `text`."""
        auto = self._load()
        ctl = auto.Control.CreateControlFromElement(element)
        ctl.GetValuePattern().SetValue(text)
        v = element.GetCurrentPropertyValue(30045)
        return isinstance(v, str) and v.strip() == text.strip()

    def value_of(self, element):
        try:
            v = element.GetCurrentPropertyValue(30045)
            return v if isinstance(v, str) else ""
        except Exception:
            return None

    def find_block(self, hwnd):
        """FansMetric's 'Please allow 3 seconds.' box (OnlyFans' 3-second rule) - found by its text, no OCR.
        Returns {'close': its CLOSE button or None} when it is showing, else None."""
        auto = self._load()
        uia = self._iuia()
        el = auto.ControlFromHandle(hwnd).Element
        hit = None
        for txt in ("Please allow 3 seconds.", "Please allow 3 seconds", "Please allow 3 seconds!"):
            try:
                found = el.FindAll(4, uia.CreatePropertyCondition(30005, txt))
            except Exception:
                found = None
            for i in range(found.Length if found is not None else 0):
                e = found.GetElement(i)
                try:                                      # FansMetric keeps a HIDDEN copy on the page all the time:
                    r = e.CurrentBoundingRectangle        # only a box you can actually see counts
                    if e.CurrentIsOffscreen or r.right - r.left < 4 or r.bottom - r.top < 4:
                        continue
                except Exception:
                    continue
                hit = e
                break
            if hit is not None:
                break
        if hit is None:
            return None
        close = None
        try:                                              # its CLOSE button: any Button named close/ok in the box (6 levels up)
            walker = uia.RawViewWalker
            p = hit
            for _ in range(6):
                p = walker.GetParentElement(p)
                if p is None:
                    break
                btns = p.FindAll(4, uia.CreatePropertyCondition(30003, 50000))
                for i in range(btns.Length if btns is not None else 0):
                    b = btns.GetElement(i)
                    try:
                        if (b.CurrentName or "").strip().lower() in ("close", "ok", "got it", "okay"):
                            close = b
                            break
                    except Exception:
                        continue
                if close is not None:
                    break
        except Exception:
            pass
        if close is None:                                 # backup: FansMetric's alert window by its id ('ModalAlert')
            try:
                m = el.FindFirst(4, uia.CreatePropertyCondition(30011, "ModalAlert"))
                if m is not None:
                    btns = m.FindAll(4, uia.CreatePropertyCondition(30003, 50000))
                    for i in range(btns.Length if btns is not None else 0):
                        b = btns.GetElement(i)
                        if (b.CurrentName or "").strip().lower() in ("close", "ok", "got it", "okay"):
                            close = b
                            break
            except Exception:
                pass
        return {"close": close}

    def panel_doc(self, hwnd):
        """(doc, url) of the web page sitting where the NOTIFICATIONS panel is - it keeps its place (and changes its
        name / address) when it shows a fan's chat. None when there is no such page."""
        rect = getattr(self, "notif_rect", None)
        if not rect:
            return None, None
        auto = self._load()
        uia = self._iuia()
        el = auto.ControlFromHandle(hwnd).Element
        docs = el.FindAll(4, uia.CreatePropertyCondition(30003, 50030))
        for i in range(docs.Length if docs is not None else 0):
            d = docs.GetElement(i)
            try:
                r = d.CurrentBoundingRectangle
                if all(abs(a - b) <= 8 for a, b in zip((r.left, r.top, r.right, r.bottom), rect)):
                    v = d.GetCurrentPropertyValue(30045)
                    return d, (v if isinstance(v, str) else "")
            except Exception:
                continue
        return None, None

    def panel_chat(self, doc):
        """A fan's chat opened INSIDE the Notifications panel: its message box, Send button, back arrow and the visible
        texts (to see if our welcome is already there). Only elements of this panel - never your main chat."""
        uia = self._iuia()
        cache = uia.CreateCacheRequest()
        for pid in (30005, 30001, 30003, 30012, 30010, 30022):
            cache.AddProperty(pid)
        arr = doc.FindAllBuildCache(4, uia.CreateTrueCondition(), cache)
        dr = doc.CurrentBoundingRectangle
        items = []
        for i in range(arr.Length if arr is not None else 0):
            e = arr.GetElement(i)
            try:
                r = e.CachedBoundingRectangle
                if e.CachedIsOffscreen or r.right - r.left < 2 or r.bottom - r.top < 2:
                    continue
                items.append(((r.left, r.top, r.right, r.bottom), e.CachedControlType, (e.CachedName or "").strip(),
                              (e.CachedClassName or ""), bool(e.CachedIsEnabled), e))
            except Exception:
                continue
        return panel_chat_parse(items, (dr.left, dr.top, dr.right, dr.bottom))

    def scroll_into_view(self, element):
        """Makes FansMetric scroll the NOTIFICATIONS panel so this card is visible (it only builds a card's reply box
        while the card is on screen). No mouse; the chat is not touched."""
        auto = self._load()
        ctl = auto.Control.CreateControlFromElement(element)
        pat = None
        for get in (lambda: ctl.GetScrollItemPattern(), lambda: ctl.GetPattern(10017),
                    lambda: auto.CreatePattern(10017, element.GetCurrentPattern(10017))):
            try:
                pat = get()
            except Exception:
                pat = None
            if pat is not None:
                break
        if pat is None:
            raise RuntimeError("FansMetric does not offer 'scroll into view' for this card")
        pat.ScrollIntoView()
        return True

    def press(self, element):
        """Clicks a button without the mouse (UI Automation Invoke pattern)."""
        auto = self._load()
        auto.Control.CreateControlFromElement(element).GetInvokePattern().Invoke()
        return True

    def focused_composer_text(self):
        """(text, rect) of the chat message box when it has the keyboard focus, else (None, None). Cheap: one call."""
        uia = self._iuia()
        try:
            f = uia.GetFocusedElement()
            cls = f.CurrentClassName or ""
            if "b-text-editor" not in cls and (f.CurrentName or "").lower() != "textbox field":
                return None, None
            r = f.CurrentBoundingRectangle
            v = f.GetCurrentPropertyValue(30045)
            v = v if isinstance(v, str) else ""
            v = v.strip()
            if v.lower().startswith("type a message"):          # the grey placeholder of an empty box
                v = ""
            return v, (r.left, r.top, r.right, r.bottom)
        except Exception:
            return None, None

    def warm_tree(self, hwnd):
        """One full read of the window, only to make Chromium (re)build the page's accessibility tree (it needs a few real
        reads after you come back to a tab). Returns (elements, @ids found) or None."""
        if not self._revive():
            return None
        try:
            els = self._walk_all(hwnd) if self.mode == "walk" else self._cached_all(hwnd)
            n_ids = sum(1 for e in els if _ID.search(str(e[0] or "")))
            return len(els), n_ids
        except Exception:
            return None

    def probe(self, x, y):
        """Cheapest possible 'what is at this point' call. Its only job is to make Chromium (FansMetric) build/refresh the
        accessibility tree of the page that is on screen NOW - right after you switch back to the fans page the tree is
        empty until some program asks for it, which is the short 'loading' time before the first hover works."""
        if not self._revive():
            return False
        try:
            if not self.fast_failed:
                uia = self._iuia()
                if self._cache is None:
                    c = uia.CreateCacheRequest()
                    for pid in (30005, 30001):
                        c.AddProperty(pid)
                    self._cache = c
                    self._true = uia.CreateTrueCondition()
                    self._walker = uia.ControlViewWalker
                from ctypes.wintypes import POINT
                uia.ElementFromPointBuildCache(POINT(int(x), int(y)), self._cache)
            else:
                self._load().ControlFromPoint(int(x), int(y))
            return True
        except Exception:
            return False

    def _disable(self):
        """Switch the reader off for a few seconds only (it used to stay off for good after a handful of errors, which is why
        the badges could 'suddenly stop' hours into a session)."""
        self.disabled = True
        self._off_until = time.monotonic() + 6.0

    def _revive(self):
        if self.disabled and time.monotonic() >= getattr(self, '_off_until', 0.0):
            self.disabled = False
            self.failed = 0
        return not self.disabled

    def id_at_point(self, x, y):
        """Fast batched lookup first; when that finds nothing, the slower one-by-one lookup double-checks (it is the one that
        is known to work on every PC). `why` says why the fast one gave up (for badges_debug.txt)."""
        if not self._revive():
            return None
        self.why = ''
        self.hit = None                      # (name, rect) of the exact element under the mouse (the text itself)
        if self.fast_failed:
            return self._id_at_point_slow(x, y)
        got = self._id_at_point_fast(x, y)
        if got is not None or self.why == 'two-ids':
            return got
        self.fast_miss = getattr(self, 'fast_miss', 0) + 1
        got2 = self._id_at_point_slow(x, y)
        if got2 is not None:
            self.fast_wrong = getattr(self, 'fast_wrong', 0) + 1      # fast said no, slow found a fan
            self.why = (self.why or 'none') + ' (slow found)'
        return got2

    def _id_at_point_fast(self, x, y, _retry=False):
        """The fan card under a screen point: (id, (l, t, r, b)) or None.
        Fast path: one 'element from point' call, then one batched call per level up (names + rectangles cached)."""
        if not self._revive():
            return None
        if self.fast_failed:
            return self._id_at_point_slow(x, y)
        try:
            auto = self._load()
            uia = self._iuia()
            if self._cache is None:
                c = uia.CreateCacheRequest()
                for pid in (30005, 30001):             # Name, BoundingRectangle
                    c.AddProperty(pid)
                self._cache = c
                self._true = uia.CreateTrueCondition()
                self._walker = uia.ControlViewWalker
            from ctypes.wintypes import POINT
            el = uia.ElementFromPointBuildCache(POINT(int(x), int(y)), self._cache)
            for lvl in range(10):
                if el is None:
                    self.why = 'no-element'
                    return None
                r = el.CachedBoundingRectangle
                w, h = r.right - r.left, r.bottom - r.top
                if lvl == 0 and not _retry:
                    self.hit = (str(el.CachedName or ''), (r.left, r.top, r.right, r.bottom))
                if w > 450 or h > 800:
                    self.why = 'too-big level=%d %dx%d' % (lvl, w, h)
                    if lvl == 0 and not _retry and 400 <= w <= 1100 and h <= 6000:
                        # The list container answered instead of a card (cards not exposed to hit-testing yet). Read everything
                        # below it in ONE call (this also makes Chromium build the cards) and find the card in memory.
                        try:
                            now_t = time.monotonic()
                            pc = getattr(self, '_pane_cache', None)
                            if pc is None or now_t - pc[0] > 0.15 or pc[1] != (r.left, r.top, r.right, r.bottom):
                                arr = el.FindAllBuildCache(4, self._true, self._cache)
                                items = []
                                for i in range(min(arr.Length, 4000)):
                                    e2 = arr.GetElement(i)
                                    rr = e2.CachedBoundingRectangle
                                    items.append((rr.left, rr.top, rr.right, rr.bottom, e2.CachedName))
                                pc = (now_t, (r.left, r.top, r.right, r.bottom), items)
                                self._pane_cache = pc
                            under = [(rr[2] - rr[0]) * (rr[3] - rr[1]) for rr in pc[2]
                                     if rr[0] <= x <= rr[2] and rr[1] <= y <= rr[3] and str(rr[4] or '').strip()]
                            if under:
                                best = min((rr for rr in pc[2] if rr[0] <= x <= rr[2] and rr[1] <= y <= rr[3] and str(rr[4] or '').strip()),
                                           key=lambda rr: (rr[2] - rr[0]) * (rr[3] - rr[1]))
                                self.hit = (str(best[4]), (best[0], best[1], best[2], best[3]))
                            hit = resolve_card(pc[2], x, y)
                            if hit is not None:
                                self.why = 'from-pane n=%d' % len(pc[2])
                                return hit
                        except Exception as exc3:
                            self.why = 'pane-error %s' % repr(exc3)[:80]
                    if (lvl == 0 and not _retry and 400 <= w <= 1100 and h <= 6000
                            and time.monotonic() - getattr(self, '_wake_t', 0.0) > 1.2):
                        # The list container answered instead of a card: Chromium has not built the cards below it yet
                        # (right after a page switch). Asking for everything below it forces that build; then ask again.
                        self._wake_t = time.monotonic()
                        try:
                            el.FindAllBuildCache(4, self._true, self._cache)
                        except Exception:
                            pass
                        got = self._id_at_point_fast(x, y, True)
                        if got is not None:
                            self.why = 'woke-list'
                        return got
                    return None                       # climbed out of the card (the whole list)
                ids = set()
                m = _ID.search(str(el.CachedName or ""))
                if m:
                    ids.add(m.group(1).lower())
                if w >= 60 and h >= 18:
                    arr = el.FindAllBuildCache(4, self._true, self._cache)     # everything below, one call
                    for i in range(min(arr.Length, 200)):
                        m = _ID.search(str(arr.GetElement(i).CachedName or ""))
                        if m:
                            ids.add(m.group(1).lower())
                            if len(ids) > 1:
                                self.why = 'two-ids'
                                return None            # two fans in one box: the cursor is between cards
                if len(ids) == 1 and 250 <= w <= 450 and h >= 200:          # a FANS card (320x280); Messages rows are ~80 high
                    if not (r.left - 2 <= x <= r.right + 2 and r.top - 2 <= y <= r.bottom + 2):
                        self.why = 'stale-rect'
                        return None                    # the tree's rectangle is out of date (just scrolled): do not trust it
                    return next(iter(ids)), (r.left, r.top, r.right, r.bottom)
                try:
                    el = self._walker.GetParentElementBuildCache(el, self._cache)
                except Exception as exc2:
                    self.why = 'parent-error level=%d %s' % (lvl, repr(exc2)[:120])
                    return None
        except Exception as exc:
            self.fast_failed = True                    # use the slower but sure method from now on
            self.fast_error = repr(exc)[:300]
            return self._id_at_point_slow(x, y)
        return None

    def _id_at_point_slow(self, x, y):
        """Same answer with ordinary one-by-one calls. The size of each level is looked at FIRST, so a cursor that is not on
        a fan card is given up after one level instead of scanning the whole page."""
        if not self._revive():
            return None
        try:
            auto = self._load()
            node = auto.ControlFromPoint(int(x), int(y))
            self.failed = 0
            first = True
            for _ in range(9):
                if node is None:
                    return None
                r = node.BoundingRectangle
                w, h = r.right - r.left, r.bottom - r.top
                if first:
                    first = False
                    try: self.hit = (str(node.Name or ''), (r.left, r.top, r.right, r.bottom))
                    except Exception: pass
                if w > 450 or h > 800:
                    return None                    # bigger than a fan card: the list, the page, the gap between cards
                ids = self._ids_in(node, 120)
                if len(ids) > 1:
                    return None
                if len(ids) == 1 and 250 <= w <= 450 and h >= 200:
                    if not (r.left - 2 <= x <= r.right + 2 and r.top - 2 <= y <= r.bottom + 2):
                        return None                # out-of-date rectangle (just scrolled)
                    return next(iter(ids)), (r.left, r.top, r.right, r.bottom)
                node = node.GetParentControl()
        except Exception:
            self.failed += 1
            if self.failed >= 8:
                self._disable()
        return None

    def read(self, hwnd, window_rect):
        """Returns parse(...) result or None when UI Automation is not usable."""
        if not self._revive():
            return None
        t0 = time.monotonic()
        try:
            try:
                if self.mode != "walk":
                    els = self._cached_all(hwnd)
                    self.mode = "cached"
                else:
                    els = self._walk_all(hwnd)
            except Exception as exc:
                if self.mode == "cached":
                    raise
                self.cached_error = repr(exc)[:300]
                self.mode = "walk"
                els = self._walk_all(hwnd)
            self.last_ms = int((time.monotonic() - t0) * 1000)
            self.last_n = len(els)
            if len(els) < 60:                      # tree not exposed (yet)
                self.failed += 1
                if self.failed >= 6:
                    self._disable()
                return None
            data = parse(els, window_rect)
            if data is None:
                return {"cards": [], "clip_top": 0, "bottom": 0, "band": (0, 0), "no_list": True}
            self.failed = 0
            return data
        except Exception:
            self.failed += 1
            if self.failed >= 4:
                self._disable()
            return None
