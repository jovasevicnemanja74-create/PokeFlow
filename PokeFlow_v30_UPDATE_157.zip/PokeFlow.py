import tkinter as tk
import tkinter.font as tkfont
from tkinter import messagebox, simpledialog
import pyautogui
import pyperclip
import pygetwindow as gw
import shutil, webbrowser
import re, time, ctypes, random, math, threading, json, os, subprocess, tempfile, urllib.request
from datetime import datetime
import statistics
from pathlib import Path

# Optional local-only AI Reply feature; it uses only the standard library and
# communicates with Ollama on 127.0.0.1. The rest of PokeFlow works without it.
from ai_reply_core import (
    MODEL_SPECS as AI_MODEL_SPECS,
    DEFAULT_MODEL_LABEL as AI_DEFAULT_MODEL_LABEL,
    OLLAMA_DOWNLOAD_URL as AI_OLLAMA_DOWNLOAD_URL,
    check_ollama as _ai_check_ollama,
    pull_model as _ai_pull_model,
    generate_reply as _ai_generate_reply,
    generate_followup as _ai_generate_followup,
    summarize_notes as _ai_summarize_notes,
    start_ollama_service as _ai_start_ollama_service,
)
import ai_reply_core as _ai_core
_ai_cpu_note = {'shown': False}


def _ai_cpu_switched():
    """The graphics card crashed the AI (e.g. NVIDIA driver too old: 'CUDA error ... PTX ... unsupported toolchain').
    ai_reply_core already retried on the CPU; remember CPU ONLY and say it once."""
    if _ai_cpu_note['shown']:
        return
    _ai_cpu_note['shown'] = True
    try: _remember_setting('ai_cpu_only', True)
    except Exception: pass
    try:
        chip = ai_reply_widgets.get('cpu_only')
        if chip is not None:
            chip.var.set(True)
    except Exception:
        pass
    try:
        _pop_info('AI switched to CPU ONLY', 'Graphics card driver too old for it - update the NVIDIA driver for faster replies.', 12.0)
    except Exception:
        pass


def _ai_cpu_watch(fn):
    def wrapped(*a, **k):
        try:
            return fn(*a, **k)
        finally:
            if _ai_core.FORCE_CPU and not _ai_cpu_note['shown']:
                try: root.after(0, _ai_cpu_switched)
                except Exception: pass
    return wrapped


_ai_generate_reply = _ai_cpu_watch(_ai_generate_reply)
_ai_generate_followup = _ai_cpu_watch(_ai_generate_followup)
_ai_summarize_notes = _ai_cpu_watch(_ai_summarize_notes)

# Optional video background dependencies. The launcher installs them if needed.
try:
    import cv2
    from PIL import Image, ImageTk
    VIDEO_READY = True
except Exception:
    cv2 = None
    Image = ImageTk = None
    VIDEO_READY = False

try:
    import pystray
    from PIL import Image as TrayImage
    TRAY_READY = True
except Exception:
    pystray = None
    TrayImage = None
    TRAY_READY = False

APP_TITLE = 'PokeFlow'
VERSION = 'v30'
CREATOR = 'Cone'
W, H = 900, 600
NEON_PINK = '#bd72f5'
NEON_CYAN = '#49bde6'
NEON_PURPLE = '#8b82d7'
NEON_ORANGE = '#d9a46b'
NEON_YELLOW = '#e7cf85'
WHITE = '#eef3fa'
DARK = '#0a1019'
# Theme selection: NORMAL uses Professional Dark; NEON restores the Cyberpunk Main Menu Reference.
theme_mode='NORMAL'
video_background_enabled=False

# Header coordinates are anchored near the FIRST visible character of the name.
# Name selection drags from within the label to the right, away from the back/edit
# controls. The former online drag began on the pencil icon, which could open a page
# instead of selecting the name, especially for short names.
ONLINE_NAME_DRAG_START = (0.503, 0.155)
ONLINE_NAME_DRAG_END   = (0.544, 0.155)
ONLINE_COMPOSER_CLICK  = (0.63, 0.835)
OFFLINE_NAME_DRAG_START = (0.353, 0.153)
OFFLINE_NAME_DRAG_END   = (0.423, 0.153)
OFFLINE_COMPOSER_CLICK  = (0.42, 0.845)
# Right-click near the first character so short labels such as "Evan" do not put
# the target on the edit/pencil control at the end of the name.
ONLINE_PROFILE_LINK_POINT  = (0.504, 0.155)
OFFLINE_PROFILE_LINK_POINT = (0.354, 0.153)
pyautogui.PAUSE = 0.01

POKE1 = [
"what are you up to babe? we haven't talked in a bit and i was curious how you've been doing...",
"i was wondering what you've been getting into lately, babe. feels like it's been a while since we caught up...",
"how's everything going with you, babe? we haven't talked much lately and i wanted to check in and see how you're doing...",
"you've been kinda quiet lately, babe. what have you been up to? i wanted to see what's been going on with you...",
"i randomly thought about you earlier and realized we haven't talked in a while, babe. how have you been?",
"what's been keeping you so busy lately, babe? we haven't had a proper chat in some time and i wanted to check on you...",
"i feel like it's been way too long since we had a conversation, babe. what have you been up to lately?",
"are you having a busy day, babe? i haven't heard much from you lately and wanted to see how things are going...",
"i haven't checked in with you for a while, babe, so here i am 😘 what have you been getting into lately?",
"tell me what you've been up to lately, babe. i feel like i haven't heard from you in forever and i'm curious how you're doing..."
]
POKE2 = [
"i can see you've checked my messages but you haven't answered me yet..are you not in the mood to talk to me babe? 🥺",
"you've seen my messages and gone quiet on me..did i do something wrong babe or are you just busy? 🥺",
"i noticed you looked at what i sent but didn't say anything back..you don't wanna chat with me babe? 🥺",
"sooo you keep checking my messages but leave me with no reply..are you really gonna ignore me like that babe? 🥺",
"i see you've been around but you still haven't answered me..should i take that as you not wanting to talk to me, babe? 🥺",
"you read what i sent and then disappeared again..come on babe, don't leave me wondering like this 🥺",
"i know you've seen my messages, babe, so now i'm curious..why are you being so quiet with me? 🥺",
"you've been checking in without actually replying..did i lose your attention babe? 🥺",
"i keep seeing that you've looked at my messages but you're not saying anything, babe..what's going on with you? 🥺",
"okay babe, i see you checking my messages 👀 but you're still not replying..do you not wanna talk to me anymore? 🥺"
]
POKE3 = [
"okay babe, i won't keep bothering you 🥺 i just wanted to hear from you..tell me what you've been up to when you get a chance?",
"alright babe, i'll stop being dramatic 😂 i was just wondering about you..how have you actually been?",
"i guess you're keeping me curious, babe 😅 when you do get a minute, tell me what's been going on with you...",
"okay babe, i'll give you some space..but when you come back, you better tell me what you've been up to 😘",
"maybe you've just been busy, babe, i get it 🥺 just don't disappear on me completely..come talk to me when you can",
"i'll take the hint for now, babe 😂 but i'm still curious about you..what have you been getting into lately?",
"no pressure babe, i just wanted to make sure everything's good with you..come say hi when you have a minute ❤️",
"okay babe, i'll leave you alone for a bit 😘 but now you owe me a proper conversation when you're free...",
"i'm guessing you've got something keeping you busy, babe..just come back and tell me about it when you can 🥺",
"alright babe, i'll stop chasing you for now 😂 i still wanna hear what's been going on with you though..."
]
for group_name, group in (("Poke 1",POKE1),("Poke 2",POKE2),("Poke 3",POKE3)):
    if len(group)!=10 or any(not re.search(r'\bbabe\b',m,re.I) for m in group):
        raise RuntimeError(f'{group_name} validation failed: every message must contain babe.')

# Poke history is keyed by the unique FansMetric/OnlyFans profile ID rather
# than the display name. It is persisted per Windows user so two people with the
# same name stay separate across app restarts.
def _history_file_path():
    local_app_data = os.environ.get('LOCALAPPDATA')
    if local_app_data:
        return Path(local_app_data) / 'PokeFlow' / 'poke_history.json'
    return Path.home() / '.pokeflow' / 'poke_history.json'

POKE_HISTORY_PATH = _history_file_path()

# ---- crash recorder: if PokeFlow ever dies, crash_log.txt (next to the poke history) says where, for every thread ----
CRASH_LOG_PATH = POKE_HISTORY_PATH.parent / 'crash_log.txt'
try:
    import faulthandler as _faulthandler
    CRASH_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        if CRASH_LOG_PATH.exists() and CRASH_LOG_PATH.stat().st_size > 400_000:
            CRASH_LOG_PATH.write_text('', encoding='utf-8')
    except Exception:
        pass
    _PREV_CRASH = None
    try:                                                    # did the LAST run crash? (fatal error after its start line)
        if CRASH_LOG_PATH.exists():
            with open(CRASH_LOG_PATH, 'rb') as _cf:
                _cf.seek(max(0, CRASH_LOG_PATH.stat().st_size - 60000))
                _tail = _cf.read().decode('utf-8', errors='replace')
            _last = _tail.rsplit('===== PokeFlow started', 1)[-1]
            if re.search(r'Fatal Python error|Windows fatal exception|Current thread .* \(most recent call first\)', _last):
                _PREV_CRASH = _last[-8000:]
    except Exception:
        _PREV_CRASH = None
    _crash_file = open(CRASH_LOG_PATH, 'a', encoding='utf-8')
    _crash_file.write(f"\n===== PokeFlow started {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n"); _crash_file.flush()
    _faulthandler.enable(file=_crash_file, all_threads=True)
except Exception:
    _crash_file = None
    _PREV_CRASH = None


def _crash_note(text):
    try:
        if _crash_file is not None:
            _crash_file.write(f"{time.strftime('%H:%M:%S')} {text}\n"); _crash_file.flush()
    except Exception:
        pass


def _thread_excepthook(args):
    import traceback
    _crash_note(f'Thread {getattr(args.thread, "name", "?")} error:\n' +
                ''.join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback))[-2500:])
threading.excepthook = _thread_excepthook
APP_SETTINGS_PATH = POKE_HISTORY_PATH.parent / 'settings.json'


def _load_app_settings():
    # Backward-compatible settings loader; unknown or invalid values use safe defaults.
    defaults = {'save_profile_ids': True, 'repoke_timer_seconds': 180,
                'shortcut_poke': 'Q', 'shortcut_send': 'E', 'shortcut_timer': 'T', 'shortcut_draft': 'G', 'model_names': '',
                'theme_mode': 'NORMAL', 'anti_block_enabled': True, 'history_sort_newest': True,
                'ai_model': '', 'ai_length': 'Short', 'ai_mode': 'Auto', 'ai_cpu_only': False, 'notify_sound': True, 'animated_bg': True, 'poke_badges': True, 'menu_volume': 100, 'quick_replies': [''] * 9}
    try:
        raw = json.loads(APP_SETTINGS_PATH.read_text(encoding='utf-8'))
        if isinstance(raw, dict):
            defaults.update(raw)
    except Exception:
        pass
    defaults['save_profile_ids'] = True      # always on: Fans History, timers and Ctrl+Q/T depend on it (the OFF switch was removed)
    defaults['model_names'] = str(defaults.get('model_names') or '')[:120]
    defaults['theme_mode'] = 'NEON' if str(defaults.get('theme_mode')).upper() == 'NEON' else 'NORMAL'
    defaults['anti_block_enabled'] = bool(defaults.get('anti_block_enabled', True))
    defaults['history_sort_newest'] = bool(defaults.get('history_sort_newest', True))
    defaults['ai_model'] = str(defaults.get('ai_model') or '')[:80]
    defaults['ai_mode'] = defaults.get('ai_mode') if defaults.get('ai_mode') in ('Auto', 'Sexting', 'Girlfriend', 'Whale') else 'Auto'
    defaults['ai_length'] = defaults.get('ai_length') if defaults.get('ai_length') in ('Short', 'Medium', 'Detailed') else 'Short'
    defaults['ai_cpu_only'] = bool(defaults.get('ai_cpu_only', False))
    defaults['notify_sound'] = bool(defaults.get('notify_sound', True))
    defaults['animated_bg'] = bool(defaults.get('animated_bg', True))
    defaults['poke_badges'] = bool(defaults.get('poke_badges', True))
    try: defaults['menu_volume'] = max(0, min(100, int(defaults.get('menu_volume', 100))))
    except Exception: defaults['menu_volume'] = 100
    _qr = defaults.get('quick_replies')
    _qr = [str(x or '')[:600] for x in _qr] if isinstance(_qr, list) else []
    defaults['quick_replies'] = (_qr + [''] * 9)[:9]
    try:
        defaults['repoke_timer_seconds'] = max(10, min(3600, int(defaults.get('repoke_timer_seconds', 180))))
    except Exception:
        defaults['repoke_timer_seconds'] = 180
    # Restrict bindings to Ctrl+letter. This avoids dangerous/conflicting system keys.
    used = set()
    for key_name, fallback in (('shortcut_poke','Q'), ('shortcut_send','E'), ('shortcut_timer','T'), ('shortcut_draft','G')):
        value = str(defaults.get(key_name, fallback)).strip().upper()
        if len(value) != 1 or not value.isalpha() or value in used:
            value = fallback
        if value in used:
            value = next((chr(n) for n in range(ord('A'), ord('Z')+1) if chr(n) not in used), fallback)
        defaults[key_name] = value
        used.add(value)
    return defaults


def _remember_setting(key, value):
    """Store one tweak in settings.json right away (used by the small toggles)."""
    try:
        if app_settings.get(key) != value:
            app_settings[key] = value
            _save_app_settings()
    except Exception:
        pass


def _save_app_settings():
    global app_settings_storage_error
    try:
        APP_SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        temp_path = APP_SETTINGS_PATH.with_suffix('.tmp')
        settings = dict(app_settings)
        settings['save_profile_ids'] = bool(save_profile_ids)
        settings['repoke_timer_seconds'] = int(repoke_timer_seconds)
        settings['shortcut_poke'] = str(shortcut_poke)
        settings['shortcut_send'] = str(shortcut_send)
        settings['shortcut_timer'] = str(shortcut_timer)
        settings['shortcut_draft'] = str(shortcut_draft)
        settings['model_names'] = str(model_names)
        settings['theme_mode'] = 'NEON' if theme_mode == 'NEON' else 'NORMAL'
        temp_path.write_text(json.dumps(settings, indent=2), encoding='utf-8')
        os.replace(temp_path, APP_SETTINGS_PATH)
        app_settings_storage_error = ''
        return True
    except Exception as exc:
        app_settings_storage_error = str(exc)
        return False


app_settings = _load_app_settings()
save_profile_ids = True                  # fixed ON (see _load_app_settings)
repoke_timer_seconds = int(app_settings['repoke_timer_seconds'])
shortcut_poke = app_settings['shortcut_poke']
shortcut_send = app_settings['shortcut_send']
shortcut_timer = app_settings['shortcut_timer']
shortcut_draft = app_settings['shortcut_draft']
theme_mode = app_settings['theme_mode']          # remembered between launches
model_names = app_settings['model_names']      # the model's name(s), used by AI Summary to separate her facts from his
repoke_timers = {}  # profile_id -> monotonic deadline; timer state is session-local
pending_repoke_profiles = set()  # expired reminders stay highlighted until the chatter copies that fan's ID
repoke_timer_text_items = {}
repoke_timer_tick_running = False
app_settings_storage_error = ''
history_storage_error = ''
poke_state = {}
# ID-off mode keeps temporary name-based stages in memory only. They are never
# persisted and are discarded when the application exits.
session_poke_state = {}
rng = random.SystemRandom()
active_mode = 'ONLINE'
poke_in_progress = False
poke_cancel_requested = False
poke_cancel_armed = False
history_sort_newest = bool(app_settings['history_sort_newest'])
history_page_index = 0
HISTORY_PAGE_SIZE = 7

class PokeCancelled(Exception):
    pass

def find_fansmetric_window():
    """The FansMetric window you are working in. With two FansMetric windows (two accounts on two monitors): the one in
    front, else the one under the mouse, else the first."""
    try:
        candidates = find_fansmetric_windows()
    except Exception:
        candidates = []
    if not candidates:
        for w in gw.getAllWindows():
            t=(w.title or '').strip(); low=t.lower()
            if 'fansmetric' in low and 'personalizer' not in low and 'pokeflow' not in low:
                candidates.append(w)
    if len(candidates) > 1:
        try:
            u = ctypes.windll.user32
            fg = u.GetAncestor(u.GetForegroundWindow(), 2)
            for w in candidates:
                if int(getattr(w, '_hWnd', 0)) == fg:
                    return w
            class _PT(ctypes.Structure):
                _fields_ = [('x', ctypes.c_long), ('y', ctypes.c_long)]
            pt = _PT()
            u.GetCursorPos(ctypes.byref(pt))
            under = u.GetAncestor(u.WindowFromPoint(pt), 2)
            for w in candidates:
                if int(getattr(w, '_hWnd', 0)) == under:
                    return w
        except Exception:
            pass
    for w in candidates:
        if 'client' in (w.title or '').lower(): return w
    return candidates[0] if candidates else None

def _bracket_real_name(name):
    """Chats renamed by the team keep the real name in brackets: 'notes/no bgs Edit (John Russell)' -> 'John Russell',
    'dz2 (Rune Scape)' -> 'Rune Scape'. Kept as is: 'Mike (VIP)' (outside already looks like a name)."""
    m = re.match(r'^(.*?)\s*\(([^()]+)\)\s*$', name or '')
    if not m:
        return name
    outer, inner = m.group(1).strip(), m.group(2).strip()
    first_in = (re.findall(r'[^\W\d_]+', inner) or [''])[0]
    if re.search(r'(?:^|\s)edit$', outer, re.I) and len(first_in) >= 2:
        return inner                                      # FansMetric's renamed chat: '<label> Edit (<real name>)
    if len(first_in) < 2 or first_in.isupper() or not first_in[:1].isupper():
        return name                                       # '(VIP)', '(whale)', '(2)' are tags, not names
    first_out = (outer.split() or [''])[0]
    looks_tag = (not outer) or bool(re.search(r'[\d/\\|#:]', outer)) or first_out[:1].islower()
    return inner if looks_tag else name


def clean_first_name(raw_name):
    name=_bracket_real_name(raw_name.strip())
    name=re.sub(r'[\s._-]*\d[\d\s._-]*$','',name)
    name=re.sub(r'[._-]+',' ',name)
    name=''.join(ch if ch.isalpha() or ch.isspace() else ' ' for ch in name)
    name=re.sub(r'\s+',' ',name).strip()
    if not name: raise ValueError('The selected name was empty.')
    first=name.split()[0]
    return first[:1].upper()+first[1:].lower()

def point(window, rel): return (window.left+int(window.width*rel[0]), window.top+int(window.height*rel[1]))
def activate_fast(window):
    try:
        if getattr(window, 'isActive', False):
            return                                   # already in front: no activation or settle delay needed
    except Exception:
        pass
    try: window.activate()
    except Exception: pass
    time.sleep(.06)


def _virtual_screen():
    """(left, top, right, bottom) of ALL monitors together (the main monitor only if Windows can't tell)."""
    try:
        u = ctypes.windll.user32
        l, t = u.GetSystemMetrics(76), u.GetSystemMetrics(77)
        w, h = u.GetSystemMetrics(78), u.GetSystemMetrics(79)
        if w > 0 and h > 0:
            return int(l), int(t), int(l + w), int(t + h)
    except Exception:
        pass
    sw, sh = pyautogui.size()
    return 0, 0, int(sw), int(sh)


def _grab_desktop(bbox):
    """Screenshot of any desktop area, on any monitor (pyautogui.screenshot() only sees the main monitor)."""
    from PIL import ImageGrab
    return ImageGrab.grab(bbox=tuple(int(v) for v in bbox), all_screens=True)


def _on_main_screen(x, y):
    try:
        sw, sh = pyautogui.size()
        return 0 <= x < sw and 0 <= y < sh
    except Exception:
        return True


def _capture_window_image(window, normalize=True, return_info=False):
    """Capture the target window in memory with DPI-aware coordinate mapping.

    OCR can inspect the original physical-pixel crop (so small names remain legible),
    while input/click automation uses the normalized PyAutoGUI coordinate space.
    The full screenshot and crop are never written to disk.
    """
    from PIL import Image as PILImage
    screen = pyautogui.screenshot()
    crop = None
    try:
        coord_w, coord_h = pyautogui.size()
        coord_scale_x = screen.width / max(1, int(coord_w))
        coord_scale_y = screen.height / max(1, int(coord_h))
        # Use the actual window rectangle. Do not stretch a large, but not fully
        # maximized, window to the whole desktop: FansMetric can occupy nearly the
        # whole screen while still leaving the taskbar/desktop outside the window.
        # PyAutoGUI and OCR coordinates are reconciled later with these scale values.
        window_scale_x, window_scale_y = coord_scale_x, coord_scale_y
        x1 = int(round(float(window.left) * window_scale_x))
        y1 = int(round(float(window.top) * window_scale_y))
        x2 = int(round((float(window.left) + float(window.width)) * window_scale_x))
        y2 = int(round((float(window.top) + float(window.height)) * window_scale_y))
        cx_, cy_ = (x1 + x2) / 2, (y1 + y2) / 2
        if not (0 <= cx_ < screen.width and 0 <= cy_ < screen.height):
            # FansMetric is on ANOTHER monitor: the screenshot above only has the main one -> grab that window's
            # area from the whole desktop instead (the 2nd account's window used to come out 1 px wide).
            vl, vt, vr, vb = _virtual_screen()
            x1, y1 = max(vl, x1), max(vt, y1)
            x2, y2 = max(x1 + 1, min(vr, x2)), max(y1 + 1, min(vb, y2))
            crop = _grab_desktop((x1, y1, x2, y2))
        else:
            x1 = max(0, min(screen.width - 1, x1))
            y1 = max(0, min(screen.height - 1, y1))
            x2 = max(x1 + 1, min(screen.width, x2))
            y2 = max(y1 + 1, min(screen.height, y2))
            crop = screen.crop((x1, y1, x2, y2))
        physical_scale_x = crop.width / max(1.0, float(window.width))
        physical_scale_y = crop.height / max(1.0, float(window.height))
        if normalize:
            target = (max(1, int(round(window.width))), max(1, int(round(window.height))))
            if crop.size != target:
                resampling = getattr(PILImage, 'Resampling', PILImage)
                filt = getattr(resampling, 'LANCZOS', getattr(PILImage, 'LANCZOS', 1))
                normalized_image = crop.resize(target, filt)
                crop.close()
                crop = normalized_image
            result = crop.copy()
            if return_info:
                return result, {'scale_x': 1.0, 'scale_y': 1.0, 'crop_left_px': 0, 'crop_top_px': 0,
                                'screen_scale_x': coord_scale_x, 'screen_scale_y': coord_scale_y}
            return result
        result = crop.copy()
        info = {'scale_x': physical_scale_x, 'scale_y': physical_scale_y,
                'crop_left_px': x1, 'crop_top_px': y1,
                'screen_scale_x': coord_scale_x, 'screen_scale_y': coord_scale_y}
        if return_info:
            return result, info
        return result
    finally:
        try: screen.close()
        except Exception: pass
        if crop is not None:
            try: crop.close()
            except Exception: pass


def _context_menu_appeared(before, after, x, y):
    """Return True only when a right-click visibly opened a context menu.

    This guard matters because sending Enter when the menu did not open can activate
    the focused profile link. Compare the small area around the pointer before/after
    the right-click; a context menu changes thousands of pixels, while a hover state
    or pointer change changes far fewer.
    """
    try:
        from PIL import ImageChops
        if before is None or after is None:
            return False
        width, height = after.size
        box = (max(0, int(x)-60), max(0, int(y)-35),
               min(width, int(x)+220), min(height, int(y)+155))
        if box[2] <= box[0] or box[3] <= box[1]:
            return False
        before_crop = before.crop(box).convert('RGB')
        after_crop = after.crop(box).convert('RGB')
        diff = ImageChops.difference(before_crop, after_crop).convert('L')
        # Require a broad visible change, not just the cursor or link hover styling.
        changed = sum(count for value, count in enumerate(diff.histogram()) if value >= 8)
        return changed >= 1800
    except Exception:
        # Fail closed: do not send Down/Enter unless we can verify the menu opened.
        return False


# Screenshot-only OCR state. Captures and crops are held in memory only.
_screen_ocr_engine = None
_screen_ocr_kind = None
_screen_ocr_error = None
_screen_ocr_lock = threading.Lock()


def _get_screen_ocr_engine():
    """Load one supported RapidOCR backend once, serialized with startup warmup."""
    global _screen_ocr_engine, _screen_ocr_kind, _screen_ocr_error
    with _screen_ocr_lock:
        if _screen_ocr_engine is not None:
            return _screen_ocr_engine, _screen_ocr_kind
        if _screen_ocr_error:
            raise RuntimeError(_screen_ocr_error)
        errors = []
        try:
            from rapidocr_onnxruntime import RapidOCR
            _screen_ocr_engine = RapidOCR()
            _screen_ocr_kind = 'legacy'
            for attr, value in (('text_score', 0.25), ('min_height', 10), ('width_height_ratio', 12)):
                try:
                    if hasattr(_screen_ocr_engine, attr):
                        setattr(_screen_ocr_engine, attr, value)
                except Exception:
                    pass
            return _screen_ocr_engine, _screen_ocr_kind
        except Exception as exc:
            errors.append(f'rapidocr-onnxruntime: {exc}')
        try:
            from rapidocr import RapidOCR
            _screen_ocr_engine = RapidOCR(params={
                'Global.text_score': 0.25,
                'Global.min_height': 10,
                'Global.max_side_len': 3200,
                'Global.width_height_ratio': 12,
            })
            _screen_ocr_kind = 'modern'
            return _screen_ocr_engine, _screen_ocr_kind
        except Exception as exc:
            errors.append(f'rapidocr: {exc}')
        _screen_ocr_error = (
            'Screenshot text recognition is unavailable. Close PokeFlow and start it with START.bat '
            'so the OCR dependency can be installed. No profile was clicked and no poke stage was changed.'
        )
        raise RuntimeError(_screen_ocr_error + '\n\n' + '\n'.join(errors))

_ocr_run_lock = threading.RLock()


def _run_screen_ocr(image):
    with _ocr_run_lock:                              # one text reading at a time (badge reader vs. Ctrl+Q / Ctrl+G)
        return _run_screen_ocr_locked(image)


def _run_screen_ocr_locked(image):
    """Return rows as (quadrilateral, recognized text, confidence); no disk I/O."""
    import numpy as np
    engine, kind = _get_screen_ocr_engine()
    rgb = np.asarray(image.convert('RGB'))
    # Both supported RapidOCR families accept OpenCV-style BGR arrays.
    bgr = rgb[:, :, ::-1].copy()
    output = engine(bgr)
    if isinstance(output, tuple) and output:
        # New RapidOCR returns a structured result; legacy RapidOCR returns rows.
        if hasattr(output[0], 'txts') or hasattr(output[0], 'boxes'):
            output = output[0]
        elif isinstance(output[0], (list, tuple)):
            output = output[0]
    if isinstance(output, dict):
        boxes = output.get('boxes')
        if boxes is None:
            boxes = output.get('dt_boxes')
        texts = output.get('txts')
        if texts is None:
            texts = output.get('texts')
        scores = output.get('scores')
        if boxes is not None and texts is not None and scores is not None:
            return [(boxes[i], str(texts[i]), float(scores[i]))
                    for i in range(min(len(boxes), len(texts), len(scores)))]
    if hasattr(output, 'txts'):
        boxes = getattr(output, 'boxes', None)
        texts = getattr(output, 'txts', None)
        scores = getattr(output, 'scores', None)
        if boxes is not None and texts is not None and scores is not None:
            normalized = []
            for i in range(min(len(boxes), len(texts), len(scores))):
                try:
                    normalized.append((boxes[i], str(texts[i]), float(scores[i])))
                except Exception:
                    continue
            return normalized
    rows = getattr(output, 'res', None)
    if rows is None:
        rows = getattr(output, 'result', None)
    if rows is None:
        rows = output
    normalized = []
    if rows is None:
        return []
    try:
        for row in rows:
            try:
                if isinstance(row, dict):
                    box = row.get('box') or row.get('points')
                    text = row.get('text') or row.get('txt')
                    score = row.get('score', row.get('confidence', 0.0))
                else:
                    box, text, score = row[0], row[1], row[2]
                normalized.append((box, str(text), float(score)))
            except Exception:
                continue
    except Exception:
        return []
    return normalized


def _ocr_box_points(box):
    """Normalize quadrilateral and xyxy formats returned by OCR versions."""
    import numpy as np
    try:
        arr = np.asarray(box, dtype=float)
    except Exception:
        return []
    if arr.ndim == 2 and arr.shape[-1] == 2 and arr.shape[0] >= 4:
        return [(float(pt[0]), float(pt[1])) for pt in arr]
    flat = arr.reshape(-1).tolist()
    if len(flat) >= 8:
        return [(float(flat[i]), float(flat[i + 1])) for i in range(0, 8, 2)]
    if len(flat) == 4:
        x1, y1, x2, y2 = map(float, flat)
        return [(x1, y1), (x2, y1), (x2, y2), (x1, y2)]
    return []


_PROFILE_UI_WORDS = {
    'client', 'fansmetric', 'messages', 'onlyfans', 'chat', 'gallery', 'find',
    'available', 'now', 'online', 'offline', 'notifications', 'fan', 'info',
    'subscriptions', 'purchases', 'tips', 'select', 'account', 'help', 'settings',
    'view', 'more', 'send', 'reply', 'search', 'unread', 'pinned', 'priority',
    'open', 'link', 'new', 'tab', 'copy', 'clipboard',
    # the grey status line under the name ("Seen 9h ago", "Last seen ...", "Typing...") is never the name
    'seen', 'ago', 'last', 'typing', 'away', 'active',
}


def _clean_ocr_fragment(text):
    text = str(text or '').replace('\u200b', '').replace('\ufeff', '').strip()
    # FansMetric can display a secondary alias/status in parentheses beside the
    # actual profile name, e.g. "Dan (Rooster)". Keep only the primary label.
    # If OCR returns the parenthetical as a separate fragment, it is discarded.
    text = re.split(r'[\(\[\{]', text, maxsplit=1)[0].strip()
    if not text:
        return ''
    chars = []
    for ch in text:
        if ch.isalpha() or ch.isdigit() or ch.isspace() or ch in "._-'’":
            chars.append(ch)
        else:
            chars.append(' ')
    text = re.sub(r'\s+', ' ', ''.join(chars)).strip(" ._-'")
    if not text or not any(ch.isalpha() for ch in text) or len(text) > 48:
        return ''
    if any(word.casefold() in _PROFILE_UI_WORDS for word in text.split()):
        return ''
    if re.fullmatch(r'(?i)\d+\s*(s|sec|m|min|mins|h|hr|hrs|d|w|mo|y)', text):
        return ''                                   # a loose "9h" from "Seen 9h ago"
    return text


def _ocr_rows_show_context_menu(rows):
    """Detect a link context menu in the header crop and refuse to guess."""
    words = set()
    for _box, text, _score in rows:
        words.update(re.findall(r'[a-z]+', str(text).casefold()))
    return ({'open', 'link', 'new', 'tab'}.issubset(words)
            or {'copy', 'link', 'clipboard'}.issubset(words))


def _choose_profile_header(rows, width, height, band_top, band_left, scale, mode, allow_header_y_edge=False):
    """Select a high-confidence OCR text cluster on the active chat-title row."""
    expected_x = ONLINE_PROFILE_LINK_POINT[0] if mode == 'ONLINE' else OFFLINE_PROFILE_LINK_POINT[0]
    x_low, x_high = expected_x - .22, expected_x + .25
    # FansMetric's tab strip ("Steve - Chat", "bodhi ... - Chat", "Fans - OnlyFans") sits just above the chat title. Any text on
    # the same line as a tab title is a tab name, never the fan in the chat header.
    tab_lines = []
    for box, text, confidence in rows:
        if re.search(r'(?i)(?:[-\u2013\u2014])\s*chat\b|\bonlyfans\b|\bfansmetric\b', str(text or '')):
            try:
                pts = [(pt[0] / scale, pt[1] / scale) for pt in _ocr_box_points(box)]
                tcy = band_top + (min(p[1] for p in pts) + max(p[1] for p in pts)) / 2
                if tcy / height < .150:
                    tab_lines.append(tcy)
            except Exception:
                pass
    entries = []
    for box, text, confidence in rows:
        try:
            pts = [(pt[0] / scale, pt[1] / scale) for pt in _ocr_box_points(box)]
            xs, ys = [pt[0] for pt in pts], [pt[1] for pt in pts]
            left, right = band_left + min(xs), band_left + max(xs)
            top, bottom = band_top + min(ys), band_top + max(ys)
            cx, cy = (left + right) / 2, (top + bottom) / 2
            x_norm, y_norm = cx / width, cy / height
            confidence = max(0.0, min(1.0, float(confidence)))
        except Exception:
            continue
        if any(abs(cy - tl) <= height * .012 for tl in tab_lines):
            continue                                   # a tab title, not the chat header
        # Permit tall/loose OCR boxes through to clustering; some engines include
        # nearby UI pixels in a box. The final line center is re-estimated robustly.
        # The app's top-level window can have a different title-bar / DPI ratio on
        # different Windows displays. The short-name refinement uses a tightly
        # cropped header slot and permits its text center to sit a little higher.
        if allow_header_y_edge:
            if not (.095 <= y_norm <= .205):
                continue
        elif not (.112 <= y_norm <= .198):
            continue
        # The mode-specific normalized point approximates the LEFT edge of the
        # profile label, not its center. Filter on the OCR fragment's left edge;
        # ranking every glyph by center let the nearby back/close icons ('x') win
        # over the actual name on some screenshots. Long names still extend right.
        x_start_norm = left / max(1.0, float(width))
        if not (expected_x - .045 <= x_start_norm <= expected_x + .025) or confidence < .25:
            continue
        raw_text = str(text or '').strip()
        fragment = _clean_ocr_fragment(raw_text)
        if not fragment:
            continue
        # If OCR puts the primary name and a parenthetical alias in one bounding box
        # (e.g. "Dan (Rooster)"), trim the clickable box to the primary-name portion
        # as well. Otherwise a context-menu click can land on the alias even though
        # the text we type was correctly cleaned to "Dan".
        raw_prefix = re.split(r'[\(\[\{]', raw_text, maxsplit=1)[0].strip()
        if raw_prefix and len(raw_prefix) < len(raw_text):
            raw_ratio = max(.15, min(.95, len(raw_prefix) / max(1, len(raw_text))))
            right = min(right, left + (right - left) * raw_ratio)
            cx = (left + right) / 2
        entries.append({
            'text': fragment, 'score': confidence, 'left': left, 'right': right,
            'top': top, 'bottom': bottom, 'cx': cx, 'cy': cy,
        })
    if not entries:
        return None

    # Group by top alignment rather than vertical center. OCR sometimes assigns a
    # tall box to the first word of a name, even though its top aligns with the next.
    entries.sort(key=lambda e: (e['top'], e['left']))
    lines = []
    y_tolerance = max(6.0, height * .012)
    for entry in entries:
        line = next((ln for ln in lines if abs(statistics.median(e['top'] for e in ln['items']) - entry['top']) <= y_tolerance), None)
        if line is None:
            lines.append({'items': [entry]})
        else:
            line['items'].append(entry)

    candidates = []
    for line in lines:
        sorted_items = sorted(line['items'], key=lambda e: e['left'])
        clusters = []
        for entry in sorted_items:
            if not clusters:
                clusters.append([entry])
                continue
            gap = entry['left'] - clusters[-1][-1]['right']
            # Tight gap joins separate words in a name but avoids dragging in nearby
            # edit-pencil glyphs or toolbar labels.
            if gap <= max(8.0, width * .008):
                clusters[-1].append(entry)
            else:
                clusters.append([entry])
        for cluster in clusters:
            text = re.sub(r'\s+', ' ', ' '.join(e['text'] for e in cluster)).strip()
            try:
                first_name = clean_first_name(text)
            except Exception:
                continue
            left = min(e['left'] for e in cluster)
            right = max(e['right'] for e in cluster)
            # Robust y target uses median top and a capped median line height; this
            # prevents one oversized OCR box from making the click land under the name.
            line_top = statistics.median(e['top'] for e in cluster)
            typical_heights = [min(max(1.0, e['bottom'] - e['top']), height * .024) for e in cluster]
            line_height = statistics.median(typical_heights)
            cx, cy = (left + right) / 2, line_top + line_height / 2
            x_norm, y_norm = cx / width, cy / height
            if allow_header_y_edge:
                if not (.100 <= y_norm <= .195):
                    continue
            elif not (.128 <= y_norm <= .172):
                continue
            confidence = sum(e['score'] for e in cluster) / len(cluster)
            # expected_x is the left edge of the primary profile name. Rank by the
            # cluster's LEFT edge (not center), because names vary in length and
            # aliases/status text can sit immediately to their right.
            left_norm = left / max(1.0, float(width))
            rank = confidence * .20 - abs(left_norm - expected_x) * 4.0 - abs(y_norm - .151) * 1.2
            candidates.append((rank, confidence, text, first_name, (left, min(e['top'] for e in cluster), right, max(e['bottom'] for e in cluster)), (cx, cy)))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    best = candidates[0]
    # Ambiguous OCR is a hard stop rather than a guess at the active fan.
    if len(candidates) > 1 and best[0] - candidates[1][0] < .010:
        return None
    return {
        'text': best[2], 'first_name': best[3], 'confidence': best[1],
        'box': best[4], 'center': best[5],
    }

def _choose_auto_profile_header(rows, width, height, band_top, band_left, scale):
    """Identify ONLINE vs OFFLINE from one OCR pass over the active header strip."""
    candidates = []
    for candidate_mode in ('ONLINE', 'OFFLINE'):
        found = _choose_profile_header(
            rows, width, height, band_top, band_left, scale, candidate_mode
        )
        if not found:
            continue
        expected_x = (ONLINE_PROFILE_LINK_POINT[0] if candidate_mode == 'ONLINE'
                      else OFFLINE_PROFILE_LINK_POINT[0])
        left = float(found['box'][0])
        # Rank the expected header position, while retaining OCR confidence as the
        # primary signal. Online/offline header start regions are deliberately
        # separated so ordinary sidebar labels cannot satisfy both.
        rank = float(found.get('confidence', 0.0)) - abs(left / max(1.0, width) - expected_x) * .9
        found['mode'] = candidate_mode
        candidates.append((rank, candidate_mode, found))
    if not candidates:
        return None, None
    candidates.sort(key=lambda item: item[0], reverse=True)
    if len(candidates) > 1 and candidates[0][1] != candidates[1][1]:
        if candidates[0][0] - candidates[1][0] < .035:
            return None, None
    best_mode, best = candidates[0][1], candidates[0][2]
    return best, best_mode


def _refine_short_profile_name(window_image, selected):
    """Re-check a suspicious 1–2 character OCR result using a larger in-memory header crop.

    A previous version only accepted a refinement if it also returned 1–2 characters,
    which meant an incorrect initial result like ``K`` could never be replaced by the
    true longer header name (e.g. ``William``). It also skipped refinement after the
    focused probe. This implementation accepts a confident longer read and refuses to
    prepare a message if a short read cannot be independently confirmed.
    """
    try:
        current = clean_first_name(selected.get('first_name') or selected.get('text') or '')
        mode = str(selected.get('mode') or '').upper()
    except Exception:
        selected['name_uncertain'] = True
        return selected
    if len(current) > 2 or mode not in ('ONLINE', 'OFFLINE'):
        return selected

    from PIL import Image as PILImage, ImageOps, ImageEnhance
    width, height = window_image.size
    expected_x = ONLINE_PROFILE_LINK_POINT[0] if mode == 'ONLINE' else OFFLINE_PROFILE_LINK_POINT[0]
    # Cover the full header text line, including small vertical alignment differences
    # from Windows DPI scaling. Keep the horizontal crop anchored to the actual name,
    # not to whatever one-letter fragment the first OCR pass returned.
    x1 = max(0, int(width * (expected_x - .025)))
    x2 = min(width, int(width * (expected_x + .135)))
    y1 = max(0, int(height * .090))
    y2 = min(height, int(height * .205))
    crop = enlarged = gray = enhanced = enhanced_large = None
    candidates = []
    try:
        crop = window_image.crop((x1, y1, x2, y2)).convert('RGB')
        resampling = getattr(PILImage, 'Resampling', PILImage)
        filt = getattr(resampling, 'LANCZOS', getattr(PILImage, 'LANCZOS', 1))

        # First pass: upscale the focused name slot. Usually this resolves a mistaken
        # single character in one extra OCR call and keeps Ctrl+Q fast.
        enlarged = crop.resize((max(1, crop.width * 4), max(1, crop.height * 4)), filt)
        rows = _run_screen_ocr(enlarged)
        found = _choose_profile_header(
            rows, width, height, y1, x1, 4, mode, allow_header_y_edge=True
        )
        if found:
            refined = clean_first_name(found.get('first_name') or found.get('text') or '')
            score = float(found.get('confidence', 0.0))
            if refined and score >= .42:
                candidates.append((refined, score, found))
                # A longer primary-name result is much stronger evidence than a
                # one-letter fragment; accept it immediately if OCR confidence is OK.
                if len(refined) > 2:
                    selected.update(found)
                    selected['mode'] = mode
                    selected['first_name'] = refined
                    selected['name_uncertain'] = False
                    selected['short_name_refined'] = True
                    selected['name_detection_method'] = 'focused_ocr'
                    return selected
                # A short result is not accepted after only one crop pass: that was
                # the path that let a single OCR fragment such as 'K' be pasted for a
                # longer name. Short labels must agree across both independent reads.

        # Second pass only for unresolved/ambiguous short names. Contrast enhancement
        # makes white/light header text stand out, still without writing any image file.
        gray = ImageOps.grayscale(crop)
        gray = ImageOps.autocontrast(gray, cutoff=1)
        enhanced = ImageEnhance.Contrast(gray).enhance(1.6)
        enhanced_large = enhanced.resize(
            (max(1, enhanced.width * 4), max(1, enhanced.height * 4)), filt
        )
        rows = _run_screen_ocr(enhanced_large.convert('RGB'))
        found = _choose_profile_header(
            rows, width, height, y1, x1, 4, mode, allow_header_y_edge=True
        )
        if found:
            refined = clean_first_name(found.get('first_name') or found.get('text') or '')
            score = float(found.get('confidence', 0.0))
            if refined and score >= .42:
                candidates.append((refined, score, found))
                if len(refined) > 2:
                    selected.update(found)
                    selected['mode'] = mode
                    selected['first_name'] = refined
                    selected['name_uncertain'] = False
                    selected['short_name_refined'] = True
                    selected['name_detection_method'] = 'contrast_ocr'
                    return selected

        # Keep one-letter/two-letter names only if independent focused reads agree.
        short_reads = [item for item in candidates if len(item[0]) <= 2]
        if len(short_reads) >= 2 and short_reads[0][0].casefold() == short_reads[1][0].casefold():
            refined, score, found = max(short_reads, key=lambda item: item[1])
            if score >= .50:
                selected.update(found)
                selected['mode'] = mode
                selected['first_name'] = refined
                selected['name_uncertain'] = False
                selected['short_name_refined'] = True
                selected['name_detection_method'] = 'short_name_consensus'
                return selected

        # The OCR has only a fragment, and a focused read could not confirm it. Fail
        # closed instead of pasting an incorrect personalized message like "K".
        selected['name_uncertain'] = True
        selected['short_name_refined'] = False
        selected['name_uncertain_reason'] = (
            f"PokeFlow only recognized '{current}' in the profile header and could not "
            "confirm the full name. No message or poke stage was changed."
        )
        return selected
    except Exception:
        selected['name_uncertain'] = True
        selected['short_name_refined'] = False
        selected['name_uncertain_reason'] = (
            'PokeFlow could not confirm the short profile name from the header. '
            'No message or poke stage was changed.'
        )
        return selected
    finally:
        for image in (enhanced_large, enhanced, gray, enlarged, crop):
            if image is not None:
                try: image.close()
                except Exception: pass


def detect_profile_header(mode='AUTO'):
    """Capture the FansMetric header and recognize both the name and active layout.

    AUTO first OCRs one narrow, full-width title strip, allowing Online and Offline
    header positions to be classified in a single engine pass. If needed, it retries
    with a 2x enlargement and a high-contrast crop. No screenshot is written to disk.
    Pass ONLINE/OFFLINE to force the legacy mode-specific crop for diagnostics.
    """
    requested_mode = str(mode or 'AUTO').upper()
    auto_detect = requested_mode not in ('ONLINE', 'OFFLINE')
    win = find_fansmetric_window()
    if not win:
        raise RuntimeError('Could not find the FansMetric client window.')
    try:
        if getattr(win, 'isMinimized', False):
            win.restore()
    except Exception:
        pass
    activate_fast(win)
    _poke_sleep(.025)

    window_image = band = scaled_band = wide_band = wide_scaled_band = enhanced_source = enhanced_gray = enhanced_band = None
    detected_mode = requested_mode
    selected = None
    try:
        window_image, capture_info = _capture_window_image(win, normalize=False, return_info=True)
        window_image = window_image.convert('RGB')
        width, height = window_image.size
        if width < 400 or height < 250:
            raise RuntimeError('The FansMetric window is too small to identify the profile header safely.')
        band_top = int(height * .115)
        band_bottom = int(height * .190)

        if auto_detect:
            # Full-width only for the narrow chat-title row. Candidate selection is
            # constrained to the known online/offline title-column start positions.
            band_left, band_right = 0, width
            band = window_image.crop((band_left, band_top, band_right, band_bottom))
            rows = _run_screen_ocr(band)
            if _ocr_rows_show_context_menu(rows):
                raise RuntimeError('A FansMetric context menu appears to be open. Close it and retry Ctrl+Q; no name or poke stage was changed.')
            selected, detected_mode = _choose_auto_profile_header(rows, width, height, band_top, band_left, 1)

            if not selected:
                # If the broad strip missed a short/small header (especially one-letter
                # names), scan only the two known title slots at 3x. This is much more
                # legible than scaling the whole desktop-width strip and lets us infer
                # the layout from whichever slot returns a plausible primary name.
                resampling = getattr(Image, 'Resampling', Image)
                resize_filter = getattr(resampling, 'LANCZOS', getattr(Image, 'LANCZOS', 1))
                focus_results = []
                focus_top = band_top
                focus_bottom = min(height, int(height * .170))
                for candidate_mode in ('ONLINE', 'OFFLINE'):
                    expected_x = ONLINE_PROFILE_LINK_POINT[0] if candidate_mode == 'ONLINE' else OFFLINE_PROFILE_LINK_POINT[0]
                    focus_left = max(0, int(width * (expected_x - .020)))
                    focus_right = min(width, int(width * (expected_x + .120)))
                    focus_crop = focus_scaled = None
                    try:
                        focus_crop = window_image.crop((focus_left, focus_top, focus_right, focus_bottom))
                        focus_scaled = focus_crop.resize((max(1, focus_crop.width * 3), max(1, focus_crop.height * 3)), resize_filter)
                        focus_rows = _run_screen_ocr(focus_scaled)
                        if _ocr_rows_show_context_menu(focus_rows):
                            raise RuntimeError('A FansMetric context menu appears to be open. Close it and retry Ctrl+Q; no name or poke stage was changed.')
                        focus_found = _choose_profile_header(focus_rows, width, height, focus_top, focus_left, 3, candidate_mode)
                        if focus_found:
                            focus_found['mode'] = candidate_mode
                            focus_found['focused_probe'] = True
                            left_norm = float(focus_found['box'][0]) / max(1.0, width)
                            rank = float(focus_found.get('confidence', 0.0)) - abs(left_norm - expected_x) * .9
                            focus_results.append((rank, candidate_mode, focus_found))
                    finally:
                        for focus_image in (focus_scaled, focus_crop):
                            if focus_image is not None:
                                try: focus_image.close()
                                except Exception: pass
                if focus_results:
                    focus_results.sort(key=lambda item: item[0], reverse=True)
                    if len(focus_results) == 1 or focus_results[0][0] - focus_results[1][0] >= .035:
                        _rank, detected_mode, selected = focus_results[0]

            if not selected:
                resampling = getattr(Image, 'Resampling', Image)
                resize_filter = getattr(resampling, 'LANCZOS', getattr(Image, 'LANCZOS', 1))
                scaled_band = band.resize((max(1, band.width * 2), max(1, band.height * 2)), resize_filter)
                rows = _run_screen_ocr(scaled_band)
                if _ocr_rows_show_context_menu(rows):
                    raise RuntimeError('A FansMetric context menu appears to be open. Close it and retry Ctrl+Q; no name or poke stage was changed.')
                selected, detected_mode = _choose_auto_profile_header(rows, width, height, band_top, band_left, 2)

            if not selected:
                from PIL import ImageOps, ImageEnhance
                enhanced_source = band.convert('L')
                enhanced_gray = ImageOps.autocontrast(enhanced_source, cutoff=1)
                enhanced_gray = ImageOps.invert(enhanced_gray)
                enhanced_gray = ImageEnhance.Contrast(enhanced_gray).enhance(1.25)
                enhanced_band = enhanced_gray.convert('RGB').resize(
                    (max(1, enhanced_gray.width * 3), max(1, enhanced_gray.height * 3)), resize_filter)
                rows = _run_screen_ocr(enhanced_band)
                if _ocr_rows_show_context_menu(rows):
                    raise RuntimeError('A FansMetric context menu appears to be open. Close it and retry Ctrl+Q; no name or poke stage was changed.')
                selected, detected_mode = _choose_auto_profile_header(rows, width, height, band_top, band_left, 3)
        else:
            detected_mode = requested_mode
            expected_x = ONLINE_PROFILE_LINK_POINT[0] if detected_mode == 'ONLINE' else OFFLINE_PROFILE_LINK_POINT[0]
            band_left = max(0, int(width * (expected_x - .17)))
            band_right = min(width, int(width * (expected_x + .18)))
            band = window_image.crop((band_left, band_top, band_right, band_bottom))
            rows = _run_screen_ocr(band)
            if _ocr_rows_show_context_menu(rows):
                raise RuntimeError('A FansMetric context menu appears to be open. Close it and retry Ctrl+Q; no name or poke stage was changed.')
            selected = _choose_profile_header(rows, width, height, band_top, band_left, 1, detected_mode)

            if not selected:
                resampling = getattr(Image, 'Resampling', Image)
                resize_filter = getattr(resampling, 'LANCZOS', getattr(Image, 'LANCZOS', 1))
                scaled_band = band.resize((max(1, band.width * 2), max(1, band.height * 2)), resize_filter)
                rows = _run_screen_ocr(scaled_band)
                if _ocr_rows_show_context_menu(rows):
                    raise RuntimeError('A FansMetric context menu appears to be open. Close it and retry Ctrl+Q; no name or poke stage was changed.')
                selected = _choose_profile_header(rows, width, height, band_top, band_left, 2, detected_mode)

            if not selected:
                wide_band = window_image.crop((0, band_top, width, band_bottom))
                rows = _run_screen_ocr(wide_band)
                if _ocr_rows_show_context_menu(rows):
                    raise RuntimeError('A FansMetric context menu appears to be open. Close it and retry Ctrl+Q; no name or poke stage was changed.')
                selected = _choose_profile_header(rows, width, height, band_top, 0, 1, detected_mode)

            if not selected:
                if wide_band is None:
                    wide_band = window_image.crop((0, band_top, width, band_bottom))
                wide_scaled_band = wide_band.resize((max(1, wide_band.width * 2), max(1, wide_band.height * 2)), resize_filter)
                rows = _run_screen_ocr(wide_scaled_band)
                if _ocr_rows_show_context_menu(rows):
                    raise RuntimeError('A FansMetric context menu appears to be open. Close it and retry Ctrl+Q; no name or poke stage was changed.')
                selected = _choose_profile_header(rows, width, height, band_top, 0, 2, detected_mode)

            if not selected:
                from PIL import ImageOps, ImageEnhance
                enhanced_source = window_image.crop((band_left, band_top, band_right, band_bottom)).convert('L')
                enhanced_gray = ImageOps.autocontrast(enhanced_source, cutoff=1)
                enhanced_gray = ImageOps.invert(enhanced_gray)
                enhanced_gray = ImageEnhance.Contrast(enhanced_gray).enhance(1.25)
                enhanced_band = enhanced_gray.convert('RGB').resize(
                    (max(1, enhanced_gray.width * 3), max(1, enhanced_gray.height * 3)), resize_filter)
                rows = _run_screen_ocr(enhanced_band)
                if _ocr_rows_show_context_menu(rows):
                    raise RuntimeError('A FansMetric context menu appears to be open. Close it and retry Ctrl+Q; no name or poke stage was changed.')
                selected = _choose_profile_header(rows, width, height, band_top, band_left, 3, detected_mode)

        if not selected:
            raise RuntimeError(
                'PokeFlow could not confidently recognize the active profile name and layout. '
                'No profile click was attempted and no poke stage was changed. Make sure the chat header '
                'is visible, then retry Ctrl+Q.'
            )
        if detected_mode not in ('ONLINE', 'OFFLINE'):
            detected_mode = selected.get('mode')
        if detected_mode not in ('ONLINE', 'OFFLINE'):
            raise RuntimeError('PokeFlow could not determine whether the active chat is Online or Offline. No poke stage was changed.')
        selected['mode'] = detected_mode
        selected = _refine_short_profile_name(window_image, selected)
        left, top, right, bottom = selected['box']
        cx, cy = selected['center']
        screen_cx = (capture_info['crop_left_px'] + cx) / max(.001, capture_info['screen_scale_x'])
        screen_cy = (capture_info['crop_top_px'] + cy) / max(.001, capture_info['screen_scale_y'])
        left_local = (capture_info['crop_left_px'] + left) / max(.001, capture_info['screen_scale_x']) - float(win.left)
        right_local = (capture_info['crop_left_px'] + right) / max(.001, capture_info['screen_scale_x']) - float(win.left)
        top_local = (capture_info['crop_top_px'] + top) / max(.001, capture_info['screen_scale_y']) - float(win.top)
        bottom_local = (capture_info['crop_top_px'] + bottom) / max(.001, capture_info['screen_scale_y']) - float(win.top)
        selected.update({
            'box': (left_local, top_local, right_local, bottom_local),
            'screen_box': (
                (capture_info['crop_left_px'] + left) / max(.001, capture_info['screen_scale_x']),
                (capture_info['crop_top_px'] + top) / max(.001, capture_info['screen_scale_y']),
                (capture_info['crop_left_px'] + right) / max(.001, capture_info['screen_scale_x']),
                (capture_info['crop_top_px'] + bottom) / max(.001, capture_info['screen_scale_y']),
            ),
            'screen_point': (int(round(screen_cx)), int(round(screen_cy))),
            'window_origin': (int(win.left), int(win.top)),
            'window_size': (int(round(win.width)), int(round(win.height))),
        })
        return selected
    finally:
        for image in (enhanced_band, enhanced_gray, enhanced_source, wide_scaled_band, wide_band, scaled_band, band, window_image):
            if image is not None:
                try:
                    image.close()
                except Exception:
                    pass

def copy_name_from_target(header_target):
    """Drag-select and copy text using the OCR-detected name bounding box.

    The screenshot decides where to start/end; no fixed-width coordinates are used.
    A real left-button drag crosses the observed text instead of clicking the profile
    link. Clipboard contents are validated and then the user's previous clipboard is
    restored.
    """
    if not header_target or not header_target.get('screen_point') or not header_target.get('box'):
        raise RuntimeError('A verified screenshot bounding box is required before copying the name.')
    win = find_fansmetric_window()
    if not win:
        raise RuntimeError('Could not find the FansMetric client window.')
    try:
        if getattr(win, 'isMinimized', False):
            win.restore()
    except Exception:
        pass
    activate_fast(win)
    _poke_sleep(.06)

    old_clip = pyperclip.paste()
    mouse_is_down = False
    try:
        sentinel = f'__POKEFLOW_NAME_COPY_CHECK_{time.time_ns()}__'
        pyperclip.copy(sentinel)
        sentinel_deadline = time.monotonic() + .4
        while time.monotonic() < sentinel_deadline:
            if pyperclip.paste().strip() == sentinel:
                break
            _poke_sleep(.01)
        else:
            raise RuntimeError('Could not safely initialize the clipboard for name verification.')

        left, top, right, bottom = header_target['box']
        origin_x, origin_y = header_target['window_origin']
        width = max(2.0, right - left)
        # Start a couple pixels before the text and finish a couple after it, at the
        # OCR-estimated text midline. This is a genuine drag even for a very short name.
        y = int(header_target['screen_point'][1])
        start_x = int(origin_x + max(0.0, left - 2.0))
        end_x = int(origin_x + right + 2.0)
        if end_x - start_x < 7:
            end_x = start_x + 7
        screen_w, _ = pyautogui.size()
        end_x = min(max(1, screen_w - 2), end_x)
        if end_x <= start_x:
            raise RuntimeError('The detected name is too close to the screen edge for safe selection.')

        pyautogui.moveTo(start_x, y, duration=.04)
        _poke_sleep(.02)
        pyautogui.mouseDown(button='left')
        mouse_is_down = True
        pyautogui.moveTo(end_x, y, duration=.18)
        pyautogui.mouseUp(button='left')
        mouse_is_down = False
        _poke_sleep(.07)
        _check_poke_cancel()
        pyautogui.hotkey('ctrl', 'c')

        deadline = time.monotonic() + .9
        raw = ''
        while time.monotonic() < deadline:
            _check_poke_cancel()
            try:
                raw = pyperclip.paste().strip()
            except Exception:
                raw = ''
            if raw and raw != sentinel:
                break
            _poke_sleep(.025)
        if not raw or raw == sentinel or len(raw) > 120 or '\n' in raw or '\r' in raw:
            raise RuntimeError('The detected name could not be copied safely. No poke stage was changed.')
        name = clean_first_name(raw)
        if name.casefold() in {
            'babe', 'fansmetric', 'client', 'pokeflow', 'personalizer', 'messages',
            'gallery', 'find', 'read', 'subscribe', 'subscribed', 'online', 'offline',
            'available', 'now', 'notifications', 'chat', 'onlyfans',
        }:
            raise RuntimeError('The copied text looks like interface text rather than a spender name. No poke stage was changed.')
        return name
    finally:
        if mouse_is_down:
            try: pyautogui.mouseUp(button='left')
            except Exception: pass
        try: pyperclip.copy(old_clip)
        except Exception: pass


# FansMetric copies either onlyfans.com/u123456789 (numeric) or onlyfans.com/username (fans who set a username).
_PROFILE_LINK_RE = re.compile(r'(?:https?://)?(?:www\.)?onlyfans\.com/([A-Za-z0-9][A-Za-z0-9_.-]{1,59})(?:[/?#\s]|$)', re.I)
_NON_PROFILE_PATHS = {'my', 'chats', 'notifications', 'collections', 'help', 'login', 'signup', 'terms', 'privacy',
                      'posts', 'search', 'settings', 'bookmarks', 'lists', 'subscriptions', 'support', 'queue'}


def copy_profile_id(mode, header_target):
    """Right-click the OCR-detected profile name and copy its unique profile URL."""
    win = find_fansmetric_window()
    if not win:
        raise RuntimeError('Could not find the FansMetric client window.')
    if not header_target or not header_target.get('screen_point'):
        raise RuntimeError('A verified profile-name target is required before copying its ID.')
    try:
        if getattr(win, 'isMinimized', False):
            win.restore()
    except Exception:
        pass
    # detect_profile_header already activated this same window; avoid a second
    # activation/settle delay before copying the URL.
    old_clip = pyperclip.paste()
    click_x, click_y = header_target['screen_point']
    screen_box = header_target.get('screen_box')
    if screen_box:
        left, top, right, bottom = screen_box
    else:
        left, top, right, bottom = header_target['box']
        left += float(win.left); right += float(win.left)
    width = max(1.0, right - left)
    # Both points are inside the OCR-detected word box and away from the edit icon.
    # screen_box is already converted to PyAutoGUI's absolute coordinate space.
    click_points = [
        (int(click_x), int(click_y)),
        (int(left + min(width * .30, max(2.0, width - 2))), int(click_y)),
    ]
    menu_open = False
    right_mouse_is_down = False
    try:
        for x, y in click_points:
            _check_poke_cancel()
            sentinel = f'__POKEFLOW_PROFILE_LINK_CHECK_{time.time_ns()}__'
            pyperclip.copy(sentinel)
            deadline = time.monotonic() + .35
            while time.monotonic() < deadline:
                if pyperclip.paste().strip() == sentinel:
                    break
                _poke_sleep(.01)
            else:
                continue

            pyautogui.moveTo(x, y, duration=.015)
            _poke_sleep(.01)
            main_scr = _on_main_screen(x, y)                  # 2nd monitor: grab around the mouse from the whole desktop
            around = (int(x) - 80, int(y) - 50, int(x) + 260, int(y) + 190)
            before = pyautogui.screenshot() if main_scr else _grab_desktop(around)
            try:
                pyautogui.mouseDown(button='right')
                right_mouse_is_down = True
                _poke_sleep(.025)
            finally:
                pyautogui.mouseUp(button='right')
                right_mouse_is_down = False
            menu_visible = False
            try:
                # Check as soon as the menu can appear instead of always waiting the full delay;
                # same pixel test as before, just polled (45 ms, then 100 ms, then 160 ms).
                for wait in (.045, .055, .06):
                    _poke_sleep(wait)
                    after = pyautogui.screenshot() if main_scr else _grab_desktop(around)
                    try:
                        if main_scr:
                            coord_w, coord_h = pyautogui.size()
                            px = int(round(x * after.width / max(1, coord_w)))
                            py = int(round(y * after.height / max(1, coord_h)))
                        else:
                            px, py = 80, 50
                        menu_visible = _context_menu_appeared(before, after, px, py)
                    finally:
                        try: after.close()
                        except Exception: pass
                    if menu_visible:
                        break
            finally:
                try: before.close()
                except Exception: pass

            if not menu_visible:
                try: _safe_esc()
                except Exception: pass
                _poke_sleep(.05)
                continue

            menu_open = True
            _check_poke_cancel()
            pyautogui.press('down')
            _poke_sleep(.03)
            pyautogui.press('down')
            _poke_sleep(.03)
            pyautogui.press('enter')
            _poke_sleep(.02)

            deadline = time.monotonic() + .70
            raw = ''
            match = None
            while time.monotonic() < deadline:
                _check_poke_cancel()
                raw = pyperclip.paste().strip()
                match = _PROFILE_LINK_RE.search(raw)
                if match and match.group(1).casefold() in _NON_PROFILE_PATHS:
                    match = None
                if match and raw != sentinel:
                    break
                time.sleep(.01)
            menu_open = False
            if match and raw != sentinel:
                return match.group(1).casefold()
            raise RuntimeError(
                'The context menu opened, but the profile link was not copied. '
                'No poke stage was changed. PokeFlow will not press Enter a second time.'
            )

        raise RuntimeError(
            'Could not verify that the context menu opened on the detected profile name. '
            'No Down/Enter keys were sent and no poke stage was changed. Retry Ctrl+Q with the chat header visible.'
        )
    finally:
        if right_mouse_is_down:
            try: pyautogui.mouseUp(button='right')
            except Exception: pass
        if menu_open:
            try: _safe_esc()
            except Exception: pass
        try: pyperclip.copy(old_clip)
        except Exception: pass


def _profile_state_key(profile_id):
    """Validate and normalize the unique FansMetric profile ID used for poke history."""
    key=str(profile_id or '').strip().casefold()
    if not re.fullmatch(r'u\d+|[a-z0-9][a-z0-9_.-]{1,59}', key) or key in _NON_PROFILE_PATHS:
        raise ValueError('A valid profile ID is required to track poke history safely.')
    return key

def _now_iso():
    return datetime.now().astimezone().isoformat(timespec='seconds')

def _parse_iso_timestamp(value):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value))
        return dt.timestamp()
    except Exception:
        return None

def _load_poke_state():
    """Load persistent per-profile history; malformed entries are safely skipped."""
    loaded = {}
    try:
        raw = json.loads(POKE_HISTORY_PATH.read_text(encoding='utf-8'))
        profiles = raw.get('profiles', {}) if isinstance(raw, dict) else {}
        if not isinstance(profiles, dict):
            return loaded
        for raw_id, record in profiles.items():
            try:
                key = _profile_state_key(raw_id)
                if not isinstance(record, dict):
                    continue
                stage = max(0, min(3, int(record.get('stage', 0))))
                used_raw = record.get('used', {})
                used = {}
                for n in (1, 2, 3):
                    values = used_raw.get(str(n), used_raw.get(n, [])) if isinstance(used_raw, dict) else []
                    used[n] = {int(v) for v in values if str(v).isdigit() and 0 <= int(v) < 10}
                loaded[key] = {
                    'stage': stage,
                    'used': used,
                    'name': str(record.get('name', '') or '')[:120],
                    'first_seen_at': record.get('first_seen_at') or _now_iso(),
                    'last_prepared_at': record.get('last_prepared_at'),
                    'last_prepared_stage': max(0, min(3, int(record.get('last_prepared_stage', stage) or 0))),
                    'last_sent_at': record.get('last_sent_at'),
                    'last_sent_stage': max(0, min(3, int(record.get('last_sent_stage', 0) or 0))),
                }
                try:
                    if record.get('spent') is not None:
                        loaded[key]['spent'] = float(record['spent'])
                except Exception:
                    pass
                for _k in ('last_spend', 'stats_at'):
                    if record.get(_k):
                        loaded[key][_k] = str(record[_k])[:40]
            except Exception:
                continue
    except FileNotFoundError:
        pass
    except Exception:
        # Do not prevent startup because a history file is missing or damaged.
        pass
    return loaded

def _save_poke_state():
    """Atomically persist poke state under the current user's local app data."""
    global history_storage_error
    try:
        payload = {'version': 1, 'profiles': {}}
        for key, state in poke_state.items():
            payload['profiles'][key] = {
                'stage': int(state.get('stage', 0)),
                'used': {str(n): sorted(int(v) for v in state.get('used', {}).get(n, set())) for n in (1, 2, 3)},
                'name': str(state.get('name', '') or '')[:120],
                'first_seen_at': state.get('first_seen_at') or _now_iso(),
                'last_prepared_at': state.get('last_prepared_at'),
                'last_prepared_stage': int(state.get('last_prepared_stage', 0)),
                'last_sent_at': state.get('last_sent_at'),
                'last_sent_stage': int(state.get('last_sent_stage', 0)),
            }
            if state.get('spent') is not None:                    # Fan Info numbers seen in his chat (reader)
                payload['profiles'][key]['spent'] = float(state['spent'])
            for _k in ('last_spend', 'stats_at'):
                if state.get(_k):
                    payload['profiles'][key][_k] = str(state[_k])[:40]
        POKE_HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
        temp_path = POKE_HISTORY_PATH.with_suffix('.tmp')
        temp_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(temp_path, POKE_HISTORY_PATH)
        history_storage_error = ''
        return True
    except Exception as exc:
        history_storage_error = str(exc)
        return False

# Loaded once before the interface appears; history persists across restarts.
poke_state.update(_load_poke_state())

def _new_stage_state(name=''):
    return {
        'stage': 0,
        'used': {1: set(), 2: set(), 3: set()},
        'name': str(name or '')[:120],
        'first_seen_at': _now_iso(),
        'last_prepared_at': None,
        'last_prepared_stage': 0,
        'last_sent_at': None,
        'last_sent_stage': 0,
    }


def _stage_data(profile_id):
    key=_profile_state_key(profile_id)
    if key not in poke_state:
        poke_state[key] = _new_stage_state()
    return poke_state[key]


def _session_stage_data(name):
    # Without IDs, temporary stage tracking uses the OCR name only. Same-name
    # profiles can share a stage in this optional mode; no ID or history is saved.
    key = ' '.join(str(name or '').strip().casefold().split()) or 'unknown'
    if key not in session_poke_state:
        session_poke_state[key] = _new_stage_state(name)
    return session_poke_state[key]

def _tag_account(state):
    """Remember on which OnlyFans account (FansMetric window) this fan was poked. True when it changed."""
    acct = _current_account()
    if acct and state.get('account') != acct:
        state['account'] = acct
        return True
    return False


def register_profile_id(profile_id):
    key = _profile_state_key(profile_id)
    is_new = key not in poke_state
    state = _stage_data(key)
    if _tag_account(state) or is_new:
        _save_poke_state()
    return state

def update_profile_name(profile_id, name):
    state = _stage_data(profile_id)
    state['name'] = str(name or '').strip()[:120]
    _save_poke_state()


def record_successful_send(profile_id):
    if not save_profile_ids or not profile_id:
        return
    state = _stage_data(profile_id)
    state['last_sent_at'] = _now_iso()
    state['last_sent_stage'] = int(state.get('stage', 0))
    _tag_account(state)
    _save_poke_state()

_ai_poke = {'ready': {1: [], 2: [], 3: []}, 'state': 'off', 'secs': {}}
AI_POKE_BASE = 1000                     # 'used' numbers >= 1000 = this session's AI messages (0-9 = the built-in ones)


def _poke_pool(poke_number):
    """[(number, text)] Ctrl+Q picks from: this session's AI messages for the stage once they are ready, else the
    30 built-in ones (also always used on PCs without AI)."""
    ai = _ai_poke['ready'].get(poke_number) or []
    if ai:
        return [(AI_POKE_BASE + i, t) for i, t in enumerate(ai)]
    return list(enumerate({1: POKE1, 2: POKE2, 3: POKE3}[poke_number]))


def get_next_poke(profile_id):
    state=_stage_data(profile_id)
    stage=state['stage']

    if stage >= 3:
        return None, 'Finished', None

    # Every successful use advances exactly one stage: Poke 1 -> Poke 2 -> Poke 3.
    # The actual message inside that stage is selected randomly.
    poke_number=stage+1
    pool=_poke_pool(poke_number)
    used=state['used'][poke_number]
    available=[(i, t) for i, t in pool if i not in used]
    if not available:
        available=pool
    idx, text=rng.choice(available)
    return text, f'Poke {poke_number}', idx

def commit_poke(profile_id,poke_number,idx,name=''):
    state=_stage_data(profile_id)
    state['used'][poke_number].add(idx)
    state['stage']=poke_number
    if name:
        state['name']=str(name).strip()[:120]
    state['last_prepared_at']=_now_iso()
    state['last_prepared_stage']=int(poke_number)
    _save_poke_state()

def get_next_session_poke(name):
    state = _session_stage_data(name)
    stage = int(state.get('stage', 0))
    if stage >= 3:
        return None, 'Finished', None
    poke_number = stage + 1
    pool = _poke_pool(poke_number)
    available = [(i, t) for i, t in pool if i not in state['used'][poke_number]] or pool
    idx, text = rng.choice(available)
    return text, f'Poke {poke_number}', idx


def commit_session_poke(name, poke_number, idx):
    state = _session_stage_data(name)
    state['used'][poke_number].add(idx)
    state['stage'] = poke_number
    state['name'] = str(name or '').strip()[:120]
    state['last_prepared_at'] = _now_iso()
    state['last_prepared_stage'] = int(poke_number)


def save_profile_id_and_start_repoke_timer(mode='AUTO'):
    """Save the currently visible fan ID and start a reminder, without preparing a poke."""
    global active_mode, poke_in_progress
    if poke_in_progress:
        set_status('PROFILE SAVE BUSY  •  TRY AGAIN IN A MOMENT', '#ff8bcf')
        return
    if not save_profile_ids:
        set_status('ENABLE SAVE FAN HISTORY BEFORE USING ID + TIMER', '#ff8bcf')
        return
    poke_in_progress = True
    try:
        _pb_log('Ctrl+T start')
        uchat, why, _uwin = None, '', find_fansmetric_window()
        if _uwin is not None:
            uchat, why = _ctrlq_uia(_uwin)                 # reader first: name + ID straight from FansMetric, no OCR
            _pb_log(f"Ctrl+T reader: {'name=%r id=%s' % (uchat['name'], uchat['id']) if uchat else 'not available - ' + why}")
        if uchat:
            detected_mode = _ctrlq_mode_from_title(_uwin, uchat['title'])
            try:
                name = clean_first_name(uchat['name'])
            except ValueError:
                name = ''
            if name.casefold() in _GENERIC_FAN_NAMES:
                name = ''
            profile_id = uchat['id']
        else:
            header_target = detect_profile_header('AUTO')
            detected_mode = header_target.get('mode')
            if detected_mode not in ('ONLINE', 'OFFLINE'):
                raise RuntimeError('Could not determine whether this is an Online or Offline chat. No ID was saved.')
            if header_target.get('name_uncertain'):
                raise RuntimeError(header_target.get('name_uncertain_reason') or 'Could not confidently confirm the profile name. No ID was saved.')
            if float(header_target.get('confidence', 0.0)) < .30:
                raise RuntimeError('Screenshot name recognition was not confident enough. No ID was saved.')
            name = clean_first_name(header_target.get('first_name') or header_target.get('text') or '')
            profile_id = copy_profile_id(detected_mode, header_target)
        already_saved = _profile_state_key(profile_id) in poke_state
        if already_saved:
            # Known fan: nothing is saved or overwritten again, only the timer (re)starts.
            if not str(_stage_data(profile_id).get('name') or '').strip():
                update_profile_name(profile_id, name)
        else:
            register_profile_id(profile_id)
            update_profile_name(profile_id, name)
        active_mode = detected_mode
        if uchat:
            _save_fan_stats(profile_id, uchat.get('stats'))
            _save_poke_state()
        start_repoke_timer_for_profile(profile_id, announce=False)
        shown_name = str(_stage_data(profile_id).get('name') or name or 'babe')
        set_status(f'{shown_name}  •  ' + ('ALREADY IN HISTORY  •  ' if already_saved else 'ID SAVED  •  ') + 'REPOKE TIMER RUNNING  •  NO POKE PREPARED',
                   '#49bde6' if theme_mode == 'NORMAL' else '#ff58d2')
    except Exception as e:
        set_status('PROFILE ID + TIMER FAILED', '#ff8bcf')
        _ui(messagebox.showwarning, APP_TITLE, "I couldn't save this profile ID and start its timer.\n\n" + str(e))
    finally:
        poke_in_progress = False



# ---- Ctrl+Q / Ctrl+S without OCR: read the open chat straight from FansMetric (same way the badges read the Fans list) ----
_cq = {'reader': None}


def _ctrlq_uia(win, focus_composer=False, timeout=2.5):
    """Returns (chat, why). chat = {'name', 'id', 'title', 'composer', 'focused'} of the chat the chatter is working in.
    Runs in its own short thread (UI Automation needs its own COM setup per thread). With focus_composer=True it also puts
    the keyboard focus into that chat's message box (no mouse)."""
    res = {'chat': None, 'why': 'timeout'}

    def work():
        try:
            import uiautomation as auto
            import uia_reader as _ur
        except Exception as exc:
            res['why'] = f'no UI Automation ({exc!r})'
            return
        try:
            with auto.UIAutomationInitializerInThread():
                rd = _ur.UiaReader()
                hwnd = int(getattr(win, '_hWnd', 0))
                data = None
                for _ in range(4):                       # right after opening a chat FansMetric may still be building it
                    data = rd.read_chat(hwnd)
                    if data['chats']:
                        break
                    time.sleep(.15)
                chats = data['chats'] if data else []
                if not chats:
                    res['why'] = f"no chat title found ({data['n'] if data else 0} elements)"
                    return
                ref = data.get('focus') or _cursor_pos()
                chat = chats[0]
                if len(chats) > 1 and ref:              # split view: the chat the chatter is in (focus, else mouse)
                    for c in chats:
                        l, t, r, b = c['title']
                        cr = c['composer'] or c['title']
                        if min(l, cr[0]) - 10 <= ref[0] <= max(r, cr[2]) + 10:
                            chat = c
                            break
                out = {k: chat[k] for k in ('name', 'id', 'title', 'composer')}
                out['messages'] = chat.get('messages') or []
                out['composer_text'] = ''
                try:
                    v = chat['composer_el'].GetCurrentPropertyValue(30045) if chat.get('composer_el') is not None else ''
                    v = (v if isinstance(v, str) else '').strip()
                    out['composer_text'] = '' if v.lower().startswith('type a message') else v
                except Exception:
                    pass
                out['stats'] = data.get('stats') or {}
                out['alerts'] = data.get('alerts') or {}
                out['focused'] = False
                res['why'] = ''
                if focus_composer and chat.get('composer_el') is not None:
                    try:
                        chat['composer_el'].SetFocus()
                        time.sleep(.04)
                        fr = rd._iuia().GetFocusedElement().CurrentBoundingRectangle
                        cl, ct, cr2, cb = chat['composer']
                        cx, cy = (fr.left + fr.right) // 2, (fr.top + fr.bottom) // 2
                        out['focused'] = bool(cl - 4 <= cx <= cr2 + 4 and ct - 4 <= cy <= cb + 4)   # focus really landed there
                        if not out['focused']:
                            res['why'] = 'focus landed elsewhere'
                    except Exception as exc:
                        res['why'] = f'focus failed ({exc!r})'
                res['chat'] = out
        except Exception as exc:
            res['why'] = repr(exc)[:160]

    _uia['busy'] = True
    try:
        th = threading.Thread(target=work, daemon=True, name='PokeFlow-CtrlQ-UIA')
        th.start()
        th.join(timeout)
    finally:
        _uia['busy'] = False
    return res['chat'], res['why']


def _ctrlq_mode_from_title(win, title_rect):
    """ONLINE / OFFLINE layout from where the chat title sits (only used to aim Ctrl+E's checks)."""
    try:
        rel = (title_rect[0] - win.left) / float(win.width)
        return 'ONLINE' if abs(rel - ONLINE_PROFILE_LINK_POINT[0]) <= abs(rel - OFFLINE_PROFILE_LINK_POINT[0]) else 'OFFLINE'
    except Exception:
        return 'ONLINE'


_GENERIC_FAN_NAMES = {'name', 'user', 'fan', 'subscriber', 'onlyfans', 'unknown',
                      # display names that start with a normal word, not a real name ("Your daddy", "The King", "Mr Big")
                      'your', 'youre', 'ur', 'urs', 'yours', 'my', 'the', 'a', 'an', 'i', 'im', 'its', 'hey', 'hi', 'hello',
                      'mr', 'mister', 'sir', 'big', 'lil', 'little', 'daddy', 'dad', 'papi', 'king', 'boss', 'baby', 'babe',
                      'bro', 'guy', 'man', 'boy', 'dude', 'real', 'just', 'not', 'no', 'mystery', 'anonymous', 'anon',
                      'deleted', 'private', 'secret', 'sexy', 'hot', 'horny', 'cock', 'dick', 'slave', 'pet', 'sub',
                      'submissive', 'servant', 'toy', 'fanboy', 'simp', 'lover', 'fan', 'biggest', 'number', 'one',
                      'loyal', 'good', 'bad', 'naughty', 'sweet', 'cute', 'handsome', 'sugar', 'stud', 'hubby', 'husband'}


def _poke_norm(text):
    t = re.sub(r'(?i)(?<![A-Za-z])babe(?![A-Za-z])', ' ', str(text or ''))
    t = re.sub(r'[^a-z0-9 ]+', ' ', t.lower())
    return ' '.join(t.split())


def _poke_already_sent(template, messages, name=''):
    """True when this poke text (with 'babe' or his name) is already one of the creator's messages in his chat."""
    import difflib
    a = _poke_norm(template)
    if name:
        a = ' '.join(w for w in a.split() if w != name.lower())
    if len(a) < 12:
        return False
    for m in messages or []:
        if m.get('side') != 'me':
            continue
        b = _poke_norm(m.get('text'))
        if name:
            b = ' '.join(w for w in b.split() if w != name.lower())
        if not b:
            continue
        if a == b or (len(b) >= 0.6 * len(a) and difflib.SequenceMatcher(None, a, b).ratio() >= 0.86):
            return True
    return False


def _save_fan_stats(profile_id, stats):
    """Fan Info numbers (spent on this model, last spend) seen while his chat was open -> shown on his badge later."""
    if not profile_id or not stats:
        return
    try:
        st = _stage_data(profile_id)
        if stats.get('total') is not None:
            st['spent'] = float(stats['total'])
        if stats.get('last_spend'):
            st['last_spend'] = str(stats['last_spend'])[:40]
        st['stats_at'] = _now_iso()
    except Exception:
        pass


def personalize(mode, start_repoke_timer=False, keep_babe=False):
    global prepared_message, prepared_profile_id, prepared_mode, active_mode, poke_in_progress, poke_cancel_requested, poke_cancel_armed
    if poke_in_progress:
        poke_cancel_requested = True
        set_status('POKE CANCELLING…', '#ff8bcf')
        return
    poke_in_progress = True
    poke_cancel_requested = False
    poke_cancel_armed = False
    _pb_hide_now(15.0)
    _pb_wait_idle()
    _pb_log('Ctrl+S start (keeps "babe")' if keep_babe else 'Ctrl+Q start')
    prior_clipboard = None
    clipboard_changed = False
    pasted = False
    try:
        # The first Ctrl+Q starts this run. Wait until that initiating key is released
        # before arming the second Ctrl+Q as a cancellation request.
        release_deadline = time.monotonic() + 1.5
        while _ctrl_q_combo_down() and time.monotonic() < release_deadline:
            time.sleep(.01)
        poke_cancel_armed = True
        threading.Thread(target=_watch_poke_cancel, daemon=True, name='PokeFlow-CtrlQ-CancelWatch').start()
        _check_poke_cancel()

        # Capture the active header in memory and read the name directly from OCR.
        # No left-click/drag or Ctrl+C is used for the name, so short names cannot
        # accidentally open the profile. The separate right-click context menu is
        # used only to obtain and validate the unique profile ID.
        uchat = None
        _uwin = find_fansmetric_window()
        if _uwin is not None:
            t_u = time.monotonic()
            uchat, why = _ctrlq_uia(_uwin)
            _pb_log(f"Ctrl+Q reader: {'name=%r id=%s box=%s' % (uchat['name'], uchat['id'], bool(uchat['composer'])) if uchat else 'not available - ' + why} "
                    f"({int((time.monotonic() - t_u) * 1000)} ms)")
        if uchat:
            _raw = uchat['name']
            try:
                _fn = clean_first_name(_raw)
            except ValueError:
                _fn = ''
            _generic = (not _fn) or _fn.casefold() in _GENERIC_FAN_NAMES or bool(re.fullmatch(r'u\d+', _raw.strip(), re.I))
            header_target = {'mode': _ctrlq_mode_from_title(_uwin, uchat['title']), 'first_name': _fn, 'text': _raw,
                             'confidence': 1.0, 'name_uncertain': _generic, 'uia': uchat}
        else:
            header_target=detect_profile_header('AUTO')
        mode = header_target.get('mode')
        if not uchat and not keep_babe and (header_target.get('name_uncertain') or float(header_target.get('confidence', 0.0)) < .30):
            _pb_log(f"Ctrl+Q name unsure on first read (conf={header_target.get('confidence')}); reading again")
            _poke_sleep(.15)
            try:
                again = detect_profile_header('AUTO')
                if again.get('mode') in ('ONLINE', 'OFFLINE') and not again.get('name_uncertain') and float(again.get('confidence', 0.0)) >= .30:
                    header_target = again; mode = again.get('mode')
            except PokeCancelled:
                raise
            except Exception:
                pass
        _pb_log(f"Ctrl+Q header: mode={mode} name={header_target.get('first_name')!r} conf={header_target.get('confidence')} uncertain={header_target.get('name_uncertain')}")
        if mode not in ('ONLINE', 'OFFLINE'):
            raise RuntimeError('Could not determine whether this is an Online or Offline chat. No poke stage was changed.')
        # A name that can't be read safely is no longer a stop: the ready-made message is used as it is,
        # with "babe" (the message's own greeting) instead of the name.
        name_unsure = bool(header_target.get('name_uncertain')) or bool(keep_babe)      # Ctrl+S: never use the name
        if active_mode != mode:
            active_mode = mode
            try: _ui(update_poke_status)
            except Exception: pass
        _check_poke_cancel()
        if float(header_target.get('confidence', 0.0)) < .30:
            name_unsure = True
        name = None
        if not name_unsure:
            try:
                name = clean_first_name(header_target.get('first_name') or header_target.get('text') or '')
            except ValueError:
                name = None
        shown_name = name or 'babe'
        track_profile_id = bool(save_profile_ids)
        if track_profile_id:
            profile_id = uchat['id'] if uchat else copy_profile_id(mode, header_target)     # reader: ID from the name's profile link
            _pb_log(f'Ctrl+Q id copied: {profile_id}')
            # Register immediately after ID capture so History includes identified fans
            # even if a later preparation step fails.
            profile_state=register_profile_id(profile_id)
            _check_poke_cancel()
            # The current visible header is authoritative. Do not replace it with
            # a previously stored label: older builds may have saved an OCR alias
            # (e.g. the parenthetical nickname) as the primary name.
            if name:
                update_profile_name(profile_id, name)
            _check_poke_cancel()
            message,poke,idx=get_next_poke(profile_id)
            if uchat:
                _save_fan_stats(profile_id, uchat.get('stats'))
                skipped = 0
                if message is not None and _poke_already_sent(message, uchat.get('messages'), name or ''):
                    # this exact poke is already in his chat: never send it twice - take another one of the same stage
                    pn = int(poke[-1])
                    group = _poke_pool(pn)
                    if group[0][0] >= AI_POKE_BASE:              # AI messages + the built-in ones as a last resort
                        group = group + list(enumerate({1: POKE1, 2: POKE2, 3: POKE3}[pn]))
                    used = _stage_data(profile_id)['used'][pn]
                    fresh = [(i, t) for i, t in group if not _poke_already_sent(t, uchat.get('messages'), name or '')]
                    pick = [(i, t) for i, t in fresh if i not in used] or fresh
                    skipped = 1
                    _pb_log(f'Ctrl+Q: {poke} text already in his chat - {len(fresh)} of {len(group)} not sent yet')
                    if not pick:
                        _pop_info(f"Already sent to {name or 'him'}", f"Every {poke} message is already in his chat - nothing pasted.")
                        set_status(f'{shown_name}: every {poke} already sent', '#ffd166'); return
                    idx, message = rng.choice(pick)
                if skipped:
                    _pop_info('Picked another message', f"That {poke} was already in his chat - a different one was pasted.", life=5.0)
        else:
            # Fast path: use OCR's name and skip right-click/context-menu ID capture.
            # No profile ID or history is written while the setting is OFF.
            profile_id=''
            message,poke,idx=get_next_session_poke(shown_name)
        if message is None:
            set_status(f'{shown_name}: all 3 pokes used', '#ffd166'); return

        if name:
            final=re.sub(r'(?i)(?<![A-Za-z])babe(?![A-Za-z])', name, message)
            if re.search(r'(?i)(?<![A-Za-z])babe(?![A-Za-z])', final):
                raise RuntimeError('Personalization validation failed: babe was not fully replaced.')
            if name.casefold() not in final.casefold():
                raise RuntimeError('Personalization validation failed: detected name is missing.')
        else:
            final = message                      # name not readable: keep the normal message with "babe"

        win=find_fansmetric_window()
        if not win: raise RuntimeError('Could not find the FansMetric client window.')
        _check_poke_cancel()
        activate_fast(win)
        focused = False
        if uchat:                                            # reader: focus the chat's message box directly, no mouse
            fchat, why = _ctrlq_uia(win, focus_composer=True)
            focused = bool(fchat and fchat.get('focused'))
            if not focused:
                _pb_log(f'Ctrl+Q reader: could not focus the message box ({why}) - clicking it instead')
        if focused:
            x, y = 'focus', 'box'
            _poke_sleep(.05)
        else:
            rel=OFFLINE_COMPOSER_CLICK if mode=='OFFLINE' else ONLINE_COMPOSER_CLICK
            x,y=point(win,rel)
            pyautogui.click(x,y)
            _poke_sleep(.04)
        pyautogui.hotkey('ctrl','a')
        _poke_sleep(.02)
        _check_poke_cancel()
        prior_clipboard=pyperclip.paste()
        pyperclip.copy(final); clipboard_changed=True
        _check_poke_cancel()
        pyautogui.hotkey('ctrl','v'); pasted=True
        _pb_log(f'Ctrl+Q pasted ({len(final)} chars) at {(x, y)} mode={mode}')
        time.sleep(.08)  # after paste, finish the transaction; do not report a false cancellation

        prepared_message=final
        prepared_profile_id=profile_id if track_profile_id else ''
        prepared_mode=mode
        if track_profile_id:
            commit_poke(profile_id, int(poke[-1]), idx, name or '')
            if start_repoke_timer:
                start_repoke_timer_for_profile(profile_id, announce=False)
            set_status(f'{shown_name}  •  {poke} ready  •  NOT SENT' + (('  •  KEPT "babe"' if keep_babe else '  •  NAME NOT READ, USED "babe"') if not name else '') + ('  •  REPOKE TIMER RUNNING' if start_repoke_timer else ''), '#ffe66d' if mode=='ONLINE' else '#9ff7ff')
        else:
            commit_session_poke(shown_name, int(poke[-1]), idx)
            set_status(f'{shown_name}  •  {poke} ready  •  ID SAVING OFF', '#a4aab5')
    except PokeCancelled:
        if clipboard_changed and not pasted and prior_clipboard is not None:
            try: pyperclip.copy(prior_clipboard)
            except Exception: pass
        set_status('POKE CANCELLED  •  no message prepared', '#ff8bcf')
    except Exception as e:
        _pb_log(f'Ctrl+Q error: {e!r}')
        set_status('Not changed', '#ff8bcf'); _ui(messagebox.showwarning, APP_TITLE, "I couldn't personalize this chat automatically.\n\n"+str(e))
    finally:
        poke_in_progress = False
        poke_cancel_armed = False
        poke_cancel_requested = False

# ----- UI / app identity / startup splash -----
ui_asset_dir = Path(__file__).with_name('ui_assets')
_EXTERNAL_SPLASH_MODE = os.environ.get('POKEFLOW_EXTERNAL_SPLASH') == '1'
POKEFLOW_LITE = os.environ.get('POKEFLOW_LITE') == '1'     # PokeFlow Lite: only Ctrl+Q, Ctrl+S and the hover poke badges, no window
_EXTERNAL_SPLASH_PROGRESS = Path(os.environ['POKEFLOW_SPLASH_PROGRESS']) if os.environ.get('POKEFLOW_SPLASH_PROGRESS') else None
_EXTERNAL_SPLASH_READY = Path(os.environ['POKEFLOW_SPLASH_READY']) if os.environ.get('POKEFLOW_SPLASH_READY') else None
_EXTERNAL_SPLASH_DISMISSED = Path(os.environ['POKEFLOW_SPLASH_DISMISSED']) if os.environ.get('POKEFLOW_SPLASH_DISMISSED') else None
_EXTERNAL_SPLASH_SHOWN = Path(os.environ['POKEFLOW_SPLASH_SHOWN']) if os.environ.get('POKEFLOW_SPLASH_SHOWN') else None
_external_ready_started = None


def _write_external_splash_state(percent, message, ready=False):
    """Send small progress updates to PokeFlow_Launcher without coupling app logic to it."""
    if not _EXTERNAL_SPLASH_MODE or _EXTERNAL_SPLASH_PROGRESS is None:
        return
    try:
        _EXTERNAL_SPLASH_PROGRESS.parent.mkdir(parents=True, exist_ok=True)
        temp = _EXTERNAL_SPLASH_PROGRESS.with_suffix('.tmp')
        temp.write_text(json.dumps({'percent': int(max(0, min(100, percent))), 'message': str(message), 'ready': bool(ready)}), encoding='utf-8')
        os.replace(temp, _EXTERNAL_SPLASH_PROGRESS)
    except Exception:
        pass
    if ready and _EXTERNAL_SPLASH_READY is not None:
        try:
            _EXTERNAL_SPLASH_READY.parent.mkdir(parents=True, exist_ok=True)
            _EXTERNAL_SPLASH_READY.write_text('ready', encoding='utf-8')
        except Exception:
            pass


# Give Windows a distinct taskbar grouping for PokeFlow instead of inheriting
# the generic python.exe identity/icon. Must be set before the first HWND.
try:
    if os.name == 'nt':
        _set_app_id = ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID
        _set_app_id.argtypes = [ctypes.c_wchar_p]
        _set_app_id.restype = ctypes.c_long
        _set_app_id('Cone.PokeFlow.v30')
except Exception:
    pass

def _register_poppins():
    """Make the bundled Poppins usable inside this program only (nothing is installed on the PC)."""
    if os.name != 'nt':
        return False
    ok_any = False
    try:
        fdir = Path(__file__).with_name('tools') / 'fonts'
        for fn in ('Poppins-Regular.ttf', 'Poppins-Medium.ttf', 'Poppins-Bold.ttf'):
            fp = fdir / fn
            if fp.is_file():
                # FR_PRIVATE = 0x10: visible to this process only
                if ctypes.windll.gdi32.AddFontResourceExW(str(fp), 0x10, 0):
                    ok_any = True
    except Exception:
        return False
    return ok_any


_POPPINS_OK = _register_poppins()
root=tk.Tk()


def _tk_callback_error(exc, val, tb):
    import traceback
    _crash_note('Window error:\n' + ''.join(traceback.format_exception(exc, val, tb))[-2500:])
root.report_callback_exception = _tk_callback_error
try:
    TEXT_FONT = ('Poppins', 9) if (_POPPINS_OK and 'Poppins' in set(tkfont.families(root))) else ('Segoe UI', 10)
except Exception:
    TEXT_FONT = ('Segoe UI', 10)
root.title(f'{APP_TITLE} {VERSION}')
root.resizable(False,False)
root.configure(bg='#07101c')
_screen_w = root.winfo_screenwidth()
_screen_h = root.winfo_screenheight()
_root_x = max(0, (_screen_w - W) // 2)
_root_y = max(0, (_screen_h - H) // 2)
if _EXTERNAL_SPLASH_MODE:
    # The lightweight launcher covers import/startup time; keep the main window
    # hidden until it has finished drawing the initial page and received dismissal.
    root.geometry(f'{W}x{H}+{_root_x}+{_root_y}')
    root.withdraw()
else:
    # Directly launching PokeFlow.py still gets the integrated splash fallback.
    root.overrideredirect(True)
    root.geometry(f'{W}x{H}+{_root_x}+{_root_y}')

_app_icon_ico_path = ui_asset_dir / 'pokeflow_app.ico'
_app_icon_png_path = ui_asset_dir / 'pokeflow_app.png'
_root_icon_photo = None
try:
    if _app_icon_ico_path.exists():
        # iconbitmap uses the real multi-resolution ICO on Windows for the
        # title bar/taskbar, instead of inheriting python.exe's default icon.
        root.iconbitmap(default=str(_app_icon_ico_path))
        root.iconbitmap(str(_app_icon_ico_path))
except Exception:
    pass
try:
    if _app_icon_png_path.exists():
        _root_icon_photo = tk.PhotoImage(file=str(_app_icon_png_path))
        root.iconphoto(True, _root_icon_photo)
except Exception:
    _root_icon_photo = None

# A polished, themed startup screen. Pillow is used for real blurred glow and
# gradient artwork; the progress controls are native Canvas objects layered on it.
_startup_started = time.monotonic()
_startup_active = True
_startup_progress = 6
_startup_bar_photo = None
_startup_background_photo = None
_startup_logo_photo = None
_startup_mark_photo = None
_startup_bar_item = None
_startup_status_item = None
_startup_percent_item = None
_startup_canvas = tk.Canvas(root, width=W, height=H, highlightthickness=0, bd=0, bg='#07101c')
if not _EXTERNAL_SPLASH_MODE:
    _startup_canvas.place(x=0, y=0, relwidth=1, relheight=1)


def _startup_palette(theme=None):
    use_neon = (theme or theme_mode) == 'NEON'
    if use_neon:
        return {
            'bg': '#080817', 'panel': '#100b20', 'edge': '#ff45d4',
            'glow': '#ac39ff', 'accent': '#ff45d4', 'accent2': '#25dcff',
            'text': '#f7edff', 'muted': '#d1bde8', 'grid': '#29173c',
            'caption': '#190923', 'caption_edge': '#ff45d4'
        }
    return {
        'bg': '#07101c', 'panel': '#0b1727', 'edge': '#49bde6',
        'glow': '#1977cc', 'accent': '#2189f5', 'accent2': '#49d7ef',
        'text': '#eff7ff', 'muted': '#a9c5df', 'grid': '#13253a',
        'caption': '#081b2c', 'caption_edge': '#49bde6'
    }


def _startup_photo_background(theme=None):
    if Image is None or ImageTk is None:
        return None
    try:
        from PIL import ImageDraw, ImageFilter
        pal = _startup_palette(theme)
        scale = 2
        size = (W * scale, H * scale)
        image = Image.new('RGBA', size, pal['bg'])
        d = ImageDraw.Draw(image, 'RGBA')
        # Quiet technical grid and a few flowing curves echo the main app UI.
        grid = tuple(int(pal['grid'][i:i+2], 16) for i in (1, 3, 5)) + (118,)
        for x in range(0, size[0], 40 * scale):
            d.line((x, 0, x, size[1]), fill=grid, width=scale)
        for y in range(0, size[1], 40 * scale):
            d.line((0, y, size[0], y), fill=grid, width=scale)
        wave_a = tuple(int(pal['accent'][i:i+2], 16) for i in (1, 3, 5)) + (90,)
        wave_b = tuple(int(pal['accent2'][i:i+2], 16) for i in (1, 3, 5)) + (65,)
        for offset, color, amp in ((110, wave_a, 24), (150, wave_b, 15), (465, wave_a, 19)):
            points = []
            for x in range(-20, W + 21, 5):
                y = offset + amp * math.sin(x / 115.0) + 5 * math.sin(x / 41.0)
                points.append((int(x * scale), int(y * scale)))
            d.line(points, fill=color, width=scale)
        # Glass panel with an actual blurred halo around its border.
        box = (140*scale, 144*scale, 760*scale, 454*scale)
        glow_layer = Image.new('RGBA', size, (0, 0, 0, 0))
        gd = ImageDraw.Draw(glow_layer)
        edge_rgb = tuple(int(pal['edge'][i:i+2],16) for i in (1,3,5))
        glow_rgb = tuple(int(pal['glow'][i:i+2],16) for i in (1,3,5))
        gd.rounded_rectangle(box, radius=25*scale, outline=glow_rgb+(210,), width=5*scale)
        glow_layer = glow_layer.filter(ImageFilter.GaussianBlur(17*scale))
        image = Image.alpha_composite(image, glow_layer)
        panel_layer = Image.new('RGBA', size, (0, 0, 0, 0))
        pd = ImageDraw.Draw(panel_layer)
        pd.rounded_rectangle(box, radius=25*scale, fill=(*tuple(int(pal['panel'][i:i+2],16) for i in (1,3,5)), 246), outline=edge_rgb+(238,), width=2*scale)
        pd.rounded_rectangle((148*scale,152*scale,752*scale,446*scale), radius=19*scale,
                             outline=tuple(int(pal['accent2'][i:i+2],16) for i in (1,3,5))+(60,), width=scale)
        # Soft, understated highlight just inside the top edge.
        pd.line((175*scale, 157*scale, 725*scale, 157*scale), fill=edge_rgb+(110,), width=scale)
        image = Image.alpha_composite(image, panel_layer)
        image = image.convert('RGB').resize((W, H), Image.Resampling.LANCZOS).convert('RGBA')
        return ImageTk.PhotoImage(image, master=root)
    except Exception:
        return None


def _startup_logo_photo(theme=None):
    if Image is None or ImageTk is None:
        try:
            p = Path(__file__).with_name('PokeFlow_Logo_Normal.png')
            return tk.PhotoImage(file=str(p)) if p.exists() else None
        except Exception:
            return None
    try:
        use_neon = (theme or theme_mode) == 'NEON'
        p = Path(__file__).with_name('PokeFlow_Logo_Neon.png' if use_neon else 'PokeFlow_Logo_Normal_HD.png')
        if not p.exists():
            p = ui_asset_dir / ('logo_neon.png' if use_neon else 'logo_normal.png')
        with Image.open(p) as raw:
            logo = raw.convert('RGBA')
            logo.thumbnail((440, 100), Image.Resampling.LANCZOS)
            return ImageTk.PhotoImage(logo.copy(), master=root)
    except Exception:
        return None


def _render_startup_bar(percent, theme=None):
    if Image is None or ImageTk is None:
        return None
    try:
        from PIL import ImageDraw, ImageFilter, ImageChops
        pal = _startup_palette(theme)
        factor, bw, bh = 3, 500, 24
        size = (bw*factor, bh*factor)

        # Keep the empty track/frame separate from the fill. This prevents the
        # Lanczos resize from smearing the fill glow across the leading edge.
        track_hi = Image.new('RGBA', size, (0, 0, 0, 0))
        td = ImageDraw.Draw(track_hi)
        edge_rgb = tuple(int(pal['edge'][i:i+2], 16) for i in (1,3,5))
        td.rounded_rectangle((2*factor, 2*factor, (bw-2)*factor, (bh-2)*factor),
                             radius=10*factor, fill=(6,14,25,245),
                             outline=edge_rgb+(165,), width=factor)
        track = track_hi.resize((bw,bh), Image.Resampling.LANCZOS)

        overlay_hi = Image.new('RGBA', size, (0,0,0,0))
        inner_left, inner_top = 5*factor, 5*factor
        inner_right, inner_bottom = (bw-5)*factor, (bh-5)*factor
        max_fill = max(0, inner_right-inner_left)
        fill_w = int(max_fill * max(0,min(100,int(percent))) / 100)
        track_clip = Image.new('L', size, 0)
        ImageDraw.Draw(track_clip).rounded_rectangle(
            (inner_left, inner_top, inner_right, inner_bottom), radius=7*factor, fill=255)
        if fill_w > 2*factor:
            fill_right = min(inner_right, inner_left+fill_w)
            glow = Image.new('RGBA', size, (0,0,0,0))
            ImageDraw.Draw(glow).rounded_rectangle(
                (inner_left, inner_top, fill_right, inner_bottom), radius=7*factor,
                fill=tuple(int(pal['accent'][i:i+2],16) for i in (1,3,5))+(235,))
            glow = glow.filter(ImageFilter.GaussianBlur(7*factor))
            glow.putalpha(ImageChops.multiply(glow.getchannel('A'), track_clip))
            overlay_hi = Image.alpha_composite(overlay_hi, glow)

            mask = Image.new('L', size, 0)
            ImageDraw.Draw(mask).rounded_rectangle(
                (inner_left, inner_top, fill_right, inner_bottom), radius=7*factor, fill=255)
            gradient = Image.new('RGBA', size, (0,0,0,0))
            px = gradient.load()
            c1 = tuple(int(pal['accent'][i:i+2],16) for i in (1,3,5))
            c2 = tuple(int(pal['accent2'][i:i+2],16) for i in (1,3,5))
            for x in range(inner_left, fill_right+1):
                t = (x-inner_left)/max(1,fill_w)
                color = tuple(int(c1[k]*(1-t)+c2[k]*t) for k in range(3)) + (255,)
                for y in range(inner_top, inner_bottom+1):
                    px[x,y] = color
            fill_layer = Image.composite(gradient, Image.new('RGBA',size,(0,0,0,0)), mask)
            overlay_hi = Image.alpha_composite(overlay_hi, fill_layer)
            if fill_w > 20*factor:
                highlight_end = min(inner_right-2*factor, inner_left+fill_w-8*factor)
                if highlight_end > inner_left+6*factor:
                    ImageDraw.Draw(overlay_hi).line(
                        (inner_left+6*factor, inner_top+2*factor, highlight_end, inner_top+2*factor),
                        fill=(255,255,255,90), width=factor)

        # Lanczos can bleed a blurred edge by a pixel; clip the final-sized alpha
        # against the rounded inner track once more after downsampling.
        overlay = overlay_hi.resize((bw,bh), Image.Resampling.LANCZOS)
        final_clip = Image.new('L', (bw,bh), 0)
        ImageDraw.Draw(final_clip).rounded_rectangle((5,5,bw-5,bh-5), radius=7, fill=255)
        overlay.putalpha(ImageChops.multiply(overlay.getchannel('A'), final_clip))
        rendered = Image.alpha_composite(track, overlay)
        return ImageTk.PhotoImage(rendered, master=root)
    except Exception:
        return None



def _set_startup_progress(percent, message, pump=True):
    global _startup_progress, _startup_bar_photo
    _startup_progress = max(_startup_progress, min(100, int(percent)))
    _write_external_splash_state(_startup_progress, message)
    try:
        pal = _startup_palette()
        _startup_canvas.itemconfigure(_startup_status_item, text=message)
        _startup_canvas.itemconfigure(_startup_percent_item, text=f'{_startup_progress:02d}%')
        _startup_bar_photo = _render_startup_bar(_startup_progress)
        if _startup_bar_photo is not None:
            _startup_canvas.itemconfigure(_startup_bar_item, image=_startup_bar_photo)
        else:
            _startup_canvas.delete('startup_fallback_bar')
            _startup_canvas.create_line(220, 379, 680, 379, fill='#172b40', width=14, capstyle=tk.ROUND, tags='startup_fallback_bar')
            end_x = 220 + 460 * _startup_progress / 100
            _startup_canvas.create_line(220, 379, end_x, 379, fill=pal['accent'], width=8, capstyle=tk.ROUND, tags='startup_fallback_bar')
        if pump:
            root.update_idletasks()
            root.update()
    except Exception:
        pass


def _animate_startup_spark():
    if not _startup_active:
        return
    try:
        # Progress artwork is centered at W//2 and is 500px wide. Keep the
        # entire 12px halo inside the actual filled portion, including at 6%.
        fill_start = W//2 - 250 + 5
        fill_end = fill_start + 490 * max(0, min(100, _startup_progress)) / 100
        left_bound = fill_start + 7
        right_bound = max(left_bound, fill_end - 7)
        current = _startup_spark[0] + _startup_spark[1]
        if current >= right_bound:
            current = right_bound
            _startup_spark[1] = -abs(_startup_spark[1])
        elif current <= left_bound:
            current = left_bound
            _startup_spark[1] = abs(_startup_spark[1])
        _startup_spark[0] = current
        x = current
        _startup_canvas.coords(_startup_spark_halo, x-6, 373, x+6, 385)
        _startup_canvas.coords(_startup_spark_core, x-2, 376, x+2, 382)
        color = _startup_palette()['accent2']
        _startup_canvas.itemconfigure(_startup_spark_halo, fill=color)
        _startup_canvas.itemconfigure(_startup_spark_core, fill='#ffffff')
    except Exception:
        return
    try: root.after(55, _animate_startup_spark)
    except Exception: pass


_startup_palette_value = _startup_palette()
_startup_bg = _startup_photo_background()
if _startup_bg is not None:
    _startup_background_photo = _startup_bg
    _startup_canvas.create_image(0, 0, image=_startup_background_photo, anchor='nw', tags='startup_background')
else:
    _startup_canvas.configure(bg=_startup_palette_value['bg'])
    for _x in range(0, W, 40): _startup_canvas.create_line(_x,0,_x,H,fill=_startup_palette_value['grid'])
    for _y in range(0, H, 40): _startup_canvas.create_line(0,_y,W,_y,fill=_startup_palette_value['grid'])

# Small custom title-strip and the full logo are the first things shown.
_mark_path = ui_asset_dir / 'PokeFlow_Logo_Mark.png'
try:
    if Image is not None and ImageTk is not None and _mark_path.exists():
        with Image.open(_mark_path) as _raw_mark:
            _mark_img = _raw_mark.convert('RGBA').resize((26,26), Image.Resampling.LANCZOS)
            _startup_mark_photo = ImageTk.PhotoImage(_mark_img, master=root)
    elif _mark_path.exists():
        _startup_mark_photo = tk.PhotoImage(file=str(_mark_path))
except Exception:
    _startup_mark_photo = None
if _startup_mark_photo is not None:
    _startup_canvas.create_image(174, 178, image=_startup_mark_photo, anchor='center')
_startup_canvas.create_text(199, 178, text='POKEFLOW v30  /  STARTUP', anchor='w',
                            font=('Segoe UI', 9, 'bold'), fill=_startup_palette_value['muted'])
_startup_logo_photo = _startup_logo_photo()
if _startup_logo_photo is not None:
    _startup_canvas.create_image(W//2, 255, image=_startup_logo_photo, anchor='center')
else:
    _startup_canvas.create_text(W//2, 244, text='PokeFlow', font=('Segoe UI', 36, 'bold'), fill=_startup_palette_value['text'])
_startup_canvas.create_text(W//2, 330, text='PREPARING YOUR WORKSPACE',
                            font=('Segoe UI', 10, 'bold'), fill=_startup_palette_value['text'])
_startup_canvas.create_text(W//2, 400, text='LOADING VISUAL ASSETS',
                            font=('Segoe UI', 8), fill=_startup_palette_value['muted'], tags='startup_status')
_startup_status_item = _startup_canvas.find_withtag('startup_status')[0]
_startup_canvas.create_text(680, 400, text='06%', anchor='e', font=('Segoe UI', 8, 'bold'),
                            fill=_startup_palette_value['accent2'], tags='startup_percent')
_startup_percent_item = _startup_canvas.find_withtag('startup_percent')[0]
_startup_bar_photo = _render_startup_bar(_startup_progress)
_startup_bar_item = _startup_canvas.create_image(W//2, 379, image=_startup_bar_photo, anchor='center') if _startup_bar_photo else None
_startup_spark = [221.0, 2.2]
_startup_spark_halo = _startup_canvas.create_oval(215,373,227,385,fill=_startup_palette_value['accent2'],outline='')
_startup_spark_core = _startup_canvas.create_oval(219,376,223,382,fill='#ffffff',outline='')
_startup_canvas.create_text(W//2, 430, text='MADE BY CONE  •  CHAT SMARTER · WORK FASTER',
                            font=('Segoe UI', 8), fill=_startup_palette_value['muted'])
if not _EXTERNAL_SPLASH_MODE:
    _startup_canvas.tk.call('raise', _startup_canvas._w)
root.update_idletasks()
root.update()
root.after(55, _animate_startup_spark)
_set_startup_progress(9, 'Starting core services')

# Real MP4 video background. The uploaded video is pre-sized to the app canvas
# so playback stays lightweight while the interface remains on top.
video_paths = {'NEON': Path(__file__).with_name("neon_rain_loop.mp4"),
               'NORMAL': Path(__file__).with_name("normal_wave_loop.mp4")}
video_path = video_paths['NEON']
video_cap_theme = None
frame_paths = [Path(__file__).with_name("frames") / f"frame_{i:02d}.png" for i in range(21)]
blend_frames = [tk.PhotoImage(file=str(p)) for p in frame_paths[:1] if p.exists()]   # only frame 0 is ever shown (was 21 = ~45 MB)
if not blend_frames:
    blend_frames=[tk.PhotoImage(width=W,height=H)]
static_bg_path = Path(__file__).with_name('professional_background.png')
try:
    static_bg_photo = tk.PhotoImage(file=str(static_bg_path))
except Exception:
    static_bg_photo = blend_frames[0]
# Dedicated rainy-city still for NEON. The older bundled MP4 is the rejected sunset scene.
neon_bg_path = Path(__file__).with_name('neon_rain_background.png')
_bg_load_note = ''
try:
    neon_static_bg_photo = tk.PhotoImage(file=str(neon_bg_path))
except Exception as _exc:
    _bg_load_note = f'neon still via Tk failed: {_exc!r}'[:160]
    try:                                         # second way (Pillow) - without it Neon fell back to the Normal wave picture
        from PIL import Image as _PILI, ImageTk as _PILTk
        neon_static_bg_photo = _PILTk.PhotoImage(_PILI.open(str(neon_bg_path)).convert('RGB'), master=root)
        _bg_load_note += ' -> loaded with Pillow'
    except Exception as _exc2:
        _bg_load_note += f' / Pillow failed too: {_exc2!r}'[:120]
        neon_static_bg_photo = static_bg_photo
_set_startup_progress(24, 'Preparing background layers')
frame_index = 0
canvas=tk.Canvas(root,width=W,height=H,highlightthickness=0,bd=0,bg='#0a1019')
canvas.pack(fill='both',expand=True)
bg_item = canvas.create_image(0, 0, image=(blend_frames[0] if video_background_enabled else static_bg_photo), anchor='nw')
# Keep the full-window startup splash above the real interface until first render is ready.
if not _EXTERNAL_SPLASH_MODE:
    try: _startup_canvas.tk.call('raise', _startup_canvas._w)
    except Exception: pass

# Transparent, hand-rendered UI card art layered above the live MP4 background.
ui_asset_dir = Path(__file__).with_name('ui_assets')
class _LazyArt(dict):
    """UI pictures load the first time a screen uses them (not all ~800 for both themes at start): less RAM, faster start.
    .items() only lists the pictures that are loaded (= the ones in use)."""
    def __init__(self, paths):
        super().__init__()
        self._paths = paths
        self._bad = set()

    def _load(self, key):
        path = self._paths.get(key)
        if path is None or key in self._bad:
            return None
        try:
            img = tk.PhotoImage(file=str(path))
        except Exception:
            self._bad.add(key)
            return None
        dict.__setitem__(self, key, img)
        return img

    def get(self, key, default=None):
        if dict.__contains__(self, key):
            return dict.__getitem__(self, key)
        img = self._load(key)
        return default if img is None else img

    def __getitem__(self, key):
        img = self.get(key)
        if img is None:
            raise KeyError(key)
        return img

    def __contains__(self, key):
        return dict.__contains__(self, key) or (key in self._paths and key not in self._bad)


# Older generations of skins (pil_*) are no longer used by any screen: skip them to keep startup fast.
_OBSOLETE_ASSET_PREFIXES = ('pil_card_', 'pil_util_', 'pil_back_button', 'pil_screen_', 'pil_toggle', 'pil_notes_btn')
_asset_files = [_f for _f in ui_asset_dir.glob('*.png') if not _f.stem.startswith(_OBSOLETE_ASSET_PREFIXES)] if ui_asset_dir.exists() else []
ui_art = _LazyArt({_f.stem: _f for _f in _asset_files})


def _art_preload(theme=None, _keys=None):
    """Load the CURRENT theme's pictures quietly in small batches after start / a theme switch, so the first hover
    never stutters. The other theme's pictures stay unloaded until you switch."""
    if _keys is None:
        t = 'neon' if (theme or theme_mode) == 'NEON' else 'normal'
        other = 'normal' if t == 'neon' else 'neon'
        _keys = [k for k in ui_art._paths if not dict.__contains__(ui_art, k)
                 and not re.search(r'(^|_)%s(_|$)' % other, k)]
    for _ in range(3):
        if not _keys:
            return
        ui_art.get(_keys.pop())
    try:
        root.after(40, lambda: _art_preload(theme, _keys))
    except Exception:
        pass
_set_startup_progress(85, 'Rendering theme assets')



def _native_toplevel_hwnd(window=None):
    """Resolve a Tk top-level client/wrapper HWND to its outer Windows frame."""
    target_window = window or root
    try:
        raw_hwnd = int(target_window.winfo_id())
        user32 = ctypes.windll.user32
        # Tk may return an inner HWND; DWM caption attributes must target the
        # outer frame HWND that owns the actual minimize/maximize/close controls.
        user32.GetAncestor.argtypes = [ctypes.c_void_p, ctypes.c_uint]
        user32.GetAncestor.restype = ctypes.c_void_p
        outer_hwnd = user32.GetAncestor(ctypes.c_void_p(raw_hwnd), 2)  # GA_ROOT
        return int(outer_hwnd or raw_hwnd)
    except Exception:
        try:
            return int(target_window.winfo_id())
        except Exception:
            return 0


def _apply_native_titlebar_theme(selected_theme=None, window=None):
    """Apply theme-aware Windows caption, caption text and border.

    DWMWA_CAPTION_COLOR (35), DWMWA_BORDER_COLOR (34), and
    DWMWA_TEXT_COLOR (36) are supported on Windows 11 22H2 and newer.
    Resolve the outer HWND explicitly and report failure instead of silently
    claiming success when Windows rejected the caption-color attributes.
    """
    if os.name != 'nt':
        return False
    try:
        target = selected_theme or theme_mode
        pal = _startup_palette(target)
        hwnd = _native_toplevel_hwnd(window)
        if not hwnd:
            return False
        dwm = ctypes.windll.dwmapi
        user32 = ctypes.windll.user32
        dwm.DwmSetWindowAttribute.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
        dwm.DwmSetWindowAttribute.restype = ctypes.c_long
        hwnd_arg = ctypes.c_void_p(int(hwnd))

        # Request dark non-client rendering first. 20 is the current attribute;
        # 19 is retained for older Windows 10 builds which used that value.
        dark_value = ctypes.c_int(1)
        for attr in (20, 19):
            try:
                if dwm.DwmSetWindowAttribute(hwnd_arg, attr, ctypes.byref(dark_value), ctypes.sizeof(dark_value)) == 0:
                    break
            except Exception:
                continue

        def _colorref(hex_color):
            rgb = hex_color.lstrip('#')
            red, green, blue = int(rgb[0:2], 16), int(rgb[2:4], 16), int(rgb[4:6], 16)
            # DWM expects COLORREF byte order: 0x00BBGGRR.
            return red | (green << 8) | (blue << 16)

        caption_results = {}
        # The coloured outline around the whole window is DWMWA_BORDER_COLOR (34). 0xFFFFFFFE = DWMWA_COLOR_NONE:
        # no border at all, in every theme.
        for attr, color in ((35, pal['caption']), (34, None), (36, pal['text'])):
            value = ctypes.c_uint32(0xFFFFFFFE if attr == 34 else _colorref(color))
            try:
                caption_results[attr] = int(dwm.DwmSetWindowAttribute(
                    hwnd_arg, attr, ctypes.byref(value), ctypes.sizeof(value)))
            except Exception:
                caption_results[attr] = -1

        # Ask Windows to recalculate the non-client frame after changing its
        # colors; this helps after Tk toggles overrideredirect during startup.
        try:
            user32.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p,
                                            ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                            ctypes.c_int, ctypes.c_uint]
            user32.SetWindowPos.restype = ctypes.c_int
            SWP_NOSIZE = 0x0001
            SWP_NOMOVE = 0x0002
            SWP_NOZORDER = 0x0004
            SWP_NOACTIVATE = 0x0010
            SWP_FRAMECHANGED = 0x0020
            user32.SetWindowPos(hwnd_arg, None, 0, 0, 0, 0,
                                SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER |
                                SWP_NOACTIVATE | SWP_FRAMECHANGED)
        except Exception:
            pass
        try:
            dwm.DwmFlush()
        except Exception:
            pass

        # Return True only if the caption color itself was accepted. If Windows
        # is older than 11 22H2, the native caption API is unsupported; use of a
        # custom-drawn title bar would be required to guarantee theme colors.
        return caption_results.get(35) == 0
    except Exception:
        return False


def _schedule_native_titlebar_theme(selected_theme=None, window=None):
    """Retry caption theming after Tk/Windows finishes creating the frame."""
    selected = selected_theme or theme_mode
    scheduler = window or root
    for delay_ms in (0, 180, 520):
        try:
            scheduler.after(delay_ms, lambda target=selected, win=scheduler: _apply_native_titlebar_theme(target, win))
        except Exception:
            if delay_ms == 0:
                _apply_native_titlebar_theme(selected, scheduler)
            break

video_cap = None
try:
    import rain_drops as _rain_mod
except Exception:
    _rain_mod = None
try:
    import brand_anim as _brand_mod
except Exception:
    _brand_mod = None
video_photo = None
video_job = None
video_fps = 24.0

_vid = {'lock': threading.RLock(), 'frame': None, 'gen': 0, 'thread': None, 'paused': False}


def _video_decoder():
    """Background thread: reads + converts the next video frame, so the window thread only has to show it (the
    decoding used to run on the same thread as your mouse / hovers -> lag)."""
    while True:
        try:
            if _vid['paused'] or video_cap is None or not video_background_enabled or _vid['frame'] is not None:
                time.sleep(0.01)
                continue
            with _vid['lock']:
                cap, gen = video_cap, _vid['gen']
                if cap is None:
                    continue
                ok, frame = cap.read()
                if not ok:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    ok, frame = cap.read()
            if not ok:
                time.sleep(0.25)
                continue
            fh, fw = frame.shape[:2]
            target_ratio = W / H
            source_ratio = fw / fh if fh else target_ratio
            if source_ratio > target_ratio:
                crop_w = max(1, int(fh * target_ratio)); left = max(0, (fw - crop_w) // 2)
                frame = frame[:, left:left+crop_w]
            elif source_ratio < target_ratio:
                crop_h = max(1, int(fw / target_ratio)); top = max(0, (fh - crop_h) // 2)
                frame = frame[top:top+crop_h, :]
            if frame.shape[1] != W or frame.shape[0] != H:
                frame = cv2.resize(frame, (W, H), interpolation=cv2.INTER_AREA)
            img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            if gen == _vid['gen']:
                _vid['frame'] = (gen, img)
        except Exception:
            time.sleep(0.25)


def _start_video_background(theme='NEON'):
    """Open the bundled, silent 900x600 ping-pong loop for the given theme."""
    with _vid['lock']:
        _vid['gen'] += 1
        _vid['frame'] = None
        ok = _start_video_background_locked(theme)
    if ok and _vid['thread'] is None:
        _vid['thread'] = threading.Thread(target=_video_decoder, daemon=True, name='PokeFlow-VideoDecode')
        _vid['thread'].start()
    return ok


def _start_video_background_locked(theme='NEON'):
    global video_cap, video_fps, video_path, video_cap_theme
    video_path = video_paths.get(theme, video_paths['NEON'])
    if not VIDEO_READY or not video_path.exists():
        return False
    try:
        if video_cap is not None and video_cap_theme != theme:
            try: video_cap.release()
            except Exception: pass
            video_cap = None
        video_cap_theme = theme
        if video_cap is not None and video_cap.isOpened():
            try: video_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            except Exception: pass
            return True
        if video_cap is not None:
            try: video_cap.release()
            except Exception: pass
        video_cap = cv2.VideoCapture(str(video_path))
        if not video_cap.isOpened():
            video_cap.release(); video_cap = None
            return False
        try: video_cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception: pass
        try: video_cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        except Exception: pass
        fps = float(video_cap.get(cv2.CAP_PROP_FPS) or 24.0)
        video_fps = 24.0 if fps <= 0 else min(fps, 24.0)
        return True
    except Exception:
        try:
            if video_cap is not None: video_cap.release()
        except Exception: pass
        video_cap = None
        return False


def _video_should_pause():
    """Automatic: pause only while PokeFlow is minimized or hidden in the tray. Not being the active window does NOT
    pause it (many people keep PokeFlow on a second monitor while they work in another window)."""
    try:
        if root.state() in ('iconic', 'withdrawn'):
            return True
        return not root.winfo_viewable()
    except Exception:
        return False


def _update_video_background():
    """Show the newest decoded frame (decoding runs in its own thread). One picture is reused, not re-created per frame."""
    global video_job, video_photo, video_cap
    video_job = None
    if video_cap is None or not video_background_enabled:
        return
    if video_cap_theme != theme_mode:                         # wrong loop for the theme (e.g. Normal waves in Neon): fix it
        try: _pb_log(f'Background: {video_cap_theme} loop was playing in {theme_mode} theme - switched to the right one')
        except Exception: pass
        _set_theme_background(theme_mode)
        return
    _vid['paused'] = _video_should_pause()
    if _vid['paused']:
        video_job = root.after(400, _update_video_background)   # frozen, costs almost nothing; resumes by itself
        return
    try:
        item = _vid['frame']
        if item is not None:
            _vid['frame'] = None
            if item[0] == _vid['gen']:
                img = item[1]
                t0 = time.perf_counter()
                if video_photo is None or video_photo.width() != img.width or video_photo.height() != img.height:
                    video_photo = ImageTk.PhotoImage(img, master=root)
                else:
                    video_photo.paste(img)
                if canvas.itemcget(bg_item, 'image') != str(video_photo):
                    canvas.itemconfig(bg_item, image=video_photo)
                canvas.update_idletasks()                         # draw it now (it is drawn anyway) - so it can be timed
                _vid.setdefault('cost', []).append((time.perf_counter() - t0) * 1000)
        interval = max(15, round(1000.0 / (video_fps or 24.0)))
        if time.monotonic() - _vid.get('hover_at', 0.0) < 0.6:
            interval = max(interval, 90)                          # mouse moving over PokeFlow: hovers first, waves at ~11 fps
        video_job = root.after(interval, _update_video_background)
    except Exception:
        try: canvas.itemconfig(bg_item, image=_theme_still())
        except Exception: pass
        video_job = root.after(250, _update_video_background)


_bg_restarts = [0]


def _bg_watchdog():
    """Every 2 s: the background must belong to the current theme (video loop or still image)."""
    try:
        if not POKEFLOW_LITE:
            if video_background_enabled and video_cap is not None and video_cap_theme != theme_mode:
                _pb_log(f'Background watchdog: {video_cap_theme} loop in {theme_mode} theme - fixed')
                _set_theme_background(theme_mode)
            elif bool(globals().get('animated_bg', True)) and not video_background_enabled and VIDEO_READY \
                    and _bg_restarts[0] < 3:
                _bg_restarts[0] += 1
                _pb_log('Background watchdog: animated background was not running - restarting it')
                _set_theme_background(theme_mode)               # loop stopped by an error: start it again
    except Exception:
        pass
    root.after(2000, _bg_watchdog)


def _theme_still(theme=None):
    return neon_static_bg_photo if (theme or theme_mode) == 'NEON' else static_bg_photo


def _set_theme_background(target_theme):
    """Both themes play their own animated loop; the still image is the fallback."""
    global video_background_enabled, video_cap, video_job
    try:
        if video_job is not None: root.after_cancel(video_job)
    except Exception: pass
    video_job = None
    try: canvas.itemconfig(bg_item, image=_theme_still(target_theme))
    except Exception: pass
    video_background_enabled = bool(globals().get('animated_bg', True)) and _start_video_background(target_theme)
    try:
        _pb_log(f'Background: theme={target_theme} animated={bool(globals().get("animated_bg", True))} '
                f'video={"ON " + Path(str(video_path)).name if video_background_enabled else "OFF (still image)"} '
                f'video_ready={VIDEO_READY} neon_still_ok={neon_static_bg_photo is not static_bg_photo}'
                + (f' ({_bg_load_note})' if _bg_load_note else ''))
    except Exception:
        pass
    if video_background_enabled:
        video_job = root.after(1, _update_video_background)
    else:
        with _vid['lock']:
            try:
                if video_cap is not None: video_cap.release()
            except Exception: pass
            video_cap = None

# Theme fade overlays are cached transparent PNG frames. The theme state is
# committed at the dark midpoint so either direction remains deterministic.
theme_transition_busy = False
theme_fade_photos = {}

def _theme_fade_photo(alpha):
    if alpha not in theme_fade_photos:
        if Image is None or ImageTk is None:
            return None
        rgba = Image.new('RGBA', (W, H), (4, 7, 14, int(alpha)))
        theme_fade_photos[alpha] = ImageTk.PhotoImage(rgba, master=root)
    return theme_fade_photos[alpha]


def neon_text(x,y,text,font,core,glow):
    layers=[]
    for dx,dy in [(-3,0),(3,0),(0,-3),(0,3),(-2,-2),(2,2)]:
        layers.append(canvas.create_text(x+dx,y+dy,text=text,font=font,fill=glow))
    layers.append(canvas.create_text(x,y,text=text,font=font,fill=core))
    return layers

# ---------------- Pages ----------------
page='main'
page_items=[]
status_text_item=None

# AI Reply native widgets sit over the glass canvas only while that page is open.
ai_reply_frame = None
ai_reply_extra = []          # extra native widgets (output box) destroyed with the page
ai_click_map = {}
ai_reply_widgets = {}
help_edit_action = None      # which shortcut is waiting for a key press (Help page)
history_pulse_items = []     # (canvas item, frame A, frame B, hover tag) pulsing "repoke due" glows
history_pulse_token = 0
settings_step_job = None
settings_step_dir = 0
settings_step_count = 0
settings_step_changed = False
settings_step_value_ids = []
ai_reply_page_token = 0
ai_reply_busy = False
ai_reply_installed_models = []

# Main-menu hover bob animation state. These jobs only swap Pillow-rendered
# frames whose icon moves 1–2 px; card boundaries and hit regions never move.
hover_bob_jobs = {}
hover_bob_leave_jobs = {}
hover_bob_active = set()

settings_switch_animation_token = 0

def clear_page():
    try: _rain_stop()
    except Exception: pass
    try: _brand_stop()
    except Exception: pass
    global page_items, settings_switch_animation_token, ai_reply_frame, ai_reply_widgets, ai_reply_page_token
    global ai_reply_extra, ai_click_map, history_pulse_items, history_pulse_token
    try: _settings_step_stop()
    except Exception: pass
    history_pulse_token += 1
    history_pulse_items = []
    for _w in ai_reply_extra:
        try: _w.destroy()
        except Exception: pass
    ai_reply_extra = []
    ai_click_map = {}
    # AI widgets are embedded native controls; destroy them explicitly when navigating away.
    ai_reply_page_token += 1
    if ai_reply_frame is not None:
        try:
            ai_reply_frame.destroy()
        except Exception:
            pass
        ai_reply_frame = None
    ai_reply_widgets = {}
    # Cancel hover jobs before the page items are deleted so no callback tries
    # to animate an image that no longer exists.
    for _jobs in (hover_bob_jobs, hover_bob_leave_jobs):
        for _job in list(_jobs.values()):
            try: canvas.after_cancel(_job)
            except Exception: pass
        _jobs.clear()
    hover_bob_active.clear()
    # Invalidate any switch animation that belongs to the page being cleared.
    settings_switch_animation_token += 1
    _nx_reset_hover()
    for item in page_items:
        try: canvas.delete(item)
        except Exception: pass
    page_items=[]

active_card_tag=None
main_card_image_items={}
main_card_style_by_tag={}
main_card_bounds={}
poke_card_image_items={}

def add(item):
    page_items.append(item)
    if active_card_tag:
        try: canvas.addtag_withtag(active_card_tag,item)
        except Exception: pass
    return item


def button_rect(x1,y1,x2,y2,label,sub='',fill='#1b293a',outline=NEON_CYAN,text_color=WHITE,width=2):
    r=add(canvas.create_rectangle(x1,y1,x2,y2,fill=fill,outline=outline,width=width))
    add(canvas.create_text((x1+x2)//2,y1+30,text=label,font=('Segoe UI',15,'bold'),fill=text_color))
    if sub:
        add(canvas.create_text((x1+x2)//2,y1+55,text=sub,font=('Segoe UI',9,'bold'),fill='#c9c4e8'))
    return r


def _nx_title_key(title, subtitle=''):
    """Asset key for a screen title (same rule as tools/render_glass_ui.py)."""
    if title == 'FANS HISTORY':
        return 'fans_history_newest' if 'newest' in subtitle else 'fans_history_oldest'
    return ''.join(c.lower() if c.isalnum() else '_' for c in title).strip('_')


def draw_header(title,subtitle=''):
    _title_art = ui_art.get(f'nx_title_{_nx_title_key(title, subtitle)}_{_nx_t()}')
    if _title_art is not None:
        add(canvas.create_image(NX_TITLE_X, NX_TITLE_Y, image=_title_art, anchor='nw'))
        return
    # Shared hierarchy: NEON titles use a soft magenta halo with a crisp pale core;
    # NORMAL remains restrained white/blue, matching the approved reference sheet.
    if theme_mode == 'NEON' and title in ('ADVANCED NOTES','HELP','FANS HISTORY','ADDITIONAL FEATURES'):
        active_card_tag = None
        for dx,dy in [(-2,0),(2,0),(0,-2),(0,2)]:
            add(canvas.create_text(450+dx,58+dy,text=title,font=('Segoe UI',22,'bold'),fill='#61265f'))
        add(canvas.create_text(450,58,text=title,font=('Segoe UI',22,'bold'),fill='#fff3fc'))
        subtitle_color = '#e4c7ed'
    else:
        add(canvas.create_text(450,58,text=title,font=('Segoe UI',22,'bold'),fill=WHITE))
        subtitle_color = '#9eafc4' if theme_mode == 'NORMAL' else '#dfc3ef'
    if subtitle:
        add(canvas.create_text(450,87,text=subtitle,font=('Segoe UI',9),fill=subtitle_color))


def draw_card_icon(kind, cx, cy, color):
    # Shared icon renderer: all visible glyphs use supersampled transparent vector exports.
    keys = {
        'chat': 'professional_icon_chat',
        'notes': 'professional_icon_notes',
        'check': 'professional_icon_shield_on' if anti_block_enabled else 'professional_icon_shield_off',
        'help': 'professional_icon_help_neon_small' if theme_mode == 'NEON' else 'professional_icon_help_small',
    }
    icon = ui_art.get(keys.get(kind, ''))
    if icon is not None:
        return add(canvas.create_image(cx, cy, image=icon))
    return None


_HOVER_BOB_SEQUENCE = (2, 1, 0, 1, 2, 3, 4, 3)  # offsets 0,-1,-2,-1,0,+1,+2,+1
_HOVER_BOB_INTERVAL_MS = 82


def _cancel_hover_bob_job(tag):
    job = hover_bob_jobs.pop(tag, None)
    if job is not None:
        try: canvas.after_cancel(job)
        except Exception: pass


def _has_hover_bob_frames(style):
    return all(ui_art.get(f'{style}_hover_float_{i:02d}') is not None for i in range(5))


def _animate_hover_bob(tag, step=0):
    if tag not in hover_bob_active:
        return
    item = main_card_image_items.get(tag)
    style = main_card_style_by_tag.get(tag)
    if not item or not style:
        hover_bob_active.discard(tag)
        return
    frame_idx = _HOVER_BOB_SEQUENCE[step % len(_HOVER_BOB_SEQUENCE)]
    frame = ui_art.get(f'{style}_hover_float_{frame_idx:02d}')
    if frame is None:
        hover_bob_active.discard(tag)
        return
    try:
        canvas.itemconfigure(item, image=frame)
        hover_bob_jobs[tag] = canvas.after(
            _HOVER_BOB_INTERVAL_MS,
            lambda t=tag, n=step+1: _animate_hover_bob(t, n))
    except Exception:
        hover_bob_active.discard(tag)
        hover_bob_jobs.pop(tag, None)


_hover_fade = {}            # style -> [PhotoImage 1/3 glow, 2/3 glow] (main-menu buttons only)
_hover_fade_jobs = {}       # tag -> pending after() of a running fade


def _hover_fade_frames(style):
    """Two in-between pictures (normal -> glowing) so a main-menu button fades in ~50 ms instead of switching hard."""
    fr = _hover_fade.get(style)
    if fr is not None:
        return fr or None
    fr = []
    try:
        if style.startswith(('nx_card_', 'nx_util_')):
            pa, pb = ui_art._paths.get(style), ui_art._paths.get(style + '_hover')
            if pa and pb:
                from PIL import Image as _PI
                a, b = _PI.open(pa).convert('RGBA'), _PI.open(pb).convert('RGBA')
                if a.size == b.size:
                    fr = [ImageTk.PhotoImage(_PI.blend(a, b, k), master=root) for k in (0.34, 0.67)]
    except Exception:
        fr = []
    _hover_fade[style] = fr
    return fr or None


def _hover_fade_prebuild():
    """After the main menu is drawn: make its fade pictures quietly, one button at a time (first hover never waits)."""
    todo = [st for st in main_card_style_by_tag.values() if st.startswith(('nx_card_', 'nx_util_')) and st not in _hover_fade]
    if todo and page == 'main':
        _hover_fade_frames(todo[0])
        try: root.after(60, _hover_fade_prebuild)
        except Exception: pass


def _hover_fade_run(tag, images, done=None, step_ms=17):
    """Show `images` one after another on this button's picture (~60 fps), then call done()."""
    job = _hover_fade_jobs.pop(tag, None)
    if job is not None:
        try: canvas.after_cancel(job)
        except Exception: pass
    item = main_card_image_items.get(tag)
    if not item:
        return
    def step(i):
        _hover_fade_jobs.pop(tag, None)
        if i >= len(images):
            if done:
                done()
            return
        try: canvas.itemconfigure(item, image=images[i])
        except Exception: return
        _hover_fade_jobs[tag] = canvas.after(step_ms, lambda: step(i + 1))
    step(0)


def _finish_card_hover_leave(tag):
    hover_bob_leave_jobs.pop(tag, None)
    if tag in hover_bob_active:
        hover_bob_active.discard(tag)
    _cancel_hover_bob_job(tag)
    item = main_card_image_items.get(tag)
    style = main_card_style_by_tag.get(tag)
    if item and style:
        image = ui_art.get(style)
        fr = _hover_fade_frames(style)
        if image and fr:
            _hover_fade_run(tag, [fr[1], fr[0], image])            # glow fades out
        elif image:
            try: canvas.itemconfigure(item, image=image)
            except Exception: pass


def set_card_hover(tag, hovered):
    item=main_card_image_items.get(tag)
    style=main_card_style_by_tag.get(tag)
    if not item or not style:
        return
    leave_job = hover_bob_leave_jobs.pop(tag, None) if hovered else None
    if leave_job is not None:
        try: canvas.after_cancel(leave_job)
        except Exception: pass
    if hovered:
        image=ui_art.get(style + '_hover')
        fr = _hover_fade_frames(style) if tag not in hover_bob_active else None
        def start_bob():
            if _has_hover_bob_frames(style):
                if tag not in hover_bob_active:
                    hover_bob_active.add(tag)
                    _animate_hover_bob(tag, 0)
        if image and fr:
            _hover_fade_run(tag, [fr[0], fr[1], image], start_bob)  # glow fades in (~50 ms), then the float starts
            return
        if image:
            try: canvas.itemconfigure(item,image=image)
            except Exception: pass
        start_bob()
    else:
        # Delay reset by one short beat; a Canvas pointer crossing between the
        # button's image and its labels can emit Leave/Enter on adjacent items.
        # This avoids an obvious stutter while still stopping immediately when
        # the pointer really exits the composite button.
        if tag in hover_bob_active:
            if tag not in hover_bob_leave_jobs:
                hover_bob_leave_jobs[tag] = canvas.after(
                    105, lambda t=tag: _finish_card_hover_leave(t))
        else:
            image=ui_art.get(style)
            fr = _hover_fade_frames(style) if _hover_fade.get(style) else None
            if image and fr:
                _hover_fade_run(tag, [fr[0], image])                 # left during the fade-in: fade back
            elif image:
                _hover_fade_run(tag, [])                             # stop a running fade
                try: canvas.itemconfigure(item,image=image)
                except Exception: pass


def bind_card_hover(tag):
    canvas.tag_bind(tag,'<Enter>',lambda _event,t=tag:set_card_hover(t,True))
    canvas.tag_bind(tag,'<Leave>',lambda _event,t=tag:set_card_hover(t,False))


def _card_label(tag, x, y, text, font, color, anchor='center'):
    # A restrained 1 px shadow gives the label contrast without the chunky double-stroke look.
    if anchor == 'center':
        add(canvas.create_text(x+1,y+1,text=text,font=font,fill='#070711'))
        return add(canvas.create_text(x,y,text=text,font=font,fill=color))
    add(canvas.create_text(x+1,y+1,text=text,font=font,fill='#070711',anchor=anchor))
    return add(canvas.create_text(x,y,text=text,font=font,fill=color,anchor=anchor))


def draw_settings_icon(cx, cy, color):
    # Use a theme-matched antialiased icon for Neon; Professional Dark retains slate-blue.
    key = 'professional_icon_gear_neon_small' if theme_mode == 'NEON' else 'professional_icon_gear_small'
    icon = ui_art.get(key) or ui_art.get('professional_icon_gear_small')
    if icon is not None:
        add(canvas.create_image(cx, cy, image=icon))
        return
    # Graceful fallback if a UI asset was removed.
    r1, r2 = 7, 12
    for angle in range(0,360,45):
        a=math.radians(angle)
        add(canvas.create_line(cx+math.cos(a)*r1,cy+math.sin(a)*r1,
                           cx+math.cos(a)*r2,cy+math.sin(a)*r2,
                           fill=color,width=2,capstyle='round'))
    add(canvas.create_oval(cx-8,cy-8,cx+8,cy+8,outline=color,width=1))
    add(canvas.create_oval(cx-3,cy-3,cx+3,cy+3,outline=color,width=1))


def draw_help_icon(cx, cy, color):
    # Use a matching pink icon in Neon utility buttons; Normal keeps the muted slate icon.
    key = 'professional_icon_help_neon_small' if theme_mode == 'NEON' else 'professional_icon_help_small'
    icon = ui_art.get(key) or ui_art.get('professional_icon_help_small')
    if icon is not None:
        add(canvas.create_image(cx, cy, image=icon))
        return
    add(canvas.create_oval(cx-10,cy-10,cx+10,cy+10,outline=color,width=1))
    add(canvas.create_text(cx,cy-1,text='?',font=('Segoe UI',14,'bold'),fill=color))


def draw_utility_card(tag, x, y, key, label, icon_kind, accent):
    global active_card_tag
    active_card_tag=tag
    main_card_style_by_tag[tag]=key
    main_card_bounds[tag]=(x,y,x+164,y+50)
    disabled_history = icon_kind == 'history' and not save_profile_ids
    art=ui_art.get(key) if not disabled_history else None
    if art:
        main_card_image_items[tag]=add(canvas.create_image(x,y,image=art,anchor='nw'))
    else:
        fill = '#11131b' if disabled_history else '#080d1d'
        edge = '#514b5b' if disabled_history else accent
        add(canvas.create_rectangle(x,y,x+164,y+50,fill=fill,outline=edge,width=2))
        if disabled_history:
            add(canvas.create_rectangle(x+4,y+4,x+160,y+46,outline='#302d39',width=1))
    if disabled_history:
        accent = '#777282'
    if icon_kind=='settings':
        draw_settings_icon(x+28,y+25,accent)
        _card_label(tag,x+94,y+25,label,('Segoe UI',10,'bold'),WHITE)
    elif icon_kind=='bug':
        bug_icon=ui_art.get('professional_icon_bug_neon_small')
        if bug_icon: add(canvas.create_image(x+28,y+25,image=bug_icon))
        _card_label(tag,x+100,y+25,label,('Segoe UI',9,'bold'),WHITE)
    elif icon_kind=='history':
        _draw_history_icon(x+26,y+25,accent,force_canvas=disabled_history)
        title_color = '#777888' if disabled_history else WHITE
        sub_color = '#6f697b' if disabled_history else '#f4d7f1'
        add(canvas.create_text(x+106,y+13,text=label,font=('Segoe UI',9,'bold'),fill=title_color,anchor='center'))
        add(canvas.create_text(x+106,y+29,text='Find lost spenders',font=('Segoe UI',7),fill=sub_color,anchor='center'))
        add(canvas.create_text(x+106,y+41,text='and their history',font=('Segoe UI',7),fill=sub_color,anchor='center'))
    else:
        draw_help_icon(x+28,y+25,accent)
        _card_label(tag,x+96,y+25,label,('Segoe UI',10,'bold'),WHITE)
    active_card_tag=None
    if art and not disabled_history:
        bind_card_hover(tag)


def _draw_history_icon(cx, cy, color, force_canvas=False):
    """Draw an antialiased analog clock, or a muted vector clock when disabled."""
    icon_key = 'professional_icon_clock_neon_small' if theme_mode == 'NEON' else 'professional_icon_clock_normal_small'
    icon = ui_art.get(icon_key) if not force_canvas else None
    if icon is not None:
        add(canvas.create_image(cx, cy, image=icon))
        return
    # Fallback if the clock PNG is unavailable: a real clock face with hands and ticks.
    add(canvas.create_oval(cx-11, cy-11, cx+11, cy+11, outline=color, width=2))
    add(canvas.create_line(cx, cy-8, cx, cy-6, fill=color, width=2, capstyle='round'))
    add(canvas.create_line(cx, cy+8, cx, cy+6, fill=color, width=2, capstyle='round'))
    add(canvas.create_line(cx-8, cy, cx-6, cy, fill=color, width=2, capstyle='round'))
    add(canvas.create_line(cx+8, cy, cx+6, cy, fill=color, width=2, capstyle='round'))
    add(canvas.create_line(cx, cy, cx, cy-6, fill=color, width=2, capstyle='round'))
    add(canvas.create_line(cx, cy, cx+5, cy+3, fill=color, width=2, capstyle='round'))
    add(canvas.create_oval(cx-1, cy-1, cx+1, cy+1, fill=color, outline=color))


def _draw_professional_utility_compact(tag, x, y, asset_key, label, description, kind, accent, width=204):
    """Draw a compact/wide utility tile using Pillow glass-and-glow artwork."""
    global active_card_tag
    height, pad = 50, 12
    active_card_tag = tag
    disabled_history = kind == 'history' and not save_profile_ids
    palette = 'neon' if theme_mode == 'NEON' else 'normal'
    suffix = '_wide' if width > 204 else ''
    style = f'pil_util_{palette}_{kind}{suffix}'
    if disabled_history:
        style = f'pil_util_{palette}_history_disabled'
    main_card_style_by_tag[tag] = style
    main_card_bounds[tag] = (x, y, x+width, y+height)
    art = ui_art.get(style)
    if art is not None:
        main_card_image_items[tag] = add(canvas.create_image(x-pad, y-pad, image=art, anchor='nw'))
    else:
        fill = '#101720' if disabled_history else ('#12071e' if palette == 'neon' else '#131d2a')
        edge = '#55515f' if disabled_history else ('#ff43cf' if palette == 'neon' else '#49bde6')
        add(canvas.create_rectangle(x, y, x+width, y+height, fill=fill, outline=edge, width=2))

    title_color = '#737887' if disabled_history else ('#fff0fc' if palette == 'neon' else '#e7eef8')
    description_color = '#686d7b' if disabled_history else ('#c8b9d8' if palette == 'neon' else '#8fa3bb')
    text_x = x+49
    title_size = 8 if kind in ('bug', 'additional') else 9
    desc_width = max(92, width-70)
    add(canvas.create_text(text_x, y+18, text=label, font=('Segoe UI', title_size, 'bold'),
                           fill=title_color, anchor='w', width=desc_width))
    add(canvas.create_text(text_x, y+35, text=description, font=('Segoe UI', 7),
                           fill=description_color, anchor='w', width=desc_width))
    active_card_tag = None
    if art is not None and not disabled_history:
        bind_card_hover(tag)


def _draw_capsule(x1,y1,x2,y2,fill,outline=None):
    """Draw a compact rounded capsule on the Tk canvas."""
    r=(y2-y1)/2
    ids=[]
    ids.append(add(canvas.create_rectangle(x1+r,y1,x2-r,y2,fill=fill,outline=fill,width=0)))
    ids.append(add(canvas.create_oval(x1,y1,x1+2*r,y2,fill=fill,outline=fill,width=0)))
    ids.append(add(canvas.create_oval(x2-2*r,y1,x2,y2,fill=fill,outline=fill,width=0)))
    if outline:
        ids.append(add(canvas.create_line(x1+r,y1,x2-r,y1,fill=outline,width=1)))
        ids.append(add(canvas.create_line(x1+r,y2,x2-r,y2,fill=outline,width=1)))
        ids.append(add(canvas.create_arc(x1,y1,x1+2*r,y2,start=90,extent=180,style='arc',outline=outline,width=1)))
        ids.append(add(canvas.create_arc(x2-2*r,y1,x2,y2,start=270,extent=180,style='arc',outline=outline,width=1)))
    return ids


def _draw_professional_icon(kind,cx,cy,color,force_muted=False):
    """Draw high-quality antialiased icon assets; use Canvas primitives only as fallback."""
    # Exported at high supersampling and downsampled with LANCZOS. This avoids
    # Tk Canvas's aliased polygon joins and inconsistent diagonal stroke widths.
    if kind == 'shield':
        icon_key = 'professional_icon_shield_on' if anti_block_enabled else 'professional_icon_shield_off'
    elif kind == 'history':
        icon_key = 'professional_icon_clock_muted_large' if force_muted else (
            'professional_icon_clock_neon_large' if theme_mode == 'NEON' else 'professional_icon_clock_normal_large')
    else:
        icon_key = {'chat':'professional_icon_chat', 'notes':'professional_icon_notes'}.get(kind)
    icon = ui_art.get(icon_key) if icon_key else None
    if icon is not None:
        add(canvas.create_image(cx, cy, image=icon))
        return
    if kind == 'history':
        # A clean fallback clock scaled to the primary-card size.
        add(canvas.create_oval(cx-20,cy-20,cx+20,cy+20,outline=color,width=3))
        add(canvas.create_line(cx,cy-15,cx,cy-11,fill=color,width=3,capstyle='round'))
        add(canvas.create_line(cx,cy,cx,cy-11,fill=color,width=3,capstyle='round'))
        add(canvas.create_line(cx,cy,cx+9,cy+6,fill=color,width=3,capstyle='round'))
        add(canvas.create_oval(cx-2,cy-2,cx+2,cy+2,fill=color,outline=color))
        return
    if kind=='chat':
        add(canvas.create_oval(cx-22,cy-17,cx+22,cy+14,outline=color,width=3))
        add(canvas.create_line(cx-10,cy+11,cx-18,cy+23,cx+1,cy+13,fill=color,width=3,capstyle='round',joinstyle='round',smooth=True))
        for dx in (-9,0,9): add(canvas.create_oval(cx+dx-2,cy-3,cx+dx+2,cy+1,fill=color,outline=color))
    elif kind=='notes':
        add(canvas.create_rectangle(cx-17,cy-23,cx+16,cy+23,outline=color,width=3))
        add(canvas.create_line(cx+6,cy-23,cx+16,cy-13,fill=color,width=2))
        for yy,ww in ((cy-7,19),(cy+1,21),(cy+9,15)):
            add(canvas.create_line(cx-8,yy,cx-8+ww,yy,fill=color,width=2,capstyle='round'))
    elif kind=='shield':
        pts=[cx,cy-25,cx+23,cy-16,cx+20,cy+7,cx+10,cy+21,cx,cy+27,cx-10,cy+21,cx-20,cy+7,cx-23,cy-16]
        add(canvas.create_polygon(pts,outline=color,fill='',width=3,joinstyle='round'))
        if anti_block_enabled:
            add(canvas.create_line(cx-10,cy+1,cx-3,cy+9,cx+12,cy-8,fill=color,width=3,capstyle='round',joinstyle='round'))
        else:
            add(canvas.create_line(cx-9,cy+2,cx+9,cy+2,fill=color,width=3,capstyle='round'))


def _draw_professional_utility(tag,x,y,asset_key,label,description,kind,accent):
    global active_card_tag
    active_card_tag=tag
    main_card_style_by_tag[tag]=asset_key
    main_card_bounds[tag]=(x,y,x+244,y+60)
    art=ui_art.get(asset_key)
    if art:
        main_card_image_items[tag]=add(canvas.create_image(x,y,image=art,anchor='nw'))
    else:
        add(canvas.create_rectangle(x,y,x+244,y+60,fill='#131d2a',outline='#34465a',width=1))
    if kind=='settings':
        draw_settings_icon(x+29,y+30,'#a9bfd7')
    elif kind=='bug':
        bug_icon=ui_art.get('professional_icon_bug_small')
        if bug_icon: add(canvas.create_image(x+29,y+30,image=bug_icon))
    else:
        draw_help_icon(x+29,y+30,'#a9bfd7')
    add(canvas.create_text(x+55,y+24,text=label,font=('Segoe UI',10,'bold'),fill='#e7eef8',anchor='w'))
    add(canvas.create_text(x+55,y+42,text=description,font=('Segoe UI',8),fill='#8fa3bb',anchor='w'))
    right_icon = ui_art.get('professional_icon_chevron_right')
    if right_icon: add(canvas.create_image(x+222,y+30,image=right_icon))
    active_card_tag=None
    if art: bind_card_hover(tag)


# ============================ GLASS UI (v30) ============================
# All artwork comes from ui_assets/nx_*.png, rendered by tools/render_glass_ui.py.
# The numbers below MUST match the layout constants at the top of that script.
NX_M = 24                                     # glow margin baked around every image
NX_CARD_W, NX_CARD_H, NX_CARD_Y = 204, 284, 156
NX_CARD_X = (21, 239, 457, 675)
NX_UTIL_W, NX_UTIL_H, NX_UTIL_Y = 274, 56, 464
NX_UTIL_X = (21, 313, 605)
NX_HEAD_X, NX_HEAD_Y = 24, 24
NX_BACK_W, NX_BACK_H, NX_BACK_M = 244, 46, 18
NX_TITLE_X, NX_TITLE_Y = 40, 22
NX_CTL_M = 8
NX_HIST_BOX = (32, 139, 868, 463)
NX_ADD_BOX = (42, 116, 858, 506)
NX_NOTES_BOX = (30, 122, 870, 510)
NX_SET_PANEL = (150, 172)                     # top-left of the first settings row
NX_THEME_BTN = (648, 173, 136, 42)
NX_THEME_BTN_M = 14
NX_SWITCH_PAD = 14
NX_SWITCH_ANTI = (690, 419, 136, 40)          # ANTI 3-SECONDS BLOCK (Additional Features page)
NX_SWITCH_SOUND = (648, 270, 136, 40)         # NOTIFICATION SOUND
NX_SWITCH_BG = (648, 318, 136, 40)            # ANIMATED BACKGROUND
NX_SWITCH_POKE = (690, 347, 136, 40)          # POKE ALERTS (Additional Features page)
NX_SWITCH_KEYS = (648, 366, 136, 40)          # SHORTCUTS ON SCREEN
NX_STEP_MINUS = (648, 222, 34, 40)            # REPOKE TIMER  [-] [0:10] [+]
NX_STEP_VALUE = (686, 222, 60, 40)
NX_STEP_PLUS = (750, 222, 34, 40)
NX_VOL_SLIDER = (584, 414, 200, 40)           # MENU SOUND VOLUME slider (track x, y, w, h); knob runs 14 px inside both ends
NX_VOL_VALUE_X = 548                          # centre of the number left of the slider
NX_STEP_M = 12
NX_TIMER_BTN = (585, 10, 98, 18)              # Fans History: x, dy, w, h (dy from row top)
NX_TIMER_CHIP = (691, 8, 58, 22)
NX_ROW_M = 10
NX_HELP_BOX = (32, 139, 868, 510)
NX_KEY = (54, 104, 24)                        # keycap x, w, h (y = row top + 12)
NX_KEY_M = 10
NX_HELP_ROW_Y0, NX_HELP_ROW_STEP = 177, 36
NX_AI_BOX = (30, 112, 870, 520)
NX_AI_M = 8
NX_AI_MODEL = (112, 124, 262, 30)
NX_AI_CPU = (382, 124, 102, 30)
NX_AI_TOP = {'check': (492, 124, 108, 30), 'download': (606, 124, 126, 30), 'setup': (738, 124, 114, 30)}
NX_AI_IN = (48, 184, 804, 90)
NX_AI_MODE = {'auto': (476, 282, 70, 28), 'sexting': (552, 282, 88, 28), 'gf': (646, 282, 104, 28), 'whale': (756, 282, 70, 28)}
NX_AI_MODE_NAME = {'auto': 'Auto', 'sexting': 'Sexting', 'gf': 'Girlfriend', 'whale': 'Whale'}
NX_AI_LEN = {'short': (112, 282, 88, 28), 'medium': (206, 282, 88, 28), 'detailed': (300, 282, 88, 28)}
NX_AI_OUT = (48, 336, 804, 90)
NX_AI_ACT = {'generate': (48, 438, 152, 32), 'regenerate': (206, 438, 130, 32),
             'copy': (342, 438, 116, 32), 'clear': (464, 438, 92, 32)}
NX_POKE_POS = {'mode_online': (50, 180), 'mode_offline': (470, 180)}
NX_POKE_W, NX_POKE_H = 380, 160

nx_hover_tags = set()      # tags whose hover is driven by exact card bounds (not the glow margin)
nx_hover_current = None


def _nx_t():
    return 'neon' if theme_mode == 'NEON' else 'normal'


def _nx_hover_at(x, y):
    for tag in nx_hover_tags:
        b = main_card_bounds.get(tag)
        if b and b[0] <= x <= b[2] and b[1] <= y <= b[3]:
            return tag
    return None


def _nx_set_hover(tag):
    global nx_hover_current
    if tag == nx_hover_current:
        return
    if nx_hover_current is not None:
        set_card_hover(nx_hover_current, False)
    nx_hover_current = tag
    t0 = time.perf_counter()
    if tag is not None:
        set_card_hover(tag, True)
    try:
        canvas.configure(cursor='hand2' if tag is not None else '')
        canvas.update_idletasks()                                 # show the glow NOW, not after the next video frame
        _lag.setdefault('hover', []).append((time.perf_counter() - t0) * 1000)
    except Exception:
        pass


def _nx_reset_hover():
    global nx_hover_current
    nx_hover_tags.clear()
    nx_hover_current = None


def _nx_refresh_hover():
    """Re-apply hover under the mouse after a redraw (e.g. after clicking a card)."""
    try:
        x = canvas.winfo_pointerx() - canvas.winfo_rootx()
        y = canvas.winfo_pointery() - canvas.winfo_rooty()
        _nx_set_hover(_nx_hover_at(x, y))
    except Exception:
        pass


def _nx_on_motion(event):
    _vid['hover_at'] = time.monotonic()
    if theme_transition_busy:
        return
    _nx_set_hover(_nx_hover_at(event.x, event.y))


def _nx_on_leave(_event):
    _nx_set_hover(None)


def _nx_place(tag, style, x, y, w, h, label, accent, hover=True, margin=NX_M):
    """Place one pre-rendered element. The hit area is the card itself, not its glow."""
    main_card_style_by_tag[tag] = style
    main_card_bounds[tag] = (x, y, x + w, y + h)
    art = ui_art.get(style)
    if art is not None:
        main_card_image_items[tag] = add(canvas.create_image(x - margin, y - margin, image=art, anchor='nw'))
    else:  # plain fallback if an asset file is missing
        add(canvas.create_rectangle(x, y, x + w, y + h, fill='#111a27', outline=accent, width=2))
        add(canvas.create_text(x + w / 2, y + h / 2, text=label, font=('Segoe UI', 10, 'bold'), fill=WHITE))
    if hover:
        nx_hover_tags.add(tag)


def _nx_panel(name, box, fallback_fill=None):
    """Frosted-glass panel baked for a fixed screen position."""
    art = ui_art.get(f'nx_panel_{name}_{_nx_t()}')
    if art is not None:
        add(canvas.create_image(box[0] - NX_M, box[1] - NX_M, image=art, anchor='nw'))
    else:
        edge = '#ff52d6' if theme_mode == 'NEON' else '#36cfff'
        add(canvas.create_rectangle(box[0], box[1], box[2], box[3],
                                    fill=fallback_fill or ('#10091b' if theme_mode == 'NEON' else '#0c1726'),
                                    outline=edge, width=1))


_ver_art = {}


def _app_version_label():
    """'v145' = the update that is installed (from CHANGES_THIS_BUILD.txt); 'v30' if unknown."""
    try:
        txt = Path(__file__).with_name('CHANGES_THIS_BUILD.txt').read_text(encoding='utf-8', errors='replace')
        n = [int(x) for x in re.findall(r'=== UPDATE (\d+) ===', txt)]
        return f'v{max(n)}' if n else VERSION
    except Exception:
        return VERSION


def _version_line_art(t):
    """The small 'vN  •  MADE BY Cone' line under the logo, in the logo's own font (Poppins) - made once per theme."""
    key = (t, _app_version_label())
    if key in _ver_art:
        return _ver_art[key]
    art = None
    try:
        import sys as _s
        _td = str(Path(__file__).with_name('tools'))
        if _td not in _s.path:
            _s.path.insert(0, _td)
        import glass_core as _gc
        from PIL import Image as _PI
        img = _PI.new('RGBA', (320, 30), (0, 0, 0, 0))
        col = (120, 176, 206) if t == 'normal' else (213, 201, 231)
        img = _gc.put_text(img, 0, 22, f'{key[1]}  \u2022  MADE BY {CREATOR}', 'r', 10.5, col)
        art = ImageTk.PhotoImage(img.crop(img.getbbox() and (0, 0, img.getbbox()[2] + 2, 30)), master=root)
    except Exception as exc:
        try: _pb_log(f'Version line art failed: {exc!r}'[:160])
        except Exception: pass
    _ver_art[key] = art
    return art


def _draw_main_layout(theme):
    """Four feature cards + three utility buttons, rendered as glass/neon artwork."""
    global page, status_text_item, active_card_tag, main_card_image_items, main_card_style_by_tag, main_card_bounds
    page = 'main'
    clear_page()
    main_card_image_items = {}
    main_card_style_by_tag = {}
    main_card_bounds = {}
    active_card_tag = None
    t = 'neon' if theme == 'NEON' else 'normal'
    accent = '#ff62dc' if t == 'neon' else '#45c5f2'
    head_item = None

    head = ui_art.get(f'nx_head_{t}')
    if head is not None:
        head_item = add(canvas.create_image(NX_HEAD_X, NX_HEAD_Y, image=head, anchor='nw'))
        ver_art = _version_line_art(t)
        if ver_art is not None:                              # 'v145  •  MADE BY Cone' - the INSTALLED update number
            add(canvas.create_image(NX_HEAD_X + 98, NX_HEAD_Y + 106 - 22, image=ver_art, anchor='nw'))
        else:
            add(canvas.create_text(NX_HEAD_X + 98, NX_HEAD_Y + 106, text=f'{_app_version_label()}  \u2022  MADE BY {CREATOR}',
                                   font=('Segoe UI', 9), fill='#78b0ce' if t == 'normal' else '#d5c9e7', anchor='sw'))
    else:
        add(canvas.create_text(NX_HEAD_X + 14, NX_HEAD_Y + 36, text='PokeFlow', font=('Segoe UI', 26, 'bold'),
                               fill=accent, anchor='w'))
        add(canvas.create_text(NX_HEAD_X + 16, NX_HEAD_Y + 70, text=f'CHAT SMARTER  \u2022  WORK FASTER   {VERSION}  \u2022  MADE BY {CREATOR}',
                               font=('Segoe UI', 8, 'bold'), fill='#9eafc4', anchor='w'))

    fans_disabled = not save_profile_ids
    cards = (('main_poke', 'fans_disabled' if fans_disabled else 'fans', 'FANS HISTORY'),
             ('main_notes', 'notes', 'ADVANCED NOTES'),
             ('main_anti', 'ai', 'AI REPLY'),
             ('main_settings', 'settings', 'SETTINGS'))
    ai_off = not _ai_is_ready()
    for i, (tag, key, label) in enumerate(cards):
        if tag == 'main_anti' and ai_off:
            key = 'ai_disabled'
        _nx_place(tag, f'nx_card_{key}_{t}', NX_CARD_X[i], NX_CARD_Y, NX_CARD_W, NX_CARD_H, label, accent,
                  hover=not ((tag == 'main_poke' and fans_disabled) or (tag == 'main_anti' and ai_off)))

    utils = (('main_report_bug', 'bug', 'REPORT A BUG'),
             ('main_additional', 'additional', 'ADDITIONAL FEATURES'),
             ('main_help', 'help', 'HELP'))
    for i, (tag, key, label) in enumerate(utils):
        _nx_place(tag, f'nx_util_{key}_{t}', NX_UTIL_X[i], NX_UTIL_Y, NX_UTIL_W, NX_UTIL_H, label, accent)

    # Empty by default; shows feedback such as "REPORT A BUG - COMING SOON".
    status_text_item = add(canvas.create_text(450, 550, text='', font=('Segoe UI', 8, 'bold'),
                                               fill=('#ffdbfa' if t == 'neon' else '#90a8c0')))
    root.after(400, _hover_fade_prebuild)
    root.after_idle(_nx_refresh_hover)
    if t == 'neon':
        try: _rain_start()
        except Exception: pass
    try: _brand_start(head_item, t)
    except Exception: pass


# ---- rain drops sliding on the NEON glass cards (follows the animated-background switch) ----
_rain = {'obj': None}


def _rain_stop():
    obj = _rain.get('obj')
    _rain['obj'] = None
    if obj is not None:
        try: obj.stop()
        except Exception: pass


def _rain_start():
    _rain_stop()
    if not video_background_enabled or _rain_mod is None or ImageTk is None:
        return
    # only the empty top-right of each card (right of the icon, above the title): drops never cross text
    regions = [(NX_CARD_X[i] + 92, NX_CARD_Y + 8, NX_CARD_X[i] + NX_CARD_W - 4, NX_CARD_Y + 106, 3, 3) for i in range(4)]
    obj = _rain_mod.CardRain(canvas, lambda im: ImageTk.PhotoImage(im, master=root), regions, lambda it: page_items.append(it), _video_should_pause)
    _rain['obj'] = obj
    obj.start()


# ---- animated PokeFlow header (logo mark + wordmark), both themes; follows the ANIMATED BACKGROUND switch ----
_brand = {'obj': None, 'token': 0}


def _brand_stop():
    _brand['token'] += 1
    obj = _brand.get('obj')
    _brand['obj'] = None
    if obj is not None:
        try: obj.stop()
        except Exception: pass


def _brand_start(item, t):
    _brand_stop()
    if item is None or _brand_mod is None or ImageTk is None or Image is None or not video_background_enabled:
        return
    token = _brand['token']

    def work():
        try:
            base = Image.open(Path(__file__).with_name('ui_assets') / f'nx_head_{t}.png')
            frames = _brand_mod.build_frames(base, t)
        except Exception:
            return

        def go():
            if _brand['token'] != token or page != 'main':
                return
            obj = _brand_mod.BrandAnim(canvas, item, frames, lambda im: ImageTk.PhotoImage(im, master=root), _video_should_pause)
            _brand['obj'] = obj
            obj.start()
        try: root.after(0, go)
        except Exception: pass
    threading.Thread(target=work, daemon=True, name='PokeFlow-Brand').start()


def draw_main_normal():
    _draw_main_layout('NORMAL')


def draw_main_neon():
    _draw_main_layout('NEON')

def draw_main():
    if theme_mode == 'NEON':
        draw_main_neon()
    else:
        draw_main_normal()


def set_poke_card_hover(tag, hovered):
    item=poke_card_image_items.get(tag)
    if item:
        if theme_mode == 'NEON':
            # Neon uses the illustrated sunset/moon cards from the Cyberpunk reference.
            stem='online_poke_card' if tag=='mode_online' else 'offline_poke_card'
            suffix='_hover' if hovered else ''
        else:
            # Normal keeps the polished Professional Dark mode-selection cards.
            stem='mode_online_card' if tag=='mode_online' else 'mode_offline_card'
            suffix='_hover' if hovered else ('_active' if active_mode==('ONLINE' if tag=='mode_online' else 'OFFLINE') else '')
        image=ui_art.get(stem+suffix) or ui_art.get(stem)
        if image:
            try: canvas.itemconfig(item,image=image)
            except Exception: pass


def bind_poke_card_hover(tag):
    canvas.tag_bind(tag,'<Enter>',lambda _event,t=tag:set_poke_card_hover(t,True))
    canvas.tag_bind(tag,'<Leave>',lambda _event,t=tag:set_poke_card_hover(t,False))


def draw_back_button(y, label='BACK TO MAIN MENU'):
    """Glass back button (works at any y; translucent artwork)."""
    t = _nx_t()
    x, w, h = 328, NX_BACK_W, NX_BACK_H
    _nx_place('back_main', f'nx_back_{t}', x, y, w, h, 'Back to Main Menu',
              '#ff62dc' if t == 'neon' else '#45c5f2', margin=NX_BACK_M)


def _history_display_time(value):
    if not value:
        return '—'
    try:
        dt = datetime.fromisoformat(str(value))
        return dt.astimezone().strftime('%d %b %H:%M') if dt.tzinfo else dt.strftime('%d %b %H:%M')
    except Exception:
        return '—'


def _history_stage_label(state):
    stage = int(state.get('stage', 0) or 0)
    if stage <= 0:
        return 'Not started'
    return f'Poke {stage} / 3'


def _history_last_activity(state):
    values = [state.get('last_prepared_at'), state.get('last_sent_at'), state.get('first_seen_at')]
    return max((_parse_iso_timestamp(v) or 0 for v in values), default=0)


def _draw_history_control(tag, x1, y1, x2, y2, label, name=None, alert=False):
    """Compact glass control (artwork has the label baked in). alert=True = pulsing glow."""
    if name is None:
        if tag == 'history_delete_all': name = 'delete_all'
        elif tag == 'history_sort': name = 'sort_new' if 'NEWEST' in label else 'sort_old'
        elif tag.startswith('history_copy_profile_'): name = 'copy'
        elif tag.startswith('history_delete_profile_'): name = 'delete'
        elif tag == 'history_prev': name = 'prev'
        elif tag == 'history_next': name = 'next'
        else: name = ''
    t = _nx_t()
    style = f'nx_ctl_{t}_{name}' + ('_alert' if alert else '')
    main_card_style_by_tag[tag] = style
    main_card_bounds[tag] = (x1, y1, x2, y2)
    art = ui_art.get(style)
    if art is not None:
        item = add(canvas.create_image(x1 - NX_CTL_M, y1 - NX_CTL_M, image=art, anchor='nw'))
        main_card_image_items[tag] = item
        if alert and ui_art.get(style + '_b') is not None:
            history_pulse_items.append((item, art, ui_art[style + '_b'], tag))
    else:
        destructive = tag == 'history_delete_all' or tag.startswith('history_delete_profile_')
        accent = '#ff79c9' if theme_mode == 'NEON' else '#49bde6'
        _draw_capsule(x1, y1, x2, y2, '#251025' if theme_mode == 'NEON' else '#101e2d', accent)
        add(canvas.create_text((x1 + x2) / 2, (y1 + y2) / 2, text=label, font=('Segoe UI', 8, 'bold'),
                               fill=('#ff7ad9' if theme_mode == 'NEON' else '#c3f2ff') if destructive else WHITE))
    nx_hover_tags.add(tag)


def delete_history_profile(profile_id):
    """Delete one saved profile and its poke-stage memory after confirmation."""
    global history_page_index, prepared_profile_id
    key = str(profile_id or '').strip().casefold()
    if key not in poke_state:
        return
    state = poke_state[key]
    name = str(state.get('name') or 'Unknown spender').strip()
    pending_for_profile = str(prepared_profile_id or '').casefold() == key
    prompt = (
        f'Delete {name} ({key}) from Poke History?\n\n'
        'This removes the saved poke stage and used-message history. '
        'If this profile is tracked again later, it will start at Poke 1.'
    )
    if pending_for_profile:
        prompt += (
            '\n\nA personalized message for this profile is currently prepared. '
            'It will remain in the composer, but its send will no longer be recorded against this deleted history entry.'
        )
    if not messagebox.askyesno('Delete Poke History Entry', prompt, parent=root):
        return

    removed_state = poke_state.pop(key)
    removed_timer = repoke_timers.pop(key, None)
    removed_pending = key in pending_repoke_profiles
    pending_repoke_profiles.discard(key)
    if not _save_poke_state():
        poke_state[key] = removed_state
        if removed_timer is not None: repoke_timers[key] = removed_timer
        if removed_pending: pending_repoke_profiles.add(key)
        draw_history()
        set_status('DELETE FAILED  •  HISTORY COULD NOT BE SAVED', '#ff8bcf')
        return

    if pending_for_profile:
        # Leave the prepared message usable, but detach it from the deleted history record.
        prepared_profile_id = ''
    history_page_index = min(history_page_index, max(0, (len(poke_state)-1) // HISTORY_PAGE_SIZE))
    draw_history()
    set_status(f'DELETED {name.upper()} FROM HISTORY', '#ff8bcf' if theme_mode == 'NEON' else '#9cecff')


def delete_all_history():
    """Clear all saved profile IDs and poke stages after an explicit confirmation."""
    global history_page_index, prepared_profile_id
    if not poke_state:
        set_status('HISTORY IS ALREADY EMPTY', '#ff8bcf' if theme_mode == 'NEON' else '#9cecff')
        return
    pending_profile = str(prepared_profile_id or '').casefold()
    prompt = (
        f'Delete all {len(poke_state)} profiles from Poke History?\n\n'
        'This permanently removes every saved profile ID, poke stage, and used-message record. '
        'Newly tracked profiles will start at Poke 1.'
    )
    if pending_profile in poke_state:
        prompt += (
            '\n\nA personalized message is currently prepared for one of these profiles. '
            'It will remain in the composer, but its send will no longer be recorded in history.'
        )
    if not messagebox.askyesno('Delete All Poke History', prompt, parent=root):
        return

    previous_state = dict(poke_state)
    previous_timers = dict(repoke_timers)
    previous_pending = set(pending_repoke_profiles)
    poke_state.clear()
    repoke_timers.clear()
    pending_repoke_profiles.clear()
    if not _save_poke_state():
        poke_state.update(previous_state)
        repoke_timers.update(previous_timers)
        pending_repoke_profiles.update(previous_pending)
        draw_history()
        set_status('DELETE FAILED  •  HISTORY COULD NOT BE SAVED', '#ff8bcf')
        return

    if pending_profile in previous_state:
        prepared_profile_id = ''
    history_page_index = 0
    draw_history()
    set_status('ALL POKE HISTORY DELETED', '#ff8bcf' if theme_mode == 'NEON' else '#9cecff')


def copy_history_profile_id(profile_id):
    """Copy a tracked spender's unique profile ID and leave it on the clipboard."""
    if not save_profile_ids:
        set_status('ENABLE SAVE FAN HISTORY IN SETTINGS TO USE FANS HISTORY', '#ff8bcf' if theme_mode == 'NEON' else '#e47782')
        return
    try:
        key = _profile_state_key(profile_id)
        if key not in poke_state:
            set_status('PROFILE ID IS NO LONGER IN HISTORY', '#ff8bcf' if theme_mode == 'NEON' else '#e47782')
            return
        pyperclip.copy(key)
        if pyperclip.paste().strip().casefold() != key:
            raise RuntimeError('Clipboard verification failed')
        pending_repoke_profiles.discard(key)
        accent = '#ff82df' if theme_mode == 'NEON' else '#49bde6'
        set_status(f'COPIED PROFILE ID  •  {key}', accent)
        if page == 'history': draw_history()
    except Exception:
        set_status('COULD NOT COPY PROFILE ID', '#ff8bcf' if theme_mode == 'NEON' else '#e47782')


def _nx_fmt_time(seconds):
    seconds = max(0, int(seconds))
    return f'{seconds // 60}:{seconds % 60:02d}'


def _nx_draw_text_glyphs(cx, cy, text, style):
    """Text built from pre-rendered Poppins glyph images (digits, ':' and A-Z) so it stays crisp
    and matches the baked-in labels. Returns the canvas item ids."""
    t = _nx_t()
    parts = []
    for ch in text:
        art = ui_art.get(f"nx_g_{t}_{style}_{'colon' if ch == ':' else ch}")
        parts.append((ch, art))
    total = sum((a.width() if a else 7) for _c, a in parts)
    x = cx - total / 2.0
    ids = []
    for ch, art in parts:
        if art is not None:
            ids.append(add(canvas.create_image(int(round(x)), cy, image=art, anchor='w')))
            x += art.width()
        else:
            ids.append(add(canvas.create_text(x + 3.5, cy, text=ch, font=('Segoe UI', 9, 'bold'), fill=WHITE)))
            x += 7
    return ids


def _nx_update_time_items(key, remaining):
    info = repoke_timer_text_items.get(key)
    if not info or info[3] == remaining:
        return
    cx, cy, ids, _last = info
    for i in ids:
        try: canvas.delete(i)
        except Exception: pass
    repoke_timer_text_items[key] = (cx, cy, _nx_draw_text_glyphs(cx, cy, _nx_fmt_time(remaining), 'c'), remaining)


def _history_pulse_tick(token, phase):
    if token != history_pulse_token or page != 'history' or not history_pulse_items:
        return
    for item, art_a, art_b, tag in list(history_pulse_items):
        if tag is not None and tag == nx_hover_current:
            continue
        try: canvas.itemconfigure(item, image=(art_a if phase % 2 == 0 else art_b))
        except Exception: pass
    try: root.after(520, lambda: _history_pulse_tick(token, phase + 1))
    except Exception: pass


def _draw_pending_glow(bounds, color=None):
    """Draw a compact theme-colored multi-outline glow around a due reminder."""
    x1, y1, x2, y2 = bounds
    accent = color or ('#ff58d2' if theme_mode == 'NEON' else '#49bde6')
    bright = '#ffd5f5' if theme_mode == 'NEON' else '#d7f8ff'
    add(canvas.create_rectangle(x1-4, y1-4, x2+4, y2+4, outline=accent, width=1))
    add(canvas.create_rectangle(x1-2, y1-2, x2+2, y2+2, outline=bright, width=1))
    add(canvas.create_rectangle(x1, y1, x2, y2, outline=accent, width=2))


history_acct_filter = ''          # '' = all accounts, else only fans poked on this OnlyFans account


def _history_accounts():
    seen = []
    for st in poke_state.values():
        a = str(st.get('account') or '')
        if a and a not in seen:
            seen.append(a)
    for a in _acct_map.values():
        if a and a not in seen:
            seen.append(a)
    return seen


def _history_records():
    recs = [(k, v) for k, v in poke_state.items() if not history_acct_filter or v.get('account') == history_acct_filter]
    return sorted(recs, key=lambda pair: _history_last_activity(pair[1]), reverse=history_sort_newest)


def _draw_history_accounts(accent, muted):
    """ALL • jessicareed1 • livdavies - click one to see only the fans poked on that account.
    GREEN name = the account you are working on right now."""
    accts = _history_accounts()
    if not accts:
        return
    here = _current_account()
    x, y = 212, 116
    for i, a in enumerate([''] + accts[:4]):
        if i:
            add(canvas.create_text(x + 5, y, text='\u2022', anchor='w', font=('Segoe UI', 8, 'bold'), fill=muted))
            x += 18
        sel = a == history_acct_filter
        col = '#70e4b3' if (a and a == here) else (WHITE if sel else muted)
        label = 'ALL' if not a else _pop_fit(a, ('Segoe UI', 8, 'bold'), 90, 14)
        fnt = ('Segoe UI', 8, 'bold' if sel else 'normal')
        add(canvas.create_text(x, y, text=label, anchor='w', font=fnt, fill=col))
        bb = (x, y - 7, x + _text_w(label, fnt), y + 7)
        if sel:
            add(canvas.create_line(bb[0], bb[3] + 1, bb[2], bb[3] + 1, fill=accent, width=2))
        main_card_bounds[f'history_acct_{i}'] = (bb[0] - 3, bb[1] - 4, bb[2] + 3, bb[3] + 4)
        x = bb[2] + 4
        if x > 455:
            break


def draw_history():
    """Show saved profile IDs, poke stage, and manual repoke reminders."""
    global page, status_text_item, main_card_bounds, main_card_image_items, main_card_style_by_tag, active_card_tag, history_page_index, history_sort_newest, repoke_timer_text_items, history_pulse_items
    page = 'history'
    clear_page()
    main_card_bounds = {}
    main_card_image_items = {}
    main_card_style_by_tag = {}
    active_card_tag = None
    repoke_timer_text_items = {}
    if not save_profile_ids:
        muted = '#858b98'
        draw_header('FANS HISTORY DISABLED', 'Enable Save Fan History in Settings to use this screen')
        _nx_panel('history_off', NX_HIST_BOX, '#101720' if theme_mode == 'NORMAL' else '#11101a')
        draw_back_button(535)
        status_text_item = add(canvas.create_text(450,515,text='',font=('Segoe UI',8,'bold'),fill=muted))
        return
    accent = '#ff58d2' if theme_mode == 'NEON' else '#49bde6'
    muted = '#b5c3d4' if theme_mode == 'NORMAL' else '#d7c8ed'
    sort_description = 'Profiles use unique IDs • newest activity first' if history_sort_newest else 'Profiles use unique IDs • oldest activity first'
    draw_header('FANS HISTORY', sort_description)

    count = len(_history_records())
    add(canvas.create_text(43, 116, text=f'{count} PROFILE{"S" if count != 1 else ""} TRACKED',
                           font=('Segoe UI', 8, 'bold'), fill=muted, anchor='w'))
    sort_label = 'SORT: NEWEST FIRST' if history_sort_newest else 'SORT: OLDEST FIRST'
    _draw_history_control('history_delete_all', 475, 101, 635, 129, 'DELETE ALL')
    _draw_history_control('history_sort', 654, 101, 858, 129, sort_label)

    _nx_panel('history', NX_HIST_BOX, '#0d1521' if theme_mode == 'NORMAL' else '#100b1c')

    _draw_history_accounts(accent, muted)
    records = _history_records()
    total_pages = max(1, (len(records) + HISTORY_PAGE_SIZE - 1) // HISTORY_PAGE_SIZE)
    history_page_index = min(max(0, history_page_index), total_pages - 1)
    start = history_page_index * HISTORY_PAGE_SIZE
    visible = records[start:start + HISTORY_PAGE_SIZE]
    row_y = 176
    row_h = 39
    if not visible:
        add(canvas.create_text(450, 295, text='No profiles tracked yet. Use Ctrl + Q on a spender to capture their profile ID.',
                               font=('Segoe UI', 9), fill=muted, width=720, justify='center'))
    else:
        for index, (profile_id, state) in enumerate(visible):
            y = row_y + index * row_h
            _row_art = ui_art.get(f'nx_row_{"even" if index % 2 == 0 else "odd"}_{_nx_t()}')
            if _row_art is not None:
                add(canvas.create_image(39, y, image=_row_art, anchor='nw'))
            elif index % 2 == 0:
                add(canvas.create_rectangle(39, y, 861, y+row_h-1,
                    fill='#111e2d' if theme_mode == 'NORMAL' else '#171027', outline=''))
            display_name = str(state.get('name') or 'Unknown spender').strip()
            if len(display_name) > 12:
                display_name = display_name[:10] + '...'
            add(canvas.create_text(52, y+10, text=display_name, font=('Segoe UI', 9, 'bold'), fill=WHITE, anchor='w'))
            add(canvas.create_text(52, y+26, text=profile_id, font=('Consolas', 8), fill=accent, anchor='w'))
            if profile_id in pending_repoke_profiles:
                _due_a = ui_art.get(f'nx_row_due_{_nx_t()}')
                if _due_a is not None:
                    _due_item = add(canvas.create_image(39 - NX_ROW_M, y - NX_ROW_M, image=_due_a, anchor='nw'))
                    _due_b = ui_art.get(f'nx_row_due_b_{_nx_t()}')
                    if _due_b is not None:
                        history_pulse_items.append((_due_item, _due_a, _due_b, None))
                else:
                    _draw_pending_glow((43, y+1, 856, y+row_h-2))
            stage = _history_stage_label(state)
            stage_color = '#45e0ca' if theme_mode == 'NEON' and stage == 'Completed' else ('#69d4ff' if theme_mode == 'NORMAL' else '#f0a2f0')
            add(canvas.create_text(326, y+19, text=stage, font=('Segoe UI', 8, 'bold'), fill=stage_color, anchor='w'))
            add(canvas.create_text(450, y+19, text=_history_display_time(state.get('first_seen_at')),
                                   font=('Segoe UI', 8), fill=muted, anchor='w'))
            _draw_history_control(f'history_copy_profile_{profile_id}', 130, y+10, 196, y+28, 'COPY ID')
            _acc = str(state.get('account') or '')
            if _acc:                                                        # which account he was poked on
                _here = _acc == _current_account()
                add(canvas.create_text(208, y+19, text=_pop_fit(_acc, ('Segoe UI', 8, 'bold'), 108, 16), anchor='w',
                                       font=('Segoe UI', 8, 'bold'), fill='#70e4b3' if _here else muted))
            timer_tag = f'history_timer_profile_{profile_id}'
            deadline = repoke_timers.get(profile_id)
            is_due = profile_id in pending_repoke_profiles
            running = deadline is not None
            bx, bdy, bw, bh = NX_TIMER_BTN
            _draw_history_control(timer_tag, bx, y+bdy, bx+bw, y+bdy+bh, 'START TIMER',
                                  name='timer_restart' if (running or is_due) else 'timer_start')
            cx0, cdy, cw, ch = NX_TIMER_CHIP
            chip_state = 'run' if running else ('due' if is_due else 'idle')
            chip_art = ui_art.get(f'nx_timechip_{chip_state}_{_nx_t()}')
            if chip_art is not None:
                add(canvas.create_image(cx0 - NX_CTL_M, y + cdy - NX_CTL_M, image=chip_art, anchor='nw'))
            else:
                _draw_capsule(cx0, y+cdy, cx0+cw, y+cdy+ch, '#102338' if theme_mode == 'NORMAL' else '#24102c', accent)
            chip_cx, chip_cy = cx0 + cw / 2, y + cdy + ch / 2
            if running:
                remaining = max(0, int(deadline - time.monotonic() + 0.999))
                repoke_timer_text_items[profile_id] = (chip_cx, chip_cy,
                    _nx_draw_text_glyphs(chip_cx, chip_cy, _nx_fmt_time(remaining), 'c'), remaining)
            elif is_due:
                if chip_art is None:
                    add(canvas.create_text(chip_cx, chip_cy, text='DUE', font=('Segoe UI', 8, 'bold'), fill=WHITE))
            else:
                _nx_draw_text_glyphs(chip_cx, chip_cy, _nx_fmt_time(repoke_timer_seconds), 'i')
            _draw_history_control(f'history_delete_profile_{profile_id}', 780, y+6, 853, y+32, 'DELETE')
            if index < len(visible)-1 and ui_art.get(f'nx_row_odd_{_nx_t()}') is None:
                add(canvas.create_line(43, y+row_h-1, 857, y+row_h-1, fill='#26374a' if theme_mode == 'NORMAL' else '#34203e'))

    if total_pages > 1:
        pending_pages = {idx // HISTORY_PAGE_SIZE for idx, (pid, _state) in enumerate(records) if pid in pending_repoke_profiles}
        _draw_history_control('history_prev', 302, 473, 409, 504, 'PREVIOUS',
                              alert=any(target_page < history_page_index for target_page in pending_pages))
        _draw_history_control('history_next', 491, 473, 598, 504, 'NEXT',
                              alert=any(target_page > history_page_index for target_page in pending_pages))
        add(canvas.create_text(450, 489, text=f'PAGE {history_page_index+1} / {total_pages}', font=('Segoe UI', 8, 'bold'), fill=muted))
    elif count:
        add(canvas.create_text(450, 489, text=f'SHOWING {len(visible)} OF {count}', font=('Segoe UI', 8, 'bold'), fill=muted))
    if history_storage_error:
        add(canvas.create_text(450, 516, text='WARNING: history could not be saved to disk', font=('Segoe UI', 8, 'bold'), fill='#ff8bcf'))
    status_text_item = add(canvas.create_text(450, 516 if not history_storage_error else 528, text='', font=('Segoe UI', 8, 'bold'), fill=accent))
    draw_back_button(535, 'BACK TO MAIN MENU')
    if history_pulse_items:
        _tok = history_pulse_token
        root.after(520, lambda: _history_pulse_tick(_tok, 1))



NX_AW_SWITCH = (690, 136, 136, 40)            # AUTOWELCOME on/off
NX_AW_WELL = (66, 206, 768, 72)              # welcome message box (baked well in nx_panel_additional_*)
_aw_ui = {'status': None, 'count': None, 'parts': []}


def draw_additional_features(animate_aw_from=None, animate_poke_from=None, animate_anti_from=None):
    """ADDITIONAL FEATURES: AUTOWELCOME (on/off, your welcome message, live status), POKE ALERTS, ANTI 3-SECONDS BLOCK."""
    global page, status_text_item, main_card_bounds, main_card_image_items, main_card_style_by_tag, active_card_tag
    page = 'additional'; clear_page()
    main_card_bounds = {}; main_card_image_items = {}; main_card_style_by_tag = {}; active_card_tag = None
    draw_header('ADDITIONAL FEATURES', 'More tools and workflow options')
    _nx_panel('additional', NX_ADD_BOX, '#0d1521' if theme_mode == 'NORMAL' else '#100b1c')
    tgt = bool(autowelcome_on)
    _draw_settings_switch('add_aw', NX_AW_SWITCH, tgt, bool(animate_aw_from) if animate_aw_from is not None else tgt,
                          settings_switch_animation_token)
    _draw_aw_message_box(NX_AW_WELL)
    _aw_ui['parts'] = []
    _aw_ui['status'] = add(canvas.create_text(72, 298, text='', anchor='w', font=('Segoe UI', 9, 'bold'), fill=WHITE))
    _aw_ui['count'] = add(canvas.create_text(834, 298, text='', anchor='e', font=('Segoe UI', 9), fill=WHITE))
    _aw_status_draw()
    for tag, rect, cur, prev in (('add_poke', NX_SWITCH_POKE, poke_badges_enabled, animate_poke_from),
                                 ('add_anti', NX_SWITCH_ANTI, anti_block_enabled, animate_anti_from)):
        _draw_settings_switch(tag, rect, bool(cur), bool(prev) if prev is not None else bool(cur), settings_switch_animation_token)
    status_text_item = add(canvas.create_text(450, 521, text='', font=('Segoe UI', 8, 'bold'),
                                              fill='#ff82df' if theme_mode == 'NEON' else '#49bde6'))
    draw_back_button(535)


def _aw_status_parts(parts):
    """Status line in several colours: [(text, colour)] drawn one after another (None = back to the single line)."""
    for i in _aw_ui.get('parts') or []:
        try: canvas.delete(i)
        except Exception: pass
    _aw_ui['parts'] = []
    if not parts:
        return
    try:
        canvas.itemconfigure(_aw_ui['status'], text='')
        x = 72
        for txt, col in parts:
            it = add(canvas.create_text(x, 298, text=txt, anchor='w', font=('Segoe UI', 9, 'bold'), fill=col))
            _aw_ui['parts'].append(it)
            x += _text_w(txt, ('Segoe UI', 9, 'bold'))
    except Exception:
        pass


def _aw_status_draw():
    """The live line under the message box: what Autowelcome is doing right now + how many today."""
    if page != 'additional' or _aw_ui.get('status') is None:
        return
    neon = theme_mode == 'NEON'
    good, warn, muted = '#70e4b3', '#ffd18b', ('#d1bfdf' if neon else '#a8bfd5')
    st = _aw.get('status') or 'off'
    if not autowelcome_on:
        text, col = 'OFF  \u2022  turn it on to welcome new subscribers automatically', muted
    elif not (autowelcome_msg or '').strip():
        text, col = '\u26a0  Write your welcome message first', warn
    elif st == 'ok':
        last = _aw.get('last')
        accts = _aw.get('accts') or []
        named = [(a, ok_) for a, ok_ in accts if not a.startswith('window')]
        if named:                                                       # each account by name: GREEN = watched, RED = not
            parts = [('\u25cf  WATCHING  ', good if all(o for _a, o in accts) else warn)]
            for i, (a, ok_) in enumerate(accts):
                if i:
                    parts.append(('  \u2022  ', muted))
                parts.append((a, good if ok_ else '#ff6b7d'))
            if len(accts) == 1 and last:
                parts.append((f'  \u2022  last: {last[0]} {last[1]}', muted))
            _aw_status_parts(parts)
            n = _aw['today'] if _aw.get('day') == time.strftime('%Y-%m-%d') else 0
            try: canvas.itemconfigure(_aw_ui['count'], text=f'welcomed today: {n}', fill=muted)
            except Exception: pass
            return
        else:
            text, col = ('\u25cf  WATCHING NOTIFICATIONS' + (f'  \u2022  {accts[0][0]}' if accts and not accts[0][0].startswith('window') else '') +
                         (f'  \u2022  last: {last[0]} {last[1]}' if last else '')), good
    elif st == 'off':
        text, col = '\u25cf  STARTING\u2026', muted
    else:
        text, col = '\u26a0  ' + st, warn
        accts = [(a, o) for a, o in (_aw.get('accts') or []) if not a.startswith('window')]
        if accts and st.startswith('Open NOTIFICATIONS'):               # which account(s) it can't see: names in red
            parts = [('\u26a0  ' + st + '  ', warn)]
            for i, (a, o) in enumerate(accts):
                parts.append((('  \u2022  ' if i else '') + a, good if o else '#ff6b7d'))
            _aw_status_parts(parts)
            n = _aw['today'] if _aw.get('day') == time.strftime('%Y-%m-%d') else 0
            try: canvas.itemconfigure(_aw_ui['count'], text=f'welcomed today: {n}', fill=muted)
            except Exception: pass
            return
    _aw_status_parts(None)
    n = _aw['today'] if _aw.get('day') == time.strftime('%Y-%m-%d') else 0
    try:
        canvas.itemconfigure(_aw_ui['status'], text=text, fill=col)
        canvas.itemconfigure(_aw_ui['count'], text=f'welcomed today: {n}', fill=muted)
    except Exception:
        pass


def _draw_aw_message_box(rect):
    """Native multi-line box inside the baked well; saved as you type."""
    global ai_reply_extra
    wx, wy, ww, wh = rect
    neon = theme_mode == 'NEON'
    well = '#10061c' if neon else '#0a1220'
    accent = '#ff62dc' if neon else '#45c5f2'
    txt = '#fff7ff' if neon else '#f1f6fc'
    holder = tk.Frame(root, bg=well, bd=0, highlightthickness=0)
    holder.place(x=wx + 10, y=wy + 8, width=ww - 20, height=wh - 16)
    ai_reply_extra.append(holder)
    box = tk.Text(holder, wrap='word', font=('Segoe UI', 10), bg=well, fg=txt, insertbackground=accent, relief='flat',
                  bd=0, highlightthickness=0, padx=4, pady=2, undo=True,
                  selectbackground='#54204f' if neon else '#174261', selectforeground='white')
    box.pack(fill='both', expand=True)
    box.insert('1.0', autowelcome_msg or '')
    state = {'job': None}
    def commit():
        global autowelcome_msg
        value = box.get('1.0', 'end').strip()[:900]
        if value != autowelcome_msg:
            autowelcome_msg = value
            _remember_setting('autowelcome_msg', value)
        _aw_status_draw()
    def on_key(_e=None):
        try:
            if state['job'] is not None: root.after_cancel(state['job'])
            state['job'] = root.after(600, commit)
        except Exception:
            pass
    box.bind('<KeyRelease>', on_key)
    box.bind('<FocusOut>', lambda e: commit())
    box.bind('<<Paste>>', lambda e: root.after(50, commit))
    return box


# ================================ FRESH AI POKES ================================
# Every session the local AI writes 10 new messages per poke stage (one stage at a time, in the background). Ctrl+Q
# uses the built-in 30 until a stage is ready, and always on PCs without AI or without a real graphics card.
try:
    import ai_pokes as _aip
except Exception:
    _aip = None


def _ollama_lower_priority():
    """Ollama (the local AI) runs 'below normal' so FansMetric and PokeFlow stay smooth while it writes."""
    if os.name != 'nt':
        return
    try:
        import ctypes.wintypes as wt
        k = ctypes.windll.kernel32
        class PE(ctypes.Structure):
            _fields_ = [('dwSize', wt.DWORD), ('cntUsage', wt.DWORD), ('th32ProcessID', wt.DWORD),
                        ('th32DefaultHeapID', ctypes.c_void_p), ('th32ModuleID', wt.DWORD), ('cntThreads', wt.DWORD),
                        ('th32ParentProcessID', wt.DWORD), ('pcPriClassBase', ctypes.c_long), ('dwFlags', wt.DWORD),
                        ('szExeFile', ctypes.c_wchar * 260)]
        k.CreateToolhelp32Snapshot.restype = ctypes.c_void_p
        snap = k.CreateToolhelp32Snapshot(2, 0)
        e = PE(); e.dwSize = ctypes.sizeof(PE)
        ok = k.Process32FirstW(ctypes.c_void_p(snap), ctypes.byref(e))
        while ok:
            if e.szExeFile.lower().startswith('ollama'):
                h = k.OpenProcess(0x0200, False, e.th32ProcessID)            # PROCESS_SET_INFORMATION
                if h:
                    k.SetPriorityClass(h, 0x4000)                              # BELOW_NORMAL_PRIORITY_CLASS
                    k.CloseHandle(h)
            ok = k.Process32NextW(ctypes.c_void_p(snap), ctypes.byref(e))
        k.CloseHandle(ctypes.c_void_p(snap))
    except Exception:
        pass


def _ai_poke_worker():
    time.sleep(25)                                        # let PokeFlow + FansMetric settle first
    def no(why):
        _ai_poke['state'] = 'off: ' + why
        _pb_log(f'AI pokes: using the built-in 30 messages ({why})')
    if _aip is None or ai_setup is None:
        return no('AI files missing')
    if not app_settings.get('ai_pokes', True):
        return no('turned off in settings')
    try:
        st, _r, _i = ai_setup.status()
    except Exception:
        st = 'missing'
    if st != 'ready':
        return no('local AI not installed')
    try:
        vram = float(ai_setup.gpu_vram_gb())
    except Exception:
        vram = 0.0
    if vram < 6 or getattr(_ai_core, 'FORCE_CPU', False):
        return no(f'no graphics card for the AI ({vram:.0f} GB) - writing on the CPU would slow the PC down')
    ok, why = _ai_start_ollama_service(wait=20.0)
    if not ok:
        return no(f'Ollama did not start ({why})'[:120])
    _ollama_lower_priority()
    model = (AI_MODEL_SPECS.get(AI_DEFAULT_MODEL_LABEL) or {}).get('id')
    banned = list(_load_banned_map().keys())
    def chat(msgs):
        return _ai_core._chat(model, msgs, num_ctx=2048, num_predict=900, temperature=0.9)
    _ai_poke['state'] = 'writing'
    t_all = time.monotonic()
    for stage, examples in ((1, POKE1), (2, POKE2), (3, POKE3)):
        if _pb.get('stop'):
            return
        t0 = time.monotonic()
        msgs = _aip.generate_stage(stage, examples, chat, banned=banned, n=10, log=_pb_log)
        secs = time.monotonic() - t0
        _ai_poke['secs'][stage] = round(secs, 1)
        if msgs:
            _ai_poke['ready'][stage] = msgs
            _pb_log(f'AI pokes: Poke {stage} ready - {len(msgs)} fresh messages in {secs:.0f} s:')
            for m_ in msgs:
                _pb_log(f'    {m_}')
        else:
            _pb_log(f'AI pokes: Poke {stage} - not enough good messages ({secs:.0f} s) - built-in ones stay')
        _ollama_lower_priority()
    done = [n for n in (1, 2, 3) if _ai_poke['ready'][n]]
    _ai_poke['state'] = 'ready' if done else 'off: AI messages failed the checks'
    _pb_log(f'AI pokes: finished in {time.monotonic() - t_all:.0f} s - fresh messages for Poke {done or "none"}')


# ================================ AUTO-UPDATE ================================
# pf_update.py checks the owner's GitHub releases. A newer, correctly SIGNED update is downloaded in the background and
# installed by the launcher on the next start (old version kept as backup, put back if the new one does not start).
try:
    import pf_update as _pfu
except Exception:
    _pfu = None
_upd_ui = {'told': None}


def _upd_restart_now():
    """Close PokeFlow and start it again ~2 s later (the launcher installs the update in between)."""
    try:
        vbs = Path(__file__).with_name('START.vbs')
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) | getattr(subprocess, 'DETACHED_PROCESS', 0)
        subprocess.Popen(f'cmd /c ping -n 3 127.0.0.1 >nul & start "" wscript.exe "{vbs}"', shell=True, creationflags=flags)
        _pb_log('Update: restarting PokeFlow to install')
    except Exception as exc:
        _pb_log(f'Update: restart failed ({exc!r})')
        set_status('RESTART POKEFLOW YOURSELF TO INSTALL THE UPDATE', '#ffb86b')
        return
    _exit_application()


def _upd_tell_ready(ver, notes):
    if _upd_ui['told'] == ver:
        return
    _upd_ui['told'] = ver
    first = next((ln.strip(' -') for ln in str(notes or '').splitlines() if ln.strip()), '')
    try:
        _pop_show_toast('info', f'PokeFlow update {ver} is ready', (first or 'Restart PokeFlow to install it')[:80],
                        [('pop_update', lambda it: (_pop_close_toast(it), _upd_restart_now())),
                         ('pop_dismiss', lambda it: _pop_close_toast(it))], life=30.0)
    except Exception:
        pass


def _upd_worker():
    time.sleep(90)                                        # let PokeFlow settle first
    while not _pb.get('stop'):
        try:
            res = _pfu.check_and_download(log=_pb_log)
            if res:
                root.after(0, lambda r=res: _upd_tell_ready(*r))
        except Exception as exc:
            _pb_log(f'Update check failed: {exc!r}'[:200])
        time.sleep(3 * 3600)


def _upd_after_start():
    """Just updated? Say so (and keep it). Rolled back? Say that."""
    if _pfu is None or POKEFLOW_LITE:
        return
    try:
        st = _pfu.state()
        done = _pfu.confirm_started()
        if done:
            ver, notes = done
            first = next((ln.strip(' -') for ln in str(notes or '').splitlines() if ln.strip()), '')
            _pb_log(f'Update: now running UPDATE {ver}')
            _pop_show_toast('info', f'Updated to PokeFlow {ver}', (first or 'Enjoy the new version')[:80],
                            [('pop_ok', lambda it: _pop_close_toast(it))], life=12.0)
        elif st.get('rolled_back_from') and not st.get('rollback_told'):
            st['rollback_told'] = True
            _pfu._save_state(st)
            _pop_show_toast('info', f"Update {st['rolled_back_from']} did not start",
                            'Your previous version was put back automatically', [('pop_ok', lambda it: _pop_close_toast(it))], life=15.0)
    except Exception as exc:
        _pb_log(f'Update: after-start step failed: {exc!r}'[:200])
    threading.Thread(target=_upd_worker, daemon=True, name='PokeFlow-Updater').start()


# ================================ REPORT A BUG ================================
# One click: a description + the PokeFlow log of that time (fan names, IDs and messages hidden) + PC/PokeFlow info
# go to the PokeFlow team's Discord channel. Nothing from FansMetric's screen is ever sent.
BUG_WEBHOOK_DEFAULT = ('https://discord.com/api/webhooks/1563287348249366539/'
                       'iUmIltFV8vISz_YzEM1-eQ8bPvHz61j_lPv9DdErGMM6yySDnvMfhTa25C6sF2k8sQKO')
NX_BUG_BOX = (42, 116, 858, 506)
NX_BUG_WELL = (66, 186, 768, 112)                       # same numbers as tools/render_glass_ui.py
NX_BUG_BTN = {'bug_preview': (518, 446, 124, 40, 'PREVIEW'), 'bug_send': (652, 446, 182, 40, 'SEND REPORT')}
BUG_WHEN = (('now', 'Just now', 20 * 60), ('hour', 'In the last hour', 75 * 60), ('today', 'Earlier today', 24 * 3600))
_bug = {'text': '', 'when': 'now', 'shot': False, 'box': None, 'busy': False, 'last_sent': 0.0, 'crash': None}


def _bug_version():
    """'v30 UPDATE 142' from CHANGES_THIS_BUILD.txt next to PokeFlow.py."""
    try:
        txt = Path(__file__).with_name('CHANGES_THIS_BUILD.txt').read_text(encoding='utf-8', errors='replace')
        n = re.findall(r'=== UPDATE (\d+) ===', txt)
        return f'{VERSION} UPDATE {n[-1]}' if n else VERSION
    except Exception:
        return VERSION


def _bug_pc_id():
    """A short, stable code for this PC (no name, no serial) - so reports from the same PC can be grouped."""
    try:
        import hashlib, uuid
        return hashlib.sha1(f'{uuid.getnode()}-{os.environ.get("COMPUTERNAME", "")}'.encode()).hexdigest()[:6]
    except Exception:
        return '??????'


class _BugAnon:
    """Replaces fans' names, @ids, profile ids, chat numbers, account names and message texts with placeholders.
    The same name always gets the same placeholder, so the log still makes sense."""
    _TECH = re.compile(r'error|exception|fansmetric|notifications|window|http|\.py|ctrl|reader|traceback|pokeflow|'
                       r'status|thread|timeout|uia|ocr|com |pointer|failed|found|not available', re.I)

    def __init__(self):
        self.names, self.ids, self.accts = {}, {}, {}
        for a in list(_acct_map.values()) + [str(v.get('account') or '') for v in poke_state.values()]:
            if a and a not in self.accts:
                self.accts[a] = 'Account ' + chr(65 + len(self.accts))
        for pid, st in poke_state.items():
            self._id(pid)
            self._name(st.get('name'))
        try:
            for k, v in _aw_load().items():
                self._id(k.split(':', 1)[-1])
                self._name(v.get('name'))
        except Exception:
            pass

    def _name(self, n):
        n = str(n or '').strip()
        if len(n) >= 2 and n not in self.names and n.lower() not in ('unknown spender', 'him', 'babe'):
            ph = self.names[n] = f'Fan#{len(self.names) + 1}'
            plain = re.sub(r"[^\w\s'.\-]", '', n).strip()          # 'Jazmin🌷' is also written 'Jazmin'
            if len(plain) >= 3 and plain not in self.names:
                self.names[plain] = ph
        return self.names.get(n, n)

    def _id(self, i):
        i = str(i or '').strip().lstrip('@')
        if len(i) >= 3 and i.lower() not in self.ids:
            self.ids[i.lower()] = f'fanid{len(self.ids) + 1}'
        return self.ids.get(i.lower(), i)

    def learn(self, text):
        """Names that only appear in the log itself (Autowelcome lines, card dumps, Ctrl+Q reader lines)."""
        pats = (r"Autowelcome: '([^'\n]{1,60})'", r"Autowelcome: \"([^\"\n]{1,60})\"", r"name='([^'\n]{1,60})'",
                r"name=\"([^\"\n]{1,60})\"", r"sent to '([^'\n]{1,60})'", r"sent to \"([^\"\n]{1,60})\"",
                r"\bL:([^;|\n]{2,40});", r"Welcoming ([^\n]{2,40})$")
        for p in pats:
            for m in re.finditer(p, text, re.M):
                self._name(m.group(1))
        for m in re.finditer(r'\((?:[^():\s]{2,40}):([A-Za-z0-9_.\-]{3,40})\)|\bid=([A-Za-z0-9_.\-]{3,40})', text):
            self._id(m.group(1) or m.group(2))              # '(livdavies:joserior)', 'id=jazmin-beau'
        for a in list(self.accts):                          # 'livdavies:meghanhart' anywhere (fan ids are stored like that)
            for m in re.finditer(re.escape(a) + r':([A-Za-z0-9_.\-]{3,40})', text):
                self._id(m.group(1))
        for m in re.finditer(r"'([^'\s:]{2,40}):([A-Za-z0-9_.\-]{3,40})'", text):
            self._id(m.group(2))
        for m in re.finditer(r'subs: ([^\n]+)', text):
            for part in m.group(1).split(', '):
                self._name(re.sub(r'\((?:\d+m|answered|\?)\)\s*$', '', part).strip())

    def __call__(self, text):
        self.learn(text)
        for a, ph in sorted(self.accts.items(), key=lambda x: -len(x[0])):
            text = text.replace(a, ph)
        for n, ph in sorted(self.names.items(), key=lambda x: -len(x[0])):
            if len(n) >= 3:
                text = re.sub(r'(?<![\w@])' + re.escape(n) + r'(?![\w])', ph, text)
        text = re.sub(r'@([A-Za-z0-9][A-Za-z0-9_.\-]{2,40})', lambda m: '@' + self._id(m.group(1)), text)
        text = re.sub(r'\bu\d{5,12}\b', lambda m: self._id(m.group(0)), text)
        for i, ph in sorted(self.ids.items(), key=lambda x: -len(x[0])):
            if len(i) >= 4:
                text = re.sub(r'(?<![\w])' + re.escape(i) + r'(?![\w])', ph, text, flags=re.I)
        text = re.sub(r'(/chats?/chat/)\d+', r'\1N', text)
        text = re.sub(r'(onlyfans\.com/)(?!my/)[A-Za-z0-9_.\-]+', r'\1[fan]', text)

        def quoted(m):                                        # long quoted text that reads like a chat message
            body = m.group(2)
            if len(body) > 28 and ' ' in body and not self._TECH.search(body):
                return f'{m.group(1)}[message {len(body)} chars]{m.group(1)}'
            return m.group(0)
        return re.sub(r"(['\"])([^'\"\n]{29,400})\1", quoted, text)


def _bug_log_part(seconds):
    """The badges_debug.txt lines of the chosen time span (it only stores HH:MM:SS - read from the end backwards)."""
    try:
        lines = _PB_LOG.read_text(encoding='utf-8', errors='replace').splitlines()
    except Exception:
        return '(no log file)'
    now = datetime.now()
    out = []
    for ln in reversed(lines):
        m = re.match(r'(\d\d):(\d\d):(\d\d) ', ln)
        if m:
            t = now.replace(hour=int(m.group(1)), minute=int(m.group(2)), second=int(m.group(3)), microsecond=0)
            age = (now - t).total_seconds()
            if age < -60:
                age += 86400                                  # written before midnight
            if age > seconds:
                break
        out.append(ln)
        if len(out) >= 5000:
            break
    return '\n'.join(reversed(out)) or '(nothing logged in that time)'


def _bug_crash_part():
    try:
        txt = CRASH_LOG_PATH.read_text(encoding='utf-8', errors='replace')
    except Exception:
        return ''
    parts = txt.split('===== PokeFlow started')
    keep = '===== PokeFlow started'.join(parts[-3:])          # this run + the 2 before
    return keep[-30000:]


def _bug_pc_info():
    info = []
    try:
        import platform
        info.append(f'Windows: {platform.platform()}  |  Python {platform.python_version()}')
    except Exception:
        pass
    try:
        u = ctypes.windll.user32
        info.append(f'Main screen: {u.GetSystemMetrics(0)}x{u.GetSystemMetrics(1)}  |  all screens: {_virtual_screen()}  |  '
                    f'PokeFlow DPI: {u.GetDpiForWindow(_native_toplevel_hwnd()) if hasattr(u, "GetDpiForWindow") else "?"}')
    except Exception:
        pass
    try:
        wins = find_fansmetric_windows()
        info.append(f'FansMetric windows: {len(wins)}  ' + '  '.join(
            f'[{_acct_map.get(int(getattr(w, "_hWnd", 0)), "?")} at {w.left},{w.top} {w.width}x{w.height}]' for w in wins))
    except Exception:
        pass
    info.append(f'Theme: {theme_mode}  |  animated background: {"on" if video_background_enabled else "off"}  |  '
                f'Autowelcome: {"on" if autowelcome_on else "off"} (message {len(autowelcome_msg or "")} chars)  |  '
                f'poke alerts: {"on" if poke_badges_enabled else "off"}  |  anti 3-sec: {"on" if anti_block_enabled else "off"}')
    safe = {k: v for k, v in app_settings.items() if not re.search(r'msg|message|webhook|note|text|name', str(k), re.I)}
    info.append('Settings: ' + json.dumps(safe, ensure_ascii=False, default=str)[:3000])
    info.append(f'Fans in history: {len(poke_state)}  |  welcomes logged: {len(_aw_load())}')
    return '\n'.join(info)


def _bug_build(text, when_key, shot=False):
    """Everything that would be sent: (report_id, embed dict, {filename: bytes}). All fan details already hidden."""
    rid = ''.join(random.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(4))
    span = next((s for k, _l, s in BUG_WHEN if k == when_key), 20 * 60)
    label = next((l for k, l, _s in BUG_WHEN if k == when_key), 'Just now')
    anon = _BugAnon()
    log = _bug_log_part(span)
    crash = _bug_crash_part()
    anon.learn(log)
    anon.learn(crash)
    log, crash = anon(log), anon(crash)
    desc = anon((text or '').strip()) or '(no description)'
    pc = anon(_bug_pc_info())
    ver = _bug_version()
    accts = ', '.join(sorted(set(anon.accts.values()))) or 'none seen'
    embed = {
        'title': f'\U0001F41E Bug report #{rid}',
        'description': desc[:3500],
        'color': 0xFF4BD4 if theme_mode == 'NEON' else 0x39C6F1,
        'fields': [
            {'name': 'When', 'value': label, 'inline': True},
            {'name': 'Version', 'value': ver, 'inline': True},
            {'name': 'PC', 'value': _bug_pc_id(), 'inline': True},
            {'name': 'Page', 'value': str(page), 'inline': True},
            {'name': 'Accounts', 'value': accts[:200], 'inline': True},
            {'name': 'Crash last time', 'value': 'YES' if _bug.get('crash') else 'no', 'inline': True},
        ],
        'footer': {'text': 'Fan names, IDs and messages are replaced before sending.'},
        'timestamp': datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S.000Z'),
    }
    files = {f'log_{rid}.txt': log.encode('utf-8'), f'pc_and_settings_{rid}.txt': pc.encode('utf-8')}
    if re.search(r'Fatal Python error|Windows fatal exception|Traceback|error', re.sub(r'=====.*?=====', '', crash)):
        files[f'crash_{rid}.txt'] = crash.encode('utf-8')     # only when something really went wrong (not just start lines)
    if shot:
        try:
            from PIL import ImageGrab
            import io
            x, y = root.winfo_rootx(), root.winfo_rooty()
            img = ImageGrab.grab(bbox=(x, y, x + root.winfo_width(), y + root.winfo_height()), all_screens=True)
            buf = io.BytesIO(); img.save(buf, 'PNG')
            files[f'pokeflow_window_{rid}.png'] = buf.getvalue()
        except Exception as exc:
            files[f'pc_and_settings_{rid}.txt'] += f'\n(screenshot failed: {exc!r})'.encode('utf-8')
    return rid, embed, files


def _bug_post(embed, files):
    """Discord webhook: one message with the embed + the files attached. True / error text."""
    import uuid
    url = str(app_settings.get('bug_webhook') or BUG_WEBHOOK_DEFAULT).strip()
    boundary = 'PokeFlow' + uuid.uuid4().hex
    body = bytearray()
    def part(headers, data):
        body.extend(f'--{boundary}\r\n'.encode())
        body.extend(headers.encode())
        body.extend(b'\r\n')
        body.extend(data)
        body.extend(b'\r\n')
    payload = {'username': 'PokeFlow Bug Reports', 'embeds': [embed],
               'attachments': [{'id': i, 'filename': n} for i, n in enumerate(files)]}
    part('Content-Disposition: form-data; name="payload_json"\r\nContent-Type: application/json\r\n',
         json.dumps(payload).encode('utf-8'))
    for i, (n, data) in enumerate(files.items()):
        ctype = 'image/png' if n.endswith('.png') else 'text/plain; charset=utf-8'
        part(f'Content-Disposition: form-data; name="files[{i}]"; filename="{n}"\r\nContent-Type: {ctype}\r\n', data)
    body.extend(f'--{boundary}--\r\n'.encode())
    req = urllib.request.Request(url, data=bytes(body), method='POST', headers={
        'Content-Type': f'multipart/form-data; boundary={boundary}',
        'User-Agent': 'PokeFlow-BugReport (pokeflow, 1.0)'})
    try:
        with urllib.request.urlopen(req, timeout=25) as r:
            return True if r.status in (200, 204) else f'Discord answered {r.status}'
    except Exception as exc:
        return repr(exc)[:160]


def _bug_save_local(rid, embed, files):
    """No internet / Discord refused: the same report as one zip on the Desktop to send by hand."""
    import zipfile
    desk = Path(os.environ.get('USERPROFILE', str(Path.home()))) / 'Desktop'
    if not desk.exists():
        desk = POKE_HISTORY_PATH.parent
    path = desk / f'PokeFlow_bug_{rid}.zip'
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr(f'report_{rid}.txt', f"{embed['title']}\n\n{embed['description']}\n\n" +
                   '\n'.join(f"{f['name']}: {f['value']}" for f in embed['fields']))
        for n, data in files.items():
            z.writestr(n, data)
    return path


def _bug_send():
    if _bug['busy']:
        return
    text = _bug_text_now()
    if len(text.strip()) < 4 and not _bug.get('crash'):
        set_status('WRITE A FEW WORDS ABOUT WHAT HAPPENED FIRST', '#ffb86b')
        return
    if time.monotonic() - _bug['last_sent'] < 60:
        set_status('REPORT ALREADY SENT  •  WAIT A MINUTE BEFORE THE NEXT ONE', '#ffb86b')
        return
    _bug['busy'] = True
    set_status('SENDING REPORT…', NEON_YELLOW)
    when, shot = _bug['when'], _bug['shot']

    def work():
        try:
            rid, embed, files = _bug_build(text, when, shot)
            res = _bug_post(embed, files)
            saved = None
            if res is not True:
                _pb_log(f'Bug report #{rid}: Discord failed ({res}) - saved on the Desktop')
                saved = _bug_save_local(rid, embed, files)
            else:
                _pb_log(f'Bug report #{rid} sent to Discord')
        except Exception as exc:
            rid, res, saved = '----', repr(exc)[:120], None
            _pb_log(f'Bug report failed: {exc!r}'[:200])

        def done():
            _bug['busy'] = False
            if res is True:
                _bug['last_sent'] = time.monotonic()
                _bug['text'] = ''
                _bug['crash'] = None
                try:
                    if _bug.get('box') is not None:
                        _bug['box'].delete('1.0', 'end')
                except Exception:
                    pass
                set_status(f'REPORT #{rid} SENT  •  THANK YOU', '#70e4b3')
                _pop_info(f'Bug report #{rid} sent', 'Thanks - the PokeFlow team has it.', 6.0)
            elif saved is not None:
                set_status(f'COULD NOT REACH DISCORD  •  SAVED TO DESKTOP: {saved.name}', '#ffb86b')
            else:
                set_status(f'REPORT FAILED  •  {res}'[:90], '#ff8bcf')
        try: root.after(0, done)
        except Exception: pass
    threading.Thread(target=work, daemon=True, name='PokeFlow-BugReport').start()


def _bug_preview():
    """Open exactly what would be sent (with fan details hidden) in Notepad."""
    try:
        rid, embed, files = _bug_build(_bug_text_now(), _bug['when'], False)
        out = Path(tempfile.gettempdir()) / f'PokeFlow_report_preview_{rid}.txt'
        parts = [f"{embed['title']}\n{embed['description']}\n" +
                 '\n'.join(f"{f['name']}: {f['value']}" for f in embed['fields']) +
                 ('\n(+ a screenshot of the PokeFlow window)' if _bug['shot'] else '')]
        for n, data in files.items():
            parts.append(f'\n\n========== {n} ==========\n' + data.decode('utf-8', errors='replace'))
        out.write_text(''.join(parts), encoding='utf-8')
        os.startfile(str(out))
        set_status('PREVIEW OPENED  •  THIS IS EXACTLY WHAT WOULD BE SENT', '#ff82df' if theme_mode == 'NEON' else '#49bde6')
    except Exception as exc:
        set_status(f'PREVIEW FAILED  •  {exc!r}'[:90], '#ff8bcf')


def _bug_text_now():
    try:
        if _bug.get('box') is not None:
            _bug['text'] = _bug['box'].get('1.0', 'end').strip()[:3000]
    except Exception:
        pass
    return _bug['text']


def draw_report_bug():
    """REPORT A BUG screen."""
    global page, status_text_item, main_card_bounds, main_card_image_items, main_card_style_by_tag, active_card_tag, ai_reply_extra
    _bug_text_now()
    page = 'bug'; clear_page()
    main_card_bounds = {}; main_card_image_items = {}; main_card_style_by_tag = {}; active_card_tag = None
    draw_header('REPORT A BUG', 'Goes straight to the PokeFlow team • fan names and messages are hidden')
    _nx_panel('bug', NX_BUG_BOX, '#0d1521' if theme_mode == 'NORMAL' else '#100b1c')
    neon = theme_mode == 'NEON'
    accent = '#ff62dc' if neon else '#45c5f2'
    muted = '#d1bfdf' if neon else '#a8bfd5'
    well = '#10061c' if neon else '#0a1220'
    wx, wy, ww, wh = NX_BUG_WELL
    holder = tk.Frame(root, bg=well, bd=0, highlightthickness=0)
    holder.place(x=wx + 10, y=wy + 8, width=ww - 20, height=wh - 16)
    ai_reply_extra.append(holder)
    box = tk.Text(holder, wrap='word', font=('Segoe UI', 10), bg=well, fg='#fff7ff' if neon else '#f1f6fc',
                  insertbackground=accent, relief='flat', bd=0, highlightthickness=0, padx=4, pady=2, undo=True,
                  selectbackground='#54204f' if neon else '#174261', selectforeground='white')
    box.pack(fill='both', expand=True)
    if _bug['text']:
        box.insert('1.0', _bug['text'])
    _bug['box'] = box
    try: box.focus_set()
    except Exception: pass
    x = 72                                                  # WHEN: Just now • In the last hour • Earlier today
    for i, (key, label, _s) in enumerate(BUG_WHEN):
        if i:
            add(canvas.create_text(x + 6, 364, text='•', anchor='w', font=('Segoe UI', 9, 'bold'), fill=muted))
            x += 20
        sel = _bug['when'] == key
        fnt = ('Segoe UI', 9, 'bold' if sel else 'normal')
        add(canvas.create_text(x, 364, text=label, anchor='w', font=fnt, fill=WHITE if sel else muted))
        w = _text_w(label, fnt)
        if sel:
            add(canvas.create_line(x, 374, x + w, 374, fill=accent, width=2))
        main_card_bounds[f'bug_when_{key}'] = (x - 4, 354, x + w + 4, 378)
        x += w + 4
    rows = [('✓', 'PokeFlow log of that time  (fan names, IDs and messages are hidden)', None),
            ('✓', 'PC + PokeFlow info  (version, Windows, screens, settings)', None),
            ('✓' if _bug['shot'] else '○', "Screenshot of PokeFlow's own window  (click to " +
             ('remove' if _bug['shot'] else 'add') + ')', 'bug_shot')]
    if _bug.get('crash'):
        rows.insert(2, ('✓', 'Crash details from last time', None))
    for j, (mark, txt, tag) in enumerate(rows):
        y = 414 + j * 21
        add(canvas.create_text(74, y, text=mark, anchor='w', font=('Segoe UI', 10, 'bold'), fill='#70e4b3' if mark == '✓' else muted))
        it = add(canvas.create_text(94, y, text=txt, anchor='w', font=('Segoe UI', 9), fill=muted if tag is None else WHITE))
        if tag:
            main_card_bounds[tag] = (70, y - 9, 94 + _text_w(txt, ('Segoe UI', 9)), y + 9)
    for key, (bx, by, bw, bh, label) in NX_BUG_BTN.items():
        _nx_place(key, f'nx_btn_{_nx_t()}_{key}', bx, by, bw, bh, label, accent, margin=8)
    status_text_item = add(canvas.create_text(450, 521, text='', font=('Segoe UI', 8, 'bold'),
                                              fill='#ff82df' if neon else '#49bde6'))
    draw_back_button(535)
    root.after_idle(_nx_refresh_hover)


def _bug_click(event):
    if _hit_card(event, 'back_main'):
        _bug_text_now(); go_main(); return
    for key, _l, _s in BUG_WHEN:
        if _hit_card(event, f'bug_when_{key}'):
            _bug['when'] = key; draw_report_bug(); return
    if _hit_card(event, 'bug_shot'):
        _bug['shot'] = not _bug['shot']; draw_report_bug(); return
    if _hit_card(event, 'bug_send'):
        _bug_send(); return
    if _hit_card(event, 'bug_preview'):
        _bug_preview(); return


def _bug_crash_offer():
    """PokeFlow crashed last time: offer a report (crash details already attached, text pre-filled)."""
    if not _PREV_CRASH or POKEFLOW_LITE:
        return
    _bug['crash'] = _PREV_CRASH
    if not _bug['text']:
        _bug['text'] = 'PokeFlow closed unexpectedly last time.'
    def report(it):
        _pop_close_toast(it)
        try:
            root.deiconify(); root.lift()
        except Exception:
            pass
        draw_report_bug()
    try:
        _pop_show_toast('info', 'PokeFlow closed unexpectedly last time', 'Send a bug report? One click, crash details included.',
                        [('pop_report', report), ('pop_dismiss', lambda it: _pop_close_toast(it))], life=25.0)
    except Exception:
        pass


def toggle_autowelcome_setting():
    global autowelcome_on
    previous = autowelcome_on
    autowelcome_on = not autowelcome_on
    _remember_setting('autowelcome', bool(autowelcome_on))
    draw_additional_features(animate_aw_from=previous)
    set_status('AUTOWELCOME ON  \u2022  KEEP NOTIFICATIONS OPEN IN FANSMETRIC' if autowelcome_on else 'AUTOWELCOME OFF',
               '#ff82df' if theme_mode == 'NEON' else '#49bde6')


def _ai_palette():
    if theme_mode == 'NEON':
        return {'panel':'#10091b', 'field':'#0c0715', 'edge':'#a83d96', 'accent':'#ff58d2',
                'accent2':'#49dfff', 'text':'#fff3fc', 'muted':'#d1bfdf', 'button':'#24102c',
                'select':'#54204f'}
    return {'panel':'#0c1726', 'field':'#081320', 'edge':'#286a91', 'accent':'#49bde6',
            'accent2':'#3e9cff', 'text':'#eef5ff', 'muted':'#a8bfd5', 'button':'#102338',
            'select':'#174261'}


def _ai_set_status(text, color=None):
    status = ai_reply_widgets.get('status')
    if status is None:
        return
    try:
        pal = _ai_palette()
        status.config(text=text, fg=color or pal['muted'])
    except Exception:
        pass


def _ai_queue_status(token, text, color=None):
    try:
        root.after(0, lambda: _ai_set_status(text, color) if token == ai_reply_page_token and ai_reply_frame is not None else None)
    except Exception:
        pass


def _ai_model_id_from_label(label):
    spec = AI_MODEL_SPECS.get(label) or AI_MODEL_SPECS[AI_DEFAULT_MODEL_LABEL]
    return spec['id']


def _ai_installed(model_id, installed):
    model_base = model_id.split(':', 1)[0].casefold()
    return any(str(name).casefold() == model_id.casefold() or str(name).split(':', 1)[0].casefold() == model_base
               for name in installed)


def _ai_apply_local_check(token, ok, models, message):
    global ai_reply_installed_models
    if token != ai_reply_page_token or ai_reply_frame is None:
        return
    ai_reply_installed_models = list(models)
    selected = _ai_model_id_from_label(ai_reply_widgets['model'].get())
    if not ok:
        _ai_set_status('Ollama is not running. Click SETUP OLLAMA, install it, then retry.', '#ff9b9b' if theme_mode == 'NEON' else '#f0a1a1')
    elif _ai_installed(selected, models):
        _ai_set_status(f'LOCAL AI READY  •  {selected} installed', '#70e4b3')
    elif models:
        _ai_set_status(f'Ollama ready, but {selected} is not installed. Click DOWNLOAD MODEL.', '#ffd18b')
    else:
        _ai_set_status('Ollama is running, but no models are installed. Click DOWNLOAD MODEL.', '#ffd18b')


def _ai_check_local():
    token = ai_reply_page_token
    _ai_set_status('Checking local Ollama service…')
    def work():
        try:
            ok, models, message = _ai_check_ollama()
        except Exception as exc:
            ok, models, message = False, [], str(exc)
        try: root.after(0, lambda: _ai_apply_local_check(token, ok, models, message))
        except Exception: pass
    threading.Thread(target=work, daemon=True, name='PokeFlow-AI-Check').start()


def _ai_open_setup():
    """Install Ollama from its official Windows installer when missing.

    The installer is downloaded over HTTPS and launched visibly, only after
    the user confirms. PokeFlow never runs a hidden shell install command.
    """
    if os.name != 'nt':
        import webbrowser
        webbrowser.open(AI_OLLAMA_DOWNLOAD_URL)
        _ai_set_status('Automatic installer is supported on Windows. Open the official Ollama download page.', '#ffd18b')
        return

    # Locate common per-user and machine-wide installations before offering a new install.
    candidates = []
    located = shutil.which('ollama')
    if located:
        candidates.append(located)
    local = os.environ.get('LOCALAPPDATA', '')
    program_files = os.environ.get('ProgramFiles', r'C:\Program Files')
    if local:
        candidates.extend([os.path.join(local, 'Programs', 'Ollama', 'ollama.exe'),
                           os.path.join(local, 'Ollama', 'ollama.exe')])
    candidates.append(os.path.join(program_files, 'Ollama', 'ollama.exe'))
    if any(os.path.isfile(item) for item in candidates):
        _ai_set_status('Ollama is installed. Starting/checking its local service…', '#ffd18b')
        def start_existing():
            try:
                ok, msg = _ai_start_ollama_service()
            except Exception as exc:
                ok, msg = False, f'Ollama could not start ({type(exc).__name__}).'
            try:
                root.after(0, lambda: (_ai_set_status(msg, '#70e4b3' if ok else '#ff9b9b'), _ai_check_local()))
            except Exception:
                pass
        threading.Thread(target=start_existing, daemon=True, name='PokeFlow-Ollama-Start').start()
        return

    if not messagebox.askyesno('Install Ollama',
            'Ollama is not installed. PokeFlow can download the official Windows installer and open it for you.\n\n'
            'The installer will be visible and may ask you to confirm installation. The AI model is a separate, several-GB download. Continue?'):
        return

    token = ai_reply_page_token
    _ai_set_busy(True)
    _ai_set_status('Downloading the official Ollama installer…', '#ffd18b')

    def work():
        installer = os.path.join(tempfile.gettempdir(), 'PokeFlow_OllamaSetup.exe')
        error = None
        try:
            request = urllib.request.Request('https://ollama.com/download/OllamaSetup.exe',
                                             headers={'User-Agent': 'PokeFlow/30'})
            with urllib.request.urlopen(request, timeout=30) as response, open(installer, 'wb') as out:
                total = int(response.headers.get('Content-Length') or 0)
                downloaded = 0
                while True:
                    chunk = response.read(1024 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = min(100, int(downloaded * 100 / total))
                        _ai_queue_status(token, f'DOWNLOADING OLLAMA INSTALLER • {pct}%', '#ffd18b')
            if not os.path.isfile(installer) or os.path.getsize(installer) < 1_000_000:
                raise RuntimeError('The downloaded installer looks incomplete. Please retry or use the official Ollama website.')
            _ai_queue_status(token, 'Opening Ollama installer. Follow its on-screen instructions…', '#ffd18b')
            proc = subprocess.Popen([installer], close_fds=True)
            proc.wait()
            # Installer completion does not always mean the server is immediately ready.
            ok, msg = _ai_start_ollama_service()
            if not ok:
                raise RuntimeError('Installer closed, but Ollama did not become ready. Open Ollama from the Start menu, then click CHECK LOCAL AI.')
        except Exception as exc:
            error = str(exc)
        def finish():
            if token == ai_reply_page_token and ai_reply_frame is not None:
                _ai_set_busy(False)
                if error:
                    _ai_set_status(f'Ollama setup failed: {error}', '#ff9b9b')
                else:
                    _ai_set_status('Ollama installed and started. Click DOWNLOAD MODEL to get Qwen3.', '#70e4b3')
                    _ai_check_local()
            else:
                _ai_set_busy(False)
        try:
            root.after(0, finish)
        except Exception:
            pass

    threading.Thread(target=work, daemon=True, name='PokeFlow-Ollama-Installer').start()


def _ai_set_busy(value):
    global ai_reply_busy
    ai_reply_busy = bool(value)
    for key in ('generate', 'regenerate', 'download', 'check', 'setup'):
        widget = ai_reply_widgets.get(key)
        if widget is not None:
            try: widget.config(state=('disabled' if ai_reply_busy and key in ('generate','regenerate','download') else 'normal'))
            except Exception: pass


def _ai_download_model():
    global ai_reply_busy
    if ai_reply_busy:
        return
    model = _ai_model_id_from_label(ai_reply_widgets['model'].get())
    token = ai_reply_page_token
    _ai_set_busy(True)
    _ai_set_status(f'Preparing to download {model}… This can take several GB of disk space.', '#ffd18b')
    def work():
        error = None
        try:
            _ai_pull_model(model, progress=lambda msg: _ai_queue_status(token, f'DOWNLOADING {model}  •  {msg}', '#ffd18b'))
        except Exception as exc:
            error = str(exc)
        def finish():
            global ai_reply_busy, ai_reply_installed_models
            ai_reply_busy = False
            if token != ai_reply_page_token or ai_reply_frame is None:
                if ai_reply_frame is not None:
                    _ai_set_busy(False)
                return
            _ai_set_busy(False)
            if error:
                _ai_set_status(error, '#ff9b9b')
            else:
                ok, models, _ = _ai_check_ollama()
                ai_reply_installed_models = models
                _ai_apply_local_check(token, ok, models, 'download complete')
        try: root.after(0, finish)
        except Exception: pass
    threading.Thread(target=work, daemon=True, name='PokeFlow-AI-Model-Download').start()


def _ai_output_text():
    widget = ai_reply_widgets.get('output')
    if widget is None:
        return ''
    try: return widget.get('1.0', 'end-1c').strip()
    except Exception: return ''


def _ai_put_output(text):
    widget = ai_reply_widgets.get('output')
    if widget is None:
        return
    try:
        widget.config(state='normal')
        widget.delete('1.0', 'end')
        widget.insert('1.0', text)
        widget.config(state='disabled')
    except Exception:
        pass


def _ai_generate(regenerate=False):
    global ai_reply_busy, ai_reply_last_message
    if ai_reply_busy or ai_reply_frame is None:
        return
    message = ai_reply_widgets['input'].get('1.0', 'end-1c').strip()
    if not message:
        _ai_set_status('Paste the fan message first.', '#ffd18b')
        ai_reply_widgets['input'].focus_set()
        return
    ai_reply_last_message = message
    model_label = ai_reply_widgets['model'].get() or AI_DEFAULT_MODEL_LABEL
    length = ai_reply_widgets['length'].get() or 'Short'
    mode = ai_reply_widgets['mode'].get() if 'mode' in ai_reply_widgets else 'Auto'
    cpu_only = bool(ai_reply_widgets['cpu_only'].var.get())
    token = ai_reply_page_token
    _ai_set_busy(True)
    _ai_set_status('Generating locally… First reply may take longer while the model loads.', '#ffd18b')
    def work():
        draft = None
        note = ''
        error = None
        try:
            draft, note = _ai_generate_reply(message, model_label=model_label, length=length, cpu_only=cpu_only, mode=mode)
        except Exception as exc:
            error = str(exc)
        def finish():
            global ai_reply_busy
            ai_reply_busy = False
            if token != ai_reply_page_token or ai_reply_frame is None:
                if ai_reply_frame is not None:
                    _ai_set_busy(False)
                return
            _ai_set_busy(False)
            if error:
                _ai_set_status(error, '#ff9b9b' if theme_mode == 'NEON' else '#e38f99')
            else:
                _ai_put_output(draft or '')
                cautious = any(term in note.casefold() for term in ('sensitive request', 'safety check', 'boundary redirect', 'neutral redirect'))
                _ai_set_status(note, '#ffd18b' if cautious else '#70e4b3')
        try: root.after(0, finish)
        except Exception: pass
    threading.Thread(target=work, daemon=True, name='PokeFlow-AI-Reply').start()


def _ai_copy_reply():
    draft = _ai_output_text()
    if not draft:
        _ai_set_status('Generate a reply before copying it.', '#ffd18b')
        return
    try:
        root.clipboard_clear()
        root.clipboard_append(draft)
        root.update_idletasks()
        _ai_set_status('REPLY COPIED  •  Review it in FansMetric before sending.', '#70e4b3')
    except Exception as exc:
        _ai_set_status(f'Clipboard unavailable ({type(exc).__name__}).', '#ff9b9b')


def _ai_clear_fields():
    try:
        ai_reply_widgets['input'].delete('1.0', 'end')
        _ai_put_output('')
        _ai_set_status('Ready when you are. Fan messages are not saved by this feature.')
        ai_reply_widgets['input'].focus_set()
    except Exception:
        pass


class _AIImageButton:
    """Glass image button that answers like the old tk.Button (config(state=...))."""
    def __init__(self, tag, key, command):
        self.tag, self.key, self.command, self.enabled = tag, key, command, True

    def set_enabled(self, enabled):
        self.enabled = bool(enabled)
        style = f'nx_ai_{_nx_t()}_{self.key}' + ('' if self.enabled else '_off')
        art = ui_art.get(style)
        if art is not None:
            main_card_style_by_tag[self.tag] = style
            item = main_card_image_items.get(self.tag)
            if item:
                try: canvas.itemconfigure(item, image=art)
                except Exception: pass
        if self.enabled: nx_hover_tags.add(self.tag)
        else: nx_hover_tags.discard(self.tag)

    def config(self, **kw):
        if 'state' in kw:
            self.set_enabled(kw['state'] != 'disabled')
    configure = config

    def invoke(self):
        if self.enabled:
            self.command()


class _AIStatusLine:
    def __init__(self, item): self.item = item
    def config(self, **kw):
        opts = {}
        if 'text' in kw: opts['text'] = kw['text']
        if 'fg' in kw: opts['fill'] = kw['fg']
        try: canvas.itemconfigure(self.item, **opts)
        except Exception: pass
    configure = config


class _AIModelChoice:
    """Model chip: shows the selected model; click cycles when there is more than one."""
    def __init__(self, labels, text_item):
        self.labels, self.text_item = list(labels), text_item
        self.value = labels[0] if labels else ''
    def get(self): return self.value
    def set(self, value):
        self.value = value
        label = value if len(value) <= 34 else value[:33] + '\u2026'
        try: canvas.itemconfigure(self.text_item, text=label, font=('Segoe UI', 9, 'bold') if len(label) <= 28 else ('Segoe UI', 8))
        except Exception: pass
    def cycle(self):
        if len(self.labels) < 2: return
        self.set(self.labels[(self.labels.index(self.value) + 1) % len(self.labels)] if self.value in self.labels else self.labels[0])
        _remember_setting('ai_model', self.value)
        _ai_check_local()


class _AILengthChoice:
    def __init__(self, value='Short'):
        self.value = value
    def get(self): return self.value


def draw_ai_reply():
    """Glass AI Reply composer. Native Tk text boxes sit in baked glass wells; every button is
    pre-rendered art with the same hover glow as the rest of the app."""
    global page, main_card_bounds, main_card_image_items, main_card_style_by_tag, active_card_tag
    global ai_reply_frame, ai_reply_widgets, ai_reply_extra, ai_click_map
    page = 'ai_reply'; clear_page()
    main_card_bounds = {}; main_card_image_items = {}; main_card_style_by_tag = {}; active_card_tag = None
    ai_reply_widgets = {}; ai_click_map = {}
    draw_header('AI REPLY', 'Local response drafts \u2022 you review and send manually')
    _nx_panel('ai', NX_AI_BOX, '#0d1521' if theme_mode == 'NORMAL' else '#100b1c')
    t = _nx_t()
    pal = _ai_palette()
    accent = '#ff62dc' if t == 'neon' else '#45c5f2'
    well = '#10061c' if t == 'neon' else '#0a1220'            # identical to the baked well fill
    txt_col = '#fff7ff' if t == 'neon' else '#f1f6fc'

    def place_btn(tag, key, rect, command, label):
        x, y, w, h = rect
        _nx_place(tag, f'nx_ai_{t}_{key}', x, y, w, h, label, accent, margin=NX_AI_M)
        ai_click_map[tag] = command

    # --- top row: model chip, CPU only, local-AI actions
    mx, my, mw, mh = NX_AI_MODEL
    place_btn('ai_model', 'model', NX_AI_MODEL, lambda: model_choice.cycle(), 'MODEL')
    model_text = add(canvas.create_text(mx + 16, my + mh / 2, text='', anchor='w',
                                        font=('Segoe UI', 9, 'bold'), fill=txt_col))
    model_choice = _AIModelChoice(list(AI_MODEL_SPECS.keys()) or [AI_DEFAULT_MODEL_LABEL], model_text)
    _saved_model = app_settings.get('ai_model') or ''
    model_choice.set(_saved_model if _saved_model in model_choice.labels else
                     (AI_DEFAULT_MODEL_LABEL if AI_DEFAULT_MODEL_LABEL in model_choice.labels else model_choice.labels[0]))
    ai_reply_widgets['model'] = model_choice

    cpu_var = tk.BooleanVar(value=bool(app_settings.get('ai_cpu_only', False)))
    cpu_chip = type('AICpuChip', (), {})()
    cpu_chip.var = cpu_var
    ai_reply_widgets['cpu_only'] = cpu_chip
    def toggle_cpu():
        cpu_var.set(not cpu_var.get())
        _remember_setting('ai_cpu_only', bool(cpu_var.get()))
        style = f"nx_ai_{t}_{'cpu_on' if cpu_var.get() else 'cpu_off'}"
        main_card_style_by_tag['ai_cpu'] = style
        item, art = main_card_image_items.get('ai_cpu'), ui_art.get(style)
        if item and art:
            try: canvas.itemconfigure(item, image=art)
            except Exception: pass
    place_btn('ai_cpu', 'cpu_on' if cpu_var.get() else 'cpu_off', NX_AI_CPU, toggle_cpu, 'CPU ONLY')

    commands = {'check': _ai_check_local, 'download': _ai_download_model, 'setup': _ai_open_setup}
    labels = {'check': 'CHECK LOCAL AI', 'download': 'DOWNLOAD MODEL', 'setup': 'SETUP OLLAMA'}
    for key, (bx, by, bw, bh) in NX_AI_TOP.items():
        btn = _AIImageButton(f'ai_{key}', key, commands[key])
        place_btn(btn.tag, key, (bx, by, bw, bh), btn.invoke, labels[key])
        ai_reply_widgets[key] = btn

    # --- fan message well (native Text, colours match the baked well)
    ix, iy, iw, ih = NX_AI_IN
    ai_reply_frame = tk.Frame(root, bg=well, bd=0, highlightthickness=0)
    ai_reply_frame.place(x=ix + 6, y=iy + 6, width=iw - 12, height=ih - 12)
    input_box = tk.Text(ai_reply_frame, wrap='word', font=TEXT_FONT, bg=well, fg=txt_col,
                        insertbackground=pal['accent'], selectbackground=pal['select'], selectforeground=pal['text'],
                        relief='flat', bd=0, highlightthickness=0, padx=8, pady=5, undo=True)
    input_box.pack(fill='both', expand=True)
    ai_reply_widgets['input'] = input_box

    # --- length selector (segmented glass buttons)
    length_choice = _AILengthChoice('Short')
    ai_reply_widgets['length'] = length_choice
    ai_reply_widgets['length_var'] = tk.StringVar(value='Short')
    def select_length(name, remember=True):
        length_choice.value = name.capitalize()
        if remember: _remember_setting('ai_length', length_choice.value)
        ai_reply_widgets['length_var'].set(length_choice.value)
        for k in NX_AI_LEN:
            style = f"nx_ai_{t}_len_{k}" + ('_on' if k == name else '')
            main_card_style_by_tag[f'ai_len_{k}'] = style
            item, art = main_card_image_items.get(f'ai_len_{k}'), ui_art.get(style)
            if item and art:
                try: canvas.itemconfigure(item, image=art)
                except Exception: pass
    for k, rect in NX_AI_LEN.items():
        place_btn(f'ai_len_{k}', f'len_{k}', rect, (lambda n=k: select_length(n)), k.upper())
    select_length((app_settings.get('ai_length') or 'Short').lower(), remember=False)

    # --- mode selector (Auto / Sexting / Girlfriend)
    mode_choice = _AILengthChoice('Auto')
    ai_reply_widgets['mode'] = mode_choice
    def select_mode(k, remember=True):
        mode_choice.value = NX_AI_MODE_NAME[k]
        if remember: _remember_setting('ai_mode', mode_choice.value)
        for kk in NX_AI_MODE:
            style = f"nx_ai_{t}_mode_{kk}" + ('_on' if kk == k else '')
            main_card_style_by_tag[f'ai_mode_{kk}'] = style
            item, art = main_card_image_items.get(f'ai_mode_{kk}'), ui_art.get(style)
            if item and art:
                try: canvas.itemconfigure(item, image=art)
                except Exception: pass
    for k, rect in NX_AI_MODE.items():
        place_btn(f'ai_mode_{k}', f'mode_{k}', rect, (lambda n=k: select_mode(n)), NX_AI_MODE_NAME[k].upper())
    _cur_mode = (app_settings.get('ai_mode') or 'Auto')
    select_mode(next((k for k, v in NX_AI_MODE_NAME.items() if v == _cur_mode), 'auto'), remember=False)

    # --- generated draft well
    ox, oy, ow, oh = NX_AI_OUT
    out_frame = tk.Frame(root, bg=well, bd=0, highlightthickness=0)
    out_frame.place(x=ox + 6, y=oy + 6, width=ow - 12, height=oh - 12)
    ai_reply_extra.append(out_frame)
    output_box = tk.Text(out_frame, wrap='word', font=TEXT_FONT, bg=well, fg=txt_col,
                         insertbackground=pal['accent'], selectbackground=pal['select'], selectforeground=pal['text'],
                         relief='flat', bd=0, highlightthickness=0, padx=8, pady=5, height=4)
    output_box.pack(fill='both', expand=True)
    output_box.config(state='disabled')
    ai_reply_widgets['output'] = output_box

    # --- action row
    acts = {'generate': lambda: _ai_generate(False), 'regenerate': lambda: _ai_generate(True),
            'copy': _ai_copy_reply, 'clear': _ai_clear_fields}
    act_labels = {'generate': 'GENERATE REPLY', 'regenerate': 'REGENERATE', 'copy': 'COPY DRAFT', 'clear': 'CLEAR'}
    for key, rect in NX_AI_ACT.items():
        btn = _AIImageButton(f'ai_{key}', key, acts[key])
        place_btn(btn.tag, key, rect, btn.invoke, act_labels[key])
        ai_reply_widgets[key] = btn

    status_item = add(canvas.create_text(54, 494, text='Checking local AI\u2026', anchor='w', width=790,
                                         font=('Segoe UI', 9), fill=pal['muted']))
    ai_reply_widgets['status'] = _AIStatusLine(status_item)
    if ai_reply_busy:
        _ai_set_busy(True)
    draw_back_button(535)
    root.after(250, _ai_check_local)


def _draw_poke_layout():
    """Online / Offline mode cards (glass artwork; labels baked in)."""
    global page, status_text_item, active_card_tag, main_card_bounds, main_card_image_items, main_card_style_by_tag
    page = 'poke'; clear_page()
    main_card_bounds = {}; main_card_image_items = {}; main_card_style_by_tag = {}; active_card_tag = None
    draw_header('POKE', 'Choose which spender mode you are working with')
    t = _nx_t()
    accent = '#ff62dc' if t == 'neon' else '#45c5f2'
    for tag, mode, label in (('mode_online', 'ONLINE', 'ONLINE SPENDERS'), ('mode_offline', 'OFFLINE', 'OFFLINE SPENDERS')):
        x, y = NX_POKE_POS[tag]
        style = f'nx_poke_{mode.lower()}_{t}' + ('_active' if active_mode == mode else '')
        _nx_place(tag, style, x, y, NX_POKE_W, NX_POKE_H, label, accent)
    status_text_item = add(canvas.create_text(450, 372, text='', font=('Segoe UI', 8, 'bold'), fill='#fff0fb' if t == 'neon' else '#90a8c0'))
    draw_back_button(422)


def draw_poke_normal():
    _draw_poke_layout()


def draw_poke_neon():
    _draw_poke_layout()


def draw_poke():
    if theme_mode == 'NEON':
        draw_poke_neon()
    else:
        draw_poke_normal()


def _ui(fn, *a, **k):
    """Run fn on the window thread: right away when already there, else queued (hotkeys now run in their own thread)."""
    if threading.current_thread() is threading.main_thread():
        return fn(*a, **k)
    try: root.after(0, lambda: fn(*a, **k))
    except Exception: pass
    return None


def _set_status_now(text, color=NEON_YELLOW):
    if status_text_item is not None:
        try: canvas.itemconfig(status_text_item,text=text,fill=color)
        except Exception: pass


def set_status(text,color=NEON_YELLOW):
    _ui(_set_status_now, text, color)

def _help_draw_shortcut_key(action, y, editing=False):
    """Glowing keycap for one editable shortcut (pre-rendered art + Poppins glyphs, no popup)."""
    t = _nx_t()
    kx, kw, kh = NX_KEY
    ky = y + 7
    tag = f'help_shortcut_{action}'
    style = f'nx_key_{t}' + ('_edit' if editing else '')
    main_card_style_by_tag[tag] = style
    main_card_bounds[tag] = (kx, ky, kx + kw, ky + kh)
    art = ui_art.get(style)
    if art is not None:
        main_card_image_items[tag] = add(canvas.create_image(kx - NX_KEY_M, ky - NX_KEY_M, image=art, anchor='nw'))
    else:
        _draw_capsule(kx, ky, kx + kw, ky + kh, '#101d2d' if theme_mode == 'NORMAL' else '#21102d',
                      '#49bde6' if theme_mode == 'NORMAL' else '#ff58d2')
    cx, cy = kx + kw / 2, ky + kh / 2
    if action == 'quit':
        if editing:
            press_art = ui_art.get(f'nx_keytxt_press_{t}')
            if press_art is not None:
                add(canvas.create_image(cx, cy, image=press_art, anchor='center'))
            else:
                add(canvas.create_text(cx, cy, text='PRESS A KEY', font=('Segoe UI', 8, 'bold'), fill=WHITE))
        else:
            add(canvas.create_text(cx, cy, text=_quit_label(), font=('Segoe UI', 9, 'bold'), fill=WHITE))
            nx_hover_tags.add(tag)
        return
    letter = {'poke': shortcut_poke, 'send': shortcut_send, 'timer': shortcut_timer, 'draft': shortcut_draft}[action]
    ctrl_art = ui_art.get(f'nx_keytxt_ctrl_{t}')
    press_art = ui_art.get(f'nx_keytxt_press_{t}')
    if editing:
        if press_art is not None:
            add(canvas.create_image(cx, cy, image=press_art, anchor='center'))
        else:
            add(canvas.create_text(cx, cy, text='PRESS A KEY', font=('Segoe UI', 8, 'bold'), fill=WHITE))
    elif ctrl_art is not None and ui_art.get(f'nx_g_{t}_k_{letter}') is not None:
        letter_art = ui_art[f'nx_g_{t}_k_{letter}']
        total = ctrl_art.width() + 3 + letter_art.width()
        sx = cx - total / 2.0
        add(canvas.create_image(int(round(sx)), cy, image=ctrl_art, anchor='w'))
        add(canvas.create_image(int(round(sx + ctrl_art.width() + 3)), cy, image=letter_art, anchor='w'))
    else:
        add(canvas.create_text(cx, cy, text=f'Ctrl + {letter}', font=('Segoe UI', 9, 'bold'), fill=WHITE))
    if not editing:
        nx_hover_tags.add(tag)


def draw_help():
    """Shortcut guide. Click a glowing key, then press a letter to change it - right here, no popup."""
    global page, status_text_item, main_card_bounds, main_card_image_items, main_card_style_by_tag, active_card_tag, help_edit_action
    if page != 'help':
        help_edit_action = None
    page = 'help'; clear_page()
    main_card_bounds = {}; main_card_image_items = {}; main_card_style_by_tag = {}; active_card_tag = None
    draw_header('HELP', 'Click a shortcut to change it')
    _nx_panel('help', NX_HELP_BOX, '#0d1521' if theme_mode == 'NORMAL' else '#100b1c')
    # Headings, explanations, the plain keycaps and row bands are baked into the panel art;
    # only the three editable keys are live items.
    for i, action_key in enumerate(('poke', 'send', 'timer', 'draft')):
        _help_draw_shortcut_key(action_key, NX_HELP_ROW_Y0 + i * NX_HELP_ROW_STEP, editing=(help_edit_action == action_key))
    _help_draw_shortcut_key('quit', NX_HELP_ROW_Y0 + 8 * NX_HELP_ROW_STEP, editing=(help_edit_action == 'quit'))
    hint = ('PRESS THE KEY THAT SHOULD CLOSE PokeFlow (Delete, End, F1-F12... or Ctrl + key)  \u2022  ESC TO CANCEL'
            if help_edit_action == 'quit' else
            'PRESS A LETTER (A\u2013Z) FOR THE NEW SHORTCUT  \u2022  ESC TO CANCEL' if help_edit_action else '')
    status_text_item = add(canvas.create_text(450, 528, text=hint, font=('Segoe UI', 8, 'bold'),
                                               fill='#ff82df' if theme_mode == 'NEON' else '#49bde6'))
    draw_back_button(550)


def _apply_shortcut(action, value):
    """Validate and store a new Ctrl+letter shortcut (same rules as before, no dialog)."""
    global shortcut_poke, shortcut_send, shortcut_timer, shortcut_draft, help_edit_action
    err = '#ff8bcf' if theme_mode == 'NEON' else '#e47782'
    current = {'poke': shortcut_poke, 'send': shortcut_send, 'timer': shortcut_timer, 'draft': shortcut_draft}[action]
    value = str(value).strip().upper()
    if len(value) != 1 or not value.isalpha():
        set_status('USE ONE LETTER FROM A TO Z', err)
        return False
    reserved = set('ACFSVXZWRNODLPB')
    if value in reserved and value != current:
        set_status(f'CTRL+{value} IS RESERVED  \u2022  PICK ANOTHER LETTER', err)
        return False
    bindings = {'poke': shortcut_poke, 'send': shortcut_send, 'timer': shortcut_timer, 'draft': shortcut_draft}
    if any(name != action and letter == value for name, letter in bindings.items()):
        set_status(f'CTRL+{value} IS ALREADY ASSIGNED  \u2022  PICK ANOTHER LETTER', err)
        return False
    old = current
    if action == 'poke': shortcut_poke = value
    elif action == 'send': shortcut_send = value
    elif action == 'draft': shortcut_draft = value
    else: shortcut_timer = value
    if not _save_app_settings():
        if action == 'poke': shortcut_poke = old
        elif action == 'send': shortcut_send = old
        elif action == 'draft': shortcut_draft = old
        else: shortcut_timer = old
        set_status('COULD NOT SAVE SHORTCUT', err)
        return False
    help_edit_action = None
    draw_help()
    set_status(f'SHORTCUT CHANGED  \u2022  CTRL+{value}', '#ff82df' if theme_mode == 'NEON' else '#49bde6')
    return True


def _apply_quit_key(key, with_ctrl):
    """Help page: store the key that closes PokeFlow. Letters / digits only together with Ctrl (typing must never close it)."""
    global quit_key, quit_ctrl, help_edit_action
    err = '#ff8bcf' if theme_mode == 'NEON' else '#e47782'
    if key in ('Shift_L', 'Shift_R', 'Control_L', 'Control_R', 'Alt_L', 'Alt_R', 'Caps_Lock', 'Super_L', 'Super_R'):
        return 'break'
    k = key.upper() if len(key) == 1 else key
    if k not in _QUIT_VK:
        set_status('USE Delete, End, Home, Insert, Page Up/Down, Pause, F1-F12 OR Ctrl + A LETTER', err)
        return 'break'
    if len(k) == 1 and not with_ctrl:
        set_status('A LETTER OR NUMBER NEEDS Ctrl (OTHERWISE TYPING WOULD CLOSE PokeFlow)', err)
        return 'break'
    if len(k) == 1 and with_ctrl and k in {shortcut_poke, shortcut_send, shortcut_timer, shortcut_draft, 'S', 'B', 'F', 'C', 'V', 'X', 'A', 'Z'}:
        set_status(f'CTRL+{k} IS ALREADY USED  \u2022  PICK ANOTHER KEY', err)
        return 'break'
    quit_key, quit_ctrl = k, bool(with_ctrl)
    _remember_setting('quit_key', quit_key)
    _remember_setting('quit_ctrl', quit_ctrl)
    help_edit_action = None
    draw_help()
    set_status(f'CLOSE PokeFlow  \u2022  {_quit_label().upper()}', '#ff82df' if theme_mode == 'NEON' else '#49bde6')
    return 'break'


def _help_on_key(event):
    global help_edit_action
    if page != 'help' or help_edit_action is None:
        return None
    key = str(getattr(event, 'keysym', '') or '')
    if key.lower() == 'escape':
        help_edit_action = None
        draw_help()
        return 'break'
    if help_edit_action == 'quit':
        return _apply_quit_key(key, bool(int(getattr(event, 'state', 0) or 0) & 0x4))
    if len(key) == 1 and key.isalpha():
        _apply_shortcut(help_edit_action, key)
        return 'break'
    if key in ('Shift_L', 'Shift_R', 'Control_L', 'Control_R', 'Alt_L', 'Alt_R', 'Caps_Lock', 'Super_L', 'Super_R'):
        return 'break'
    set_status('PRESS A LETTER FROM A TO Z  \u2022  ESC TO CANCEL', '#ff8bcf' if theme_mode == 'NEON' else '#e47782')
    return 'break'

def _settings_switch_palette(is_on):
    """Return compact, theme-aware colors for the Save Fan History slider."""
    accent = '#ff58d2' if theme_mode == 'NEON' else '#49bde6'
    if is_on:
        return {
            'fill': '#21102d' if theme_mode == 'NEON' else '#122b3c',
            'edge': accent,
            'knob': accent,
            'halo': '#ff8be4' if theme_mode == 'NEON' else '#83e4ff',
            'glint': '#fff0fc' if theme_mode == 'NEON' else '#f2fcff',
            'label': '#ffb4eb' if theme_mode == 'NEON' else '#a8edff',
        }
    return {
        # OFF remains dim, but keeps the active theme's hue instead of turning gray.
        'fill': '#211126' if theme_mode == 'NEON' else '#102638',
        'edge': '#873d7d' if theme_mode == 'NEON' else '#34799a',
        'knob': '#93417f' if theme_mode == 'NEON' else '#347b9e',
        'halo': '#59264f' if theme_mode == 'NEON' else '#285a75',
        'glint': '#ead5e8' if theme_mode == 'NEON' else '#d1edf8',
        'label': '#d08ac7' if theme_mode == 'NEON' else '#8fcde3',
    }


def _blend_hex_color(color_a, color_b, amount):
    """Linear blend between two #RRGGBB colors."""
    amount = max(0.0, min(1.0, float(amount)))
    a = tuple(int(color_a[i:i+2], 16) for i in (1, 3, 5))
    b = tuple(int(color_b[i:i+2], 16) for i in (1, 3, 5))
    values = tuple(round(x + (y-x)*amount) for x, y in zip(a, b))
    return '#%02x%02x%02x' % values


def _settings_switch_positions(sx, sw, sy):
    """Return knob center and state-label center for OFF and ON states."""
    cy = sy + 20
    return {
        False: (sx + 20, sx + 88, cy),
        True:  (sx + sw - 20, sx + 48, cy),
    }


def _animate_settings_switch(token, start_on, target_on, step, total_steps,
                             track_image_id, label_id, thumb_id, sx, sy, sw):
    """Blend Pillow-rendered glass track frames while the thumb image slides left/right."""
    if token != settings_switch_animation_token or page not in ('settings', 'additional'):
        return
    t = min(1.0, step / float(total_steps))
    eased = t*t*(3.0 - 2.0*t)
    start_colors = _settings_switch_palette(start_on)
    target_colors = _settings_switch_palette(target_on)
    label_color = _blend_hex_color(start_colors['label'], target_colors['label'], eased)

    start_frame = 14 if start_on else 0
    target_frame = 14 if target_on else 0
    frame_index = round(start_frame + (target_frame-start_frame)*eased)
    palette = 'neon' if theme_mode == 'NEON' else 'normal'
    track_image = ui_art.get(f'nx_toggle_{palette}_{frame_index:02d}')
    if track_image is not None:
        canvas.itemconfigure(track_image_id, image=track_image)

    positions = _settings_switch_positions(sx, sw, sy)
    start_knob, start_label, cy = positions[bool(start_on)]
    target_knob, target_label, _ = positions[bool(target_on)]
    knob_x = start_knob + (target_knob-start_knob)*eased
    label_x = start_label + (target_label-start_label)*eased
    # Image thumbs use a center point; the accessible vector fallback oval
    # instead requires its four bounding-box coordinates.
    if canvas.type(thumb_id) == 'image':
        canvas.coords(thumb_id, knob_x, cy)
    else:
        canvas.coords(thumb_id, knob_x-11, cy-11, knob_x+11, cy+11)
    canvas.coords(label_id, label_x, cy)
    canvas.itemconfigure(label_id,
                         text=('ON' if (target_on if t >= 0.5 else start_on) else 'OFF'),
                         fill=label_color)

    if step < total_steps:
        try:
            root.after(16, lambda: _animate_settings_switch(
                token, start_on, target_on, step+1, total_steps,
                track_image_id, label_id, thumb_id, sx, sy, sw))
        except Exception:
            pass
    else:
        final_frame = 14 if target_on else 0
        final_track = ui_art.get(f'nx_toggle_{palette}_{final_frame:02d}')
        if final_track is not None:
            canvas.itemconfigure(track_image_id, image=final_track)
        knob_x, label_x, cy = positions[bool(target_on)]
        if canvas.type(thumb_id) == 'image':
            canvas.coords(thumb_id, knob_x, cy)
        else:
            canvas.coords(thumb_id, knob_x-11, cy-11, knob_x+11, cy+11)
        canvas.coords(label_id, label_x, cy)
        canvas.itemconfigure(label_id, text=('ON' if target_on else 'OFF'),
                             fill=target_colors['label'])


REPOKE_SOUND_PATH = Path(__file__).with_name('sounds') / 'repoke_alert.wav'   # 10% quieter than the original clip


def _play_repoke_alert():
    if not notify_sound:
        return
    try:
        import winsound
        if REPOKE_SOUND_PATH.exists():
            winsound.PlaySound(str(REPOKE_SOUND_PATH), winsound.SND_FILENAME | winsound.SND_ASYNC)
            return
        winsound.MessageBeep(winsound.MB_ICONASTERISK)
    except Exception:
        try: root.bell()
        except Exception: pass


def start_repoke_timer_for_profile(profile_id, announce=True):
    """Start/restart the manual repoke reminder for a tracked profile."""
    key = str(profile_id or '').strip().casefold()
    if key not in poke_state:
        set_status('REPOKE TIMER NEEDS A SAVED PROFILE ID', '#ff8bcf')
        return False
    pending_repoke_profiles.discard(key)
    repoke_timers[key] = time.monotonic() + int(repoke_timer_seconds)
    _ui(_ensure_repoke_timer_tick)
    if page == 'history': _ui(draw_history)
    if announce:
        set_status(f'REPOKE REMINDER STARTED  •  {repoke_timer_seconds} SECONDS', '#ff82df' if theme_mode == 'NEON' else '#49bde6')
    return True


MENU_CLICK_SOUND_PATH = Path(__file__).with_name('sounds') / 'menu_click.wav'
_menu_click_cache = {}


def _menu_click_file(volume):
    """The click sound at the chosen volume (a quieter copy is made once and kept). None = muted."""
    volume = max(0, min(100, int(volume)))
    if volume <= 0:
        return None
    if volume >= 100 or not MENU_CLICK_SOUND_PATH.exists():
        return MENU_CLICK_SOUND_PATH if MENU_CLICK_SOUND_PATH.exists() else None
    if volume in _menu_click_cache:
        return _menu_click_cache[volume]
    try:
        import wave, array
        gain = (volume / 100.0) ** 2                    # feels like an even volume scale
        out_dir = POKE_HISTORY_PATH.parent / 'sound_cache'
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f'menu_click_{volume}.wav'
        if not out.exists():
            with wave.open(str(MENU_CLICK_SOUND_PATH), 'rb') as w:
                params = w.getparams(); frames = w.readframes(w.getnframes())
            if params.sampwidth != 2:
                return MENU_CLICK_SOUND_PATH
            a = array.array('h'); a.frombytes(frames)
            for k in range(len(a)):
                a[k] = int(a[k] * gain)
            with wave.open(str(out), 'wb') as w:
                w.setparams(params); w.writeframes(a.tobytes())
        _menu_click_cache[volume] = out
        return out
    except Exception:
        return MENU_CLICK_SOUND_PATH


def _play_menu_click():
    """Soft click for main-menu buttons only (not every button in the app)."""
    try:
        import winsound
        f = _menu_click_file(menu_volume)
        if f is not None:
            winsound.PlaySound(str(f), winsound.SND_FILENAME | winsound.SND_ASYNC)
    except Exception:
        pass


def reset_repoke_timer_for_profile(profile_id):
    """RESTART: stop the countdown / clear the DUE glow. It only runs again after START TIMER."""
    key = str(profile_id or '').strip().casefold()
    repoke_timers.pop(key, None)
    pending_repoke_profiles.discard(key)
    if page == 'history': draw_history()
    set_status('REPOKE TIMER RESET  \u2022  PRESS START TIMER TO RUN IT AGAIN', '#ff82df' if theme_mode == 'NEON' else '#49bde6')


# ----- pop-ups: repoke-timer toasts + local-AI check / setup dialogs -----
# Artwork comes from tools/render_popup_assets.py (same numbers as POP_* below).
try:
    import ai_setup
except Exception:
    ai_setup = None

POP_TOAST_W, POP_TOAST_H = 420, 130          # window incl. baked glow margin; the card is (10,10)-(410,120)
POP_TOAST_STEP = 126                         # vertical pitch of stacked toasts
POP_TOAST_LIFE = 8.0                         # seconds before a timer toast fades away by itself
POP_BTN_Y = 79
POP_BTN_X = {'pop_restart': 28, 'pop_copy': 160, 'pop_dismiss': 254, 'pop_ok': 28, 'pop_report': 28, 'pop_update': 28}
POP_BTN_SIZE = {'pop_restart': (122, 30), 'pop_copy': (84, 30), 'pop_dismiss': (84, 30), 'pop_ok': (84, 30), 'pop_report': (122, 30), 'pop_update': (122, 30)}
POP_DLG_W, POP_DLG_H = 520, 300
POP_DLG_BTN = {'dlg_install': (34, 226, 210, 38), 'dlg_notnow': (254, 226, 110, 38), 'dlg_close': (34, 226, 110, 38),
               'dlg_hide': (34, 226, 190, 38), 'dlg_cancel': (234, 226, 110, 38)}
POP_BAR = (34, 188, 452, 14)

pop_toasts = []                              # stacked timer / info toasts (oldest sits lowest)
ai_state = {'status': 'checking', 'reason': '', 'info': {}, 'installing': False, 'cancel': False,
            'frac': 0.0, 'text': '', 'error': ''}
ai_dialog = {'win': None, 'variant': None, 'cv': None, 'items': {}}


def _pop_theme():
    neon = theme_mode == 'NEON'
    # same palette as the on-screen SHORTCUTS card (flat dark card, thin border, blue / pink accent)
    return {'t': 'neon' if neon else 'normal', 'accent': '#ff5cd6' if neon else '#49bde6',
            'well': '#160a19' if neon else '#0f1116', 'txt': '#fff3fc' if neon else '#eef2f8',
            'muted': '#d6a0d0' if neon else '#96a0b4', 'good': '#70e4b3', 'bad': '#ff9b9b'}


_acct_map = {}          # FansMetric window (hwnd) -> OnlyFans account shown in it (kept fresh by _acct_watch_worker)


def _acct_hwnd(acct):
    """The FansMetric window currently showing this account (None if none)."""
    if not acct:
        return None
    for h, a in list(_acct_map.items()):
        if a == acct:
            return h
    return None


def _acct_watch_worker():
    """Every 20 s: which account is open in which FansMetric window (follows you when you switch accounts)."""
    time.sleep(4)
    try:
        import uiautomation as auto
        import uia_reader as _ur
    except Exception:
        return
    with auto.UIAutomationInitializerInThread():
        readers = {}
        while not _pb.get('stop'):
            try:
                live = set()
                for w in find_fansmetric_windows():
                    h = int(getattr(w, '_hWnd', 0) or 0)
                    if not h:
                        continue
                    live.add(h)
                    rd = readers.get(h) or readers.setdefault(h, _ur.UiaReader())
                    rd._acct_at = 0                                # fresh read, not the 1-minute cache
                    a = rd.account_name(h)
                    if a and _acct_map.get(h) != a:
                        if _acct_map.get(h):
                            _pb_log(f'Accounts: window {h} switched {_acct_map.get(h)} -> {a}')
                        _acct_map[h] = a
                for h in list(_acct_map):
                    if h not in live:
                        _acct_map.pop(h, None)
                        readers.pop(h, None)
            except Exception as exc:
                _pb_log(f'Accounts watch error: {exc!r}'[:160])
            time.sleep(20.0)


def _current_account():
    """Account of the FansMetric window you are working in right now ('' if unknown)."""
    try:
        w = find_fansmetric_window_cached()
        return _acct_map.get(int(getattr(w, '_hWnd', 0) or 0), '') if w is not None else ''
    except Exception:
        return ''


def _pop_area_for(hwnd):
    """Work area (no taskbar) of the monitor this FansMetric window is on; the main monitor when unknown."""
    if hwnd and os.name == 'nt':
        try:
            class _MI(ctypes.Structure):
                _fields_ = [('cb', ctypes.c_ulong), ('rm', ctypes.c_long * 4), ('rw', ctypes.c_long * 4), ('f', ctypes.c_ulong)]
            u = ctypes.windll.user32
            u.MonitorFromWindow.restype = ctypes.c_void_p
            mon = u.MonitorFromWindow(ctypes.c_void_p(int(hwnd)), 2)            # nearest monitor
            mi = _MI(); mi.cb = ctypes.sizeof(_MI)
            if mon and u.GetMonitorInfoW(ctypes.c_void_p(mon), ctypes.byref(mi)) and mi.rw[2] > mi.rw[0]:
                return int(mi.rw[0]), int(mi.rw[1]), int(mi.rw[2]), int(mi.rw[3])
        except Exception:
            pass
    return _pop_work_area()


def _pop_work_area():
    try:
        class _RECT(ctypes.Structure):
            _fields_ = [('l', ctypes.c_long), ('t', ctypes.c_long), ('r', ctypes.c_long), ('b', ctypes.c_long)]
        r = _RECT()
        if ctypes.windll.user32.SystemParametersInfoW(48, 0, ctypes.byref(r), 0) and r.r > r.l:
            return int(r.l), int(r.t), int(r.r), int(r.b)
    except Exception:
        pass
    return 0, 0, int(root.winfo_screenwidth() or 1920), int(root.winfo_screenheight() or 1080) - 48


def _pop_no_activate(win):
    """Show over FansMetric without taking keyboard focus (Windows: WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW)."""
    if os.name != 'nt':
        return
    try:
        win.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(win.winfo_id()) or win.winfo_id()
        style = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
        ctypes.windll.user32.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x00000080)
    except Exception:
        pass


POP_KEY = '#010001'      # 'transparent colour' of the pop-up art: everything outside the rounded card is see-through


_popth = {'wins': [], 'seen': None}


def _pop_track(win):
    """Remember a PokeFlow pop-up so a theme switch can restyle it while it is open."""
    _popth['wins'] = [w for w in _popth['wins'] if _pop_alive(w)] + [win]
    return win


def _pop_alive(win):
    try:
        return bool(win.winfo_exists())
    except Exception:
        return False


def _pop_recolor(win, old, new):
    """Swap every old-theme colour / picture in the pop-up for the new theme's one."""
    cmap = {str(old[k]).lower(): new[k] for k in old if k != 't' and old[k] != new.get(k)}
    names = {str(img): k for k, img in ui_art.items()}
    a, b = old['t'], new['t']
    def swap_img(nm):
        k = names.get(str(nm))
        if not k:
            return None
        k2 = re.sub(r'(?<=_)%s(?=_|$)' % a, b, k)
        return ui_art.get(k2) if k2 != k else None
    stack = [win]
    while stack:
        w = stack.pop()
        stack.extend(w.winfo_children())
        if isinstance(w, tk.Canvas):
            for it in w.find_all():
                typ = w.type(it)
                if typ == 'image':
                    im = swap_img(w.itemcget(it, 'image'))
                    if im is not None:
                        w.itemconfigure(it, image=im)
                    continue
                for opt in ('fill', 'outline'):
                    try:
                        v = str(w.itemcget(it, opt)).lower()
                    except Exception:
                        continue
                    if v in cmap:
                        w.itemconfigure(it, **{opt: cmap[v]})
        for opt in ('bg', 'fg', 'insertbackground', 'highlightbackground', 'highlightcolor'):
            try:
                v = str(w.cget(opt)).lower()
            except Exception:
                continue
            if v in cmap:
                try: w.configure(**{opt: cmap[v]})
                except Exception: pass


def _pop_theme_watch():
    """Called every 0.25 s: theme switched while pop-ups are open -> each fades out, changes look, fades back in."""
    th = _pop_theme()
    old = _popth['seen']
    _popth['seen'] = th
    if old is None or old['t'] == th['t']:
        return
    for win in [w for w in _popth['wins'] if _pop_alive(w)]:
        fw = {'top': win, 'alpha': 1.0, 'job': None}
        def swap(win=win, fw=fw):
            if not _pop_alive(win):
                return
            try:
                _pop_recolor(win, old, _pop_theme())
            except Exception as exc:
                _pb_log(f'Pop-up restyle failed: {exc!r}'[:120])
            _ph_fade(fw, 1.0, 14)
        _ph_fade(fw, 0.0, 12, swap)


def _pop_window(w, h, x, y):
    win = tk.Toplevel(root)
    try: win.overrideredirect(True)
    except Exception: pass
    try: win.attributes('-topmost', True)
    except Exception: pass
    win.configure(bg=POP_KEY)
    win.geometry(f'{w}x{h}+{x}+{y}')
    try: win.attributes('-transparentcolor', POP_KEY)       # round corners, no dark rectangle behind them
    except Exception: pass
    _pop_no_activate(win)
    return win


def _pop_ease_out(t):
    return 1 - (1 - t) ** 3


def _pop_ease_pop(t):
    """Ease-out with a tiny overshoot: the pop-up 'pops' into place."""
    c1 = 1.25; c3 = c1 + 1
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2


def _pop_move(item, x, y, frames=14, ease=_pop_ease_out, done=None):
    """Glide a pop-up window from where it is now to (x, y) (frame-based, ~60 fps)."""
    if item.get('anim_job') is not None:
        try: root.after_cancel(item['anim_job'])
        except Exception: pass
    sx, sy = item.get('cx', x), item.get('cy', y)
    w, h = item['w'], item['h']

    def step(n):
        if item.get('destroyed'):
            return
        e = 1.0 if n >= frames else ease(n / float(frames))
        item['cx'], item['cy'] = sx + (x - sx) * e, sy + (y - sy) * e
        try: item['win'].geometry(f"{w}x{h}+{int(round(item['cx']))}+{int(round(item['cy']))}")
        except Exception: pass
        if n < frames:
            item['anim_job'] = root.after(16, lambda: step(n + 1))
        else:
            item['anim_job'] = None
            if done:
                done()
    step(0)


def _pop_destroy(item):
    item['destroyed'] = True
    try: item['win'].destroy()
    except Exception: pass


def _pop_add_button(cv, key, x, y, w, h, fn):
    """Glass image button on a pop-up canvas (hover art, hand cursor)."""
    def arts():                                              # looked up each time: follows a theme switch
        style = f"nx_btn_{_pop_theme()['t']}_{key}"
        return ui_art.get(style), ui_art.get(style + '_hover')
    art, hov = arts()
    if art is None:
        return None
    item = cv.create_image(x - 8, y - 8, image=art, anchor='nw')
    cv.tag_bind(item, '<Enter>', lambda e: (cv.itemconfigure(item, image=arts()[1] or arts()[0]), cv.configure(cursor='hand2')))
    cv.tag_bind(item, '<Leave>', lambda e: (cv.itemconfigure(item, image=arts()[0]), cv.configure(cursor='')))
    cv.tag_bind(item, '<Button-1>', lambda e: fn())
    return item


def _pop_layout_toasts():
    left, top, right, bottom = _pop_work_area()
    shift = 0
    try:
        for _pop in (draft_popup.get('item'),):
            if _pop is not None and not _pop.get('closed'):
                shift = max(shift, _pop['h'] - 14 - 10 + 8)      # keep the notifications above the open pop-up
    except NameError:
        pass
    slot = {}
    main_area = (left, top, right, bottom)
    for item in pop_toasts:
        area = _pop_area_for(item.get('hwnd'))                # each account's pop-ups on ITS FansMetric's monitor
        item['area'] = area
        left, top, right, bottom = area
        i = slot.get(area, 0)
        slot[area] = i + 1
        x = right - POP_TOAST_W - 4
        y = bottom - 12 - (shift if area == main_area else 0) - i * POP_TOAST_STEP - 120   # card bottom edge at window y+120
        item['x'], item['y'] = x, y
        if 'cx' not in item:                                  # brand new: start just off the right edge, then pop in
            item['cx'], item['cy'] = right + 30, y
            try: item['win'].geometry(f"{POP_TOAST_W}x{POP_TOAST_H}+{int(item['cx'])}+{y}")
            except Exception: pass
            _pop_move(item, x, y, frames=20, ease=_pop_ease_pop)
        else:                                                 # others glide down/up to their new slot
            _pop_move(item, x, y, frames=12)


def _pop_close_toast(item):
    """Slide out to the right, then remove. The other toasts glide into the gap."""
    if item.get('closed'):
        return
    item['closed'] = True
    try: pop_toasts.remove(item)
    except ValueError: pass
    _pop_layout_toasts()
    left, top, right, bottom = item.get('area') or _pop_area_for(item.get('hwnd'))
    _pop_move(item, right + 30, item.get('cy', item['y']), frames=10, ease=lambda t: t * t, done=lambda: _pop_destroy(item))


def _text_w(text, font_spec):
    """Width in pixels of `text` in this font (char estimate if fonts can't be measured)."""
    try:
        import tkinter.font as _tkfont
        return int(_tkfont.Font(root=root, font=font_spec).measure(str(text)))
    except Exception:
        return int(len(str(text)) * (font_spec[1] if len(font_spec) > 1 else 9) * 0.75)


def _pop_fit(text, font_spec, max_px, max_chars):
    """Cut `text` with an ellipsis so it always stays inside the pop-up card (measured; char count as fallback)."""
    text = str(text or '').replace('\n', ' ').strip()
    try:
        import tkinter.font as _tkfont
        f = _tkfont.Font(root=root, font=font_spec)
        if f.measure(text) <= max_px:
            return text
        while text and f.measure(text + '…') > max_px:
            text = text[:-1]
        return text.rstrip() + '…'
    except Exception:
        return text if len(text) <= max_chars else text[:max_chars - 1].rstrip() + '…'


def _pop_follow_tick():
    """FansMetric window moved to another monitor -> its open pop-ups move with it."""
    try:
        if any(_pop_area_for(it.get('hwnd')) != it.get('area') for it in pop_toasts if not it.get('closed')):
            _pop_layout_toasts()
    except Exception:
        pass
    try: root.after(800, _pop_follow_tick)
    except Exception: pass


def _pop_show_toast(kind, title, sub, buttons, key=None, life=POP_TOAST_LIFE, note=None, acct=None, hwnd=None):
    """kind: 'repoke' | 'ai'. buttons: list of (button_key, handler(item)).
    acct / hwnd: which account / FansMetric window it is about (default: the one you are in) - the pop-up shows on
    that window's monitor with the account name on it."""
    if hwnd is None and acct:
        hwnd = _acct_hwnd(acct)
    if hwnd is None and kind not in ('ai',):
        try:
            w = find_fansmetric_window_cached()
            hwnd = (int(getattr(w, '_hWnd', 0) or 0) or None) if w is not None else None
        except Exception:
            hwnd = None
    if not acct and hwnd:
        acct = _acct_map.get(hwnd, '')
    th = _pop_theme()
    art = ui_art.get(f"nx_pop_toast{'' if kind == 'repoke' else '_' + kind}_{th['t']}") or ui_art.get(f"nx_pop_toast_ai_{th['t']}")
    win = _pop_track(_pop_window(POP_TOAST_W, POP_TOAST_H, _pop_area_for(hwnd)[2] + 60, 0))     # created off-screen, slides in
    cv = tk.Canvas(win, width=POP_TOAST_W, height=POP_TOAST_H, bd=0, highlightthickness=0, bg=POP_KEY)
    cv.pack(fill='both', expand=True)
    if art is not None:
        cv.create_image(0, 0, image=art, anchor='nw')
    else:
        cv.create_text(30, 27, text={'repoke': 'REPOKE TIMER UP', 'ai': 'LOCAL AI', 'spend': 'PLATFORM-WIDE SPEND', 'welcome': 'AUTOWELCOME'}.get(kind, 'POKEFLOW'), anchor='w',
                       font=('Segoe UI', 8, 'bold'), fill=th['accent'])
    text = _pop_fit(title, ('Segoe UI', 13, 'bold'), 360, 27)
    title_item = cv.create_text(30, 54, text=text, anchor='w', font=('Segoe UI', 13, 'bold'), fill=th['txt'])
    if acct and kind != 'ai':                                           # which account this is about - always visible
        _an = _pop_fit(acct, ('Segoe UI', 9, 'bold'), 170 if not note else 120, 22)
        cv.create_text(390, 27, text=_an, anchor='e', font=('Segoe UI', 9, 'bold'), fill=th['accent'])
        _nx = 390 - _text_w(_an, ('Segoe UI', 9, 'bold')) - 12
    else:
        _nx = 390
    note_item = cv.create_text(_nx, 27, text=_pop_fit(note, ('Segoe UI', 8), max(40, _nx - 160), 24) if note else '',
                               anchor='e', font=('Segoe UI', 8), fill=th['muted'])
    if sub and kind == 'welcome' and not buttons:                      # info-style welcome note: full-width 2nd line
        cv.create_text(30, 84, text=_pop_fit(sub, ('Segoe UI', 11), 360, 52), anchor='w', font=('Segoe UI', 11), fill=th['muted'])
    elif sub and kind == 'welcome':                                    # 2nd line, left of the DISMISS button
        cv.create_text(30, 86, text=_pop_fit(sub, ('Segoe UI', 10), 215, 34), anchor='w', font=('Segoe UI', 10), fill=th['muted'])
    elif sub and kind in ('bundle', 'spend'):                                       # 2nd line, readable - no OK button on this one
        cv.create_text(30, 84, text=_pop_fit(sub, ('Segoe UI', 11), 360, 52), anchor='w', font=('Segoe UI', 11), fill=th['muted'])
    elif False and kind == 'spend':                                         # 'Justin spent $28  27 minutes ago' - one line
        try:
            x2 = cv.bbox(title_item)[2] + 10                       # right after the bold title
        except Exception:
            x2 = 220
        cv.create_text(x2, 55, text=_pop_fit(sub, ('Segoe UI', 11), max(60, 390 - x2), 24), anchor='w', font=('Segoe UI', 11), fill=th['muted'])
    elif sub:
        cv.create_text(30, 69, text=_pop_fit(sub, ('Segoe UI', 8), 360, 58), anchor='w', font=('Segoe UI', 8), fill=th['muted'])
    bar = cv.create_line(28, 114, 392, 114, fill=th['accent'], width=2, capstyle=tk.ROUND)
    item = {'win': win, 'cv': cv, 'kind': kind, 'key': key, 'life': float(life), 'note_item': note_item,
            'deadline': time.monotonic() + float(life), 'last': time.monotonic(), 'closed': False, 'x': 0, 'y': 0,
            'w': POP_TOAST_W, 'h': POP_TOAST_H, 'hwnd': hwnd, 'acct': acct or ''}
    for bkey, handler in buttons:
        w, h = POP_BTN_SIZE[bkey]
        _pop_add_button(cv, bkey, POP_BTN_X[bkey] if len(buttons) > 1 or bkey != 'pop_ok' else POP_BTN_X['pop_ok'],
                        POP_BTN_Y, w, h, lambda hd=handler, it=item: hd(it))
    if not buttons:
        cv.bind('<Button-1>', lambda e, it=item: _pop_close_toast(it))  # click anywhere on it to close
    pop_toasts.append(item)
    _pop_layout_toasts()
    try: win.lift()
    except Exception: pass

    def tick():
        if item['closed']:
            return
        if kind == 'repoke' and key not in pending_repoke_profiles:
            _pop_close_toast(item)           # handled elsewhere (Fans History, Ctrl+T ...)
            return
        now = time.monotonic()
        try:
            px, py = root.winfo_pointerx(), root.winfo_pointery()
            hovering = item['x'] <= px <= item['x'] + POP_TOAST_W and item['y'] <= py <= item['y'] + POP_TOAST_H
        except Exception:
            hovering = False
        if hovering:                          # stay open while the mouse is on it
            item['deadline'] += now - item['last']
        item['last'] = now
        remaining = item['deadline'] - now
        if remaining <= 0:
            _pop_close_toast(item)
            return
        try: cv.coords(bar, 28, 114, 28 + 364 * remaining / item['life'], 114)
        except Exception: pass
        root.after(100, tick)
    root.after(100, tick)
    return item


def show_repoke_toast(profile_key):
    if POKEFLOW_LITE:
        return None                                   # Lite: no timer notifications
    """A fan's repoke timer ran out: tell the chatter (name + RESTART TIMER / COPY ID / DISMISS)."""
    try:
        key = str(profile_key)
        if any(i['kind'] == 'repoke' and i['key'] == key and not i['closed'] for i in pop_toasts):
            return None
        name = str((poke_state.get(key) or {}).get('name') or '').strip() or 'Unknown spender'

        def restart(it):
            _pop_close_toast(it)
            start_repoke_timer_for_profile(key)

        def copy_id(it):
            copy_history_profile_id(key)
            try:
                it['cv'].itemconfigure(it['note_item'], text='ID COPIED', fill=_pop_theme()['good'])
            except Exception: pass

        def dismiss(it):
            pending_repoke_profiles.discard(key)          # DISMISS also stops his glow inside Fans History
            _pop_close_toast(it)
            if page == 'history':
                draw_history()

        return _pop_show_toast('repoke', name, None,
                               [('pop_restart', restart), ('pop_copy', copy_id), ('pop_dismiss', dismiss)],
                               key=key, note='ID  ' + (key if len(key) <= 18 else key[:17] + '…'),
                               acct=str((poke_state.get(key) or {}).get('account') or '') or None)
    except Exception:
        return None


def show_ai_ready_toast():
    return _pop_show_toast('ai', 'AI is installed and ready', '',
                           [('pop_ok', lambda it: _pop_close_toast(it))], life=12.0)


# ---- local-AI status / dialogs --------------------------------------------
def _ai_is_ready():
    return ai_setup is None or ai_state['status'] in ('ready', 'checking')


def _ai_summary_style():
    return f"nx_btn_{_pop_theme()['t']}_" + ('summary' if _ai_is_ready() else 'sum_off')


def _ai_refresh_status():
    """Look (in the background) whether Ollama + the model are installed and whether this PC can run them."""
    if ai_setup is None or ai_state['installing']:
        return
    def work():
        try:
            status, reason, info = ai_setup.status()
        except Exception:
            status, reason, info = 'ready', '', {}          # a failed check must never lock the user out
        def apply():
            if ai_state['installing']:
                return
            ai_state.update(status=status, reason=reason, info=info)
            _ai_status_changed()
        try: root.after(0, apply)
        except Exception: pass
    threading.Thread(target=work, daemon=True, name='PokeFlow-AI-Status').start()


def _ai_status_changed():
    try:
        if page == 'main':
            draw_main()
        elif page == 'notes' and 'notes_summary' in main_card_image_items:
            style = _ai_summary_style()
            main_card_style_by_tag['notes_summary'] = style
            art = ui_art.get(style)
            if art is not None:
                canvas.itemconfigure(main_card_image_items['notes_summary'], image=art)
    except Exception:
        pass


def _ai_dialog_close():
    win = ai_dialog.get('win')
    _anim = ai_dialog.get('anim')
    if _anim is not None:
        _anim['destroyed'] = True
    ai_dialog.update(win=None, variant=None, cv=None, items={}, anim=None)
    try:
        if win is not None: win.destroy()
    except Exception:
        pass


def _ai_dialog_body(variant, body):
    info = ai_state.get('info') or {}
    if variant == 'ask':
        lines = ['The AI is downloaded once, then it runs on this PC.', '',
                 'Will download in the background' + (' (about 6 GB):' if not info.get('ollama') else ' (about 5 GB):')]
        if not info.get('ollama'):
            lines.append('   •  Ollama, the local AI engine  (about 1.2 GB)')
        lines.append('   •  Qwen3 8B, the AI model  (about 5.0 GB)')
        return '\n'.join(lines)
    if variant == 'bad':
        return (body or ai_state.get('reason') or 'This PC does not meet the requirements.') + \
               '\n\nAI Reply and AI Summary stay switched off on this PC. Everything else in PokeFlow works as normal.'
    if variant == 'busy':
        return ('The local AI is already being installed by another PokeFlow window on this PC.\n\n'
                'Wait for it to finish (you will get a notification), then use AI Reply or AI Summary.')
    if variant == 'fail':
        return f'The download did not finish:\n{body or "unknown error"}\n\nClick the AI button again to retry.'
    return ''


def _ai_dialog_show(variant, body=None):
    """variant: 'ask' | 'prog' | 'bad' | 'busy' | 'fail'."""
    if variant == 'prog' and ai_dialog.get('variant') == 'prog' and ai_dialog.get('win') is not None:
        try:
            ai_dialog['win'].lift()
            _ai_dialog_update()
            return ai_dialog['win']
        except Exception:
            pass
    _ai_dialog_close()
    th = _pop_theme()
    left, top, right, bottom = _pop_work_area()
    try:
        if root.state() == 'normal' and root.winfo_rootx() > -1000:
            x = root.winfo_rootx() + (W - POP_DLG_W) // 2
            y = root.winfo_rooty() + (H - POP_DLG_H) // 2
        else:
            raise ValueError
    except Exception:
        x, y = left + (right - left - POP_DLG_W) // 2, top + (bottom - top - POP_DLG_H) // 2
    win = _pop_track(_pop_window(POP_DLG_W, POP_DLG_H, x, y + 30))
    cv = tk.Canvas(win, width=POP_DLG_W, height=POP_DLG_H, bd=0, highlightthickness=0, bg=POP_KEY)
    cv.pack(fill='both', expand=True)
    _dlg_item = {'win': win, 'w': POP_DLG_W, 'h': POP_DLG_H, 'cx': x, 'cy': y + 30}
    _pop_move(_dlg_item, x, y, frames=14, ease=_pop_ease_pop)      # slides up into place
    art = ui_art.get(f"nx_pop_dlg_{'bad' if variant == 'busy' else variant}_{th['t']}")
    if art is not None:
        cv.create_image(0, 0, image=art, anchor='nw')
    ai_dialog.update(win=win, variant=variant, cv=cv, items={}, anim=_dlg_item)
    if variant == 'prog':
        bx, by, bw, bh = POP_BAR
        ai_dialog['items']['status'] = cv.create_text(34, 134, text='', anchor='w', font=('Segoe UI', 11, 'bold'), fill=th['txt'])
        _again = (body == 'again')
        cv.create_text(34, 158, text=("Already installing, nothing was restarted. You'll be notified when it's ready." if _again
                                      else "PokeFlow stays usable. You'll get a notification when it's ready."), anchor='w',
                       font=('Segoe UI', 9), fill=th['muted'])
        cv.create_rectangle(bx, by, bx + bw, by + bh, fill=th['well'], outline=th['accent'])
        ai_dialog['items']['fill'] = cv.create_rectangle(bx + 2, by + 2, bx + 2, by + bh - 2, fill=th['accent'], outline='')
        ai_dialog['items']['pct'] = cv.create_text(bx + bw, by - 12, text='0%', anchor='e', font=('Segoe UI', 9, 'bold'), fill=th['accent'])
        _ai_dialog_update()
    else:
        cv.create_text(34, 112, text=_ai_dialog_body(variant, body), anchor='nw', width=452, justify='left',
                       font=('Segoe UI', 10), fill=th['bad'] if variant == 'fail' and False else th['txt'])
    buttons = {'ask': [('dlg_install', _ai_install_start), ('dlg_notnow', _ai_dialog_close)],
               'prog': [('dlg_hide', _ai_dialog_close), ('dlg_cancel', _ai_install_cancel)],
               'bad': [('dlg_close', _ai_dialog_close)],
               'busy': [('dlg_close', _ai_dialog_close)],
               'fail': [('dlg_close', _ai_dialog_close)]}[variant]
    for bkey, fn in buttons:
        bx, by, bw, bh = POP_DLG_BTN[bkey]
        _pop_add_button(cv, bkey, bx, by, bw, bh, fn)
    try: win.lift()
    except Exception: pass
    return win


def _ai_dialog_update():
    cv = ai_dialog.get('cv')
    if cv is None or ai_dialog.get('variant') != 'prog':
        return
    items = ai_dialog['items']
    bx, by, bw, bh = POP_BAR
    frac = max(0.0, min(1.0, ai_state['frac']))
    try:
        cv.itemconfigure(items['status'], text=ai_state['text'] or 'Starting…')
        cv.itemconfigure(items['pct'], text=f'{int(frac * 100)}%')
        cv.coords(items['fill'], bx + 2, by + 2, bx + 2 + (bw - 4) * frac, by + bh - 2)
    except Exception:
        pass


def _ai_gate():
    """True when local AI is ready; otherwise shows the right pop-up and returns False."""
    if ai_setup is not None and ai_state['status'] == 'checking' and not ai_state['installing']:
        # The start-up check has not finished yet: finish it now (max 4 s) instead of letting the user in unchecked.
        box = {}
        def _quick():
            try: box['r'] = ai_setup.status()
            except Exception: box['r'] = ('ready', '', {})
        th = threading.Thread(target=_quick, daemon=True, name='PokeFlow-AI-Gate'); th.start(); th.join(4.0)
        if 'r' in box:
            ai_state.update(status=box['r'][0], reason=box['r'][1], info=box['r'][2])
            _ai_status_changed()
        else:
            ai_state['status'] = 'missing'
    if ai_state['status'] == 'ready' or ai_setup is None:
        return True
    if ai_state['installing']:
        _ai_dialog_show('prog', 'again')
    elif ai_state['status'] == 'unavailable':
        _ai_dialog_show('bad')
    else:
        _ai_dialog_show('ask')
    return False


def _ai_install_cancel():
    ai_state['cancel'] = True
    ai_state['text'] = 'Cancelling…'
    _ai_dialog_update()


def _ai_install_start():
    if ai_setup is None:
        return
    _t = ai_state.get('thread')
    if ai_state['installing'] or (_t is not None and _t.is_alive()):   # already running: just show its progress, never start a second one
        _ai_dialog_show('prog', 'again')
        return
    try:
        if not ai_setup.acquire_install_lock():       # another PokeFlow window is installing
            _ai_dialog_show('busy')
            return
    except Exception:
        pass
    info = dict(ai_state.get('info') or {})
    ai_state.update(installing=True, cancel=False, frac=0.0, text='Starting…', error='')
    _ai_dialog_show('prog')
    last = [0.0]

    def progress(frac, text):
        ai_state['frac'], ai_state['text'] = frac, text
        now = time.monotonic()
        if now - last[0] >= 0.2 or frac >= 1.0:
            last[0] = now
            try: root.after(0, _ai_dialog_update)
            except Exception: pass

    def work():
        try:
            ai_setup.install(progress, lambda: ai_state['cancel'], have_ollama=bool(info.get('ollama')), have_model=bool(info.get('model')))
            result = ('ok', '')
        except ai_setup.Cancelled:
            result = ('cancel', '')
        except Exception as exc:
            result = ('error', str(exc) or type(exc).__name__)
        try: root.after(0, lambda: _ai_install_done(*result))
        except Exception: pass
    ai_state['thread'] = threading.Thread(target=work, daemon=True, name='PokeFlow-AI-Install')
    ai_state['thread'].start()


def _ai_install_done(result, message):
    ai_state['installing'] = False
    try: ai_setup.release_install_lock()
    except Exception: pass
    if result == 'ok':
        ai_state.update(status='ready', reason='', info={'ollama': True, 'model': True})
        was_open = ai_dialog.get('variant') == 'prog'
        _ai_dialog_close()
        _play_repoke_alert()
        show_ai_ready_toast()
        _ai_status_changed()
    elif result == 'cancel':
        _ai_dialog_close()
        _ai_refresh_status()
    else:
        ai_state['error'] = message
        _ai_dialog_show('fail', message)
        _ai_refresh_status()


def _ensure_repoke_timer_tick():
    global repoke_timer_tick_running
    if repoke_timer_tick_running: return
    repoke_timer_tick_running = True
    def tick():
        global repoke_timer_tick_running
        now = time.monotonic(); expired=[]
        for key, deadline in list(repoke_timers.items()):
            remaining = int(deadline - now + 0.999)
            if remaining <= 0:
                expired.append(key)
            elif page == 'history' and key in repoke_timer_text_items:
                try: _nx_update_time_items(key, remaining)
                except Exception: pass
        if expired:
            for key in expired:
                repoke_timers.pop(key, None)
                if key in poke_state:
                    pending_repoke_profiles.add(key)
                    show_repoke_toast(key)
            _play_repoke_alert()
            if page == 'history': draw_history()
            set_status('REPOKE REMINDER  •  CHECK THE FAN CHAT', '#ff82df' if theme_mode == 'NEON' else '#49bde6')
        if repoke_timers:
            root.after(250, tick)
        else:
            repoke_timer_tick_running = False
    root.after(250, tick)


def _settings_draw_timer_value():
    """Repoke seconds as m:ss, drawn with the same Poppins glyph art as the other labels."""
    global settings_step_value_ids
    for i in settings_step_value_ids:
        try: canvas.delete(i)
        except Exception: pass
    vx, vy, vw, vh = NX_STEP_VALUE
    settings_step_value_ids = _nx_draw_text_glyphs(vx + vw / 2, vy + vh / 2, _nx_fmt_time(repoke_timer_seconds), 'v')


settings_vol_value_ids = []
settings_vol_items = {'track': None, 'knob': None}
settings_vol_drag = False


def _settings_vol_build():
    sx, sy, sw, sh = NX_VOL_SLIDER
    palette = 'neon' if theme_mode == 'NEON' else 'normal'
    frame = ui_art.get(f'nx_slider_{palette}_{int(round(menu_volume / 5)):02d}')
    if frame is not None:
        settings_vol_items['track'] = add(canvas.create_image(sx - NX_SWITCH_PAD, sy - NX_SWITCH_PAD, image=frame, anchor='nw'))
    else:
        settings_vol_items['track'] = add(canvas.create_rectangle(sx, sy + 13, sx + sw, sy + 27, fill='#09121e', outline='#49bde6'))
    thumb = ui_art.get(f'nx_toggle_thumb_{palette}')
    kx = sx + 14 + (sw - 28) * menu_volume / 100.0
    if thumb is not None:
        settings_vol_items['knob'] = add(canvas.create_image(kx, sy + sh / 2, image=thumb, anchor='center'))
    else:
        settings_vol_items['knob'] = add(canvas.create_oval(kx - 11, sy + sh / 2 - 11, kx + 11, sy + sh / 2 + 11, fill='#49bde6', outline=''))
    _settings_draw_volume_value()


def _settings_draw_volume_value():
    global settings_vol_value_ids
    for i in settings_vol_value_ids:
        try: canvas.delete(i)
        except Exception: pass
    sx, sy, sw, sh = NX_VOL_SLIDER
    settings_vol_value_ids = _nx_draw_text_glyphs(NX_VOL_VALUE_X, sy + sh / 2, str(int(menu_volume)), 'v')


def _settings_vol_update():
    """Move the knob and light the track up to it (no full redraw while dragging)."""
    sx, sy, sw, sh = NX_VOL_SLIDER
    palette = 'neon' if theme_mode == 'NEON' else 'normal'
    frame = ui_art.get(f'nx_slider_{palette}_{int(round(menu_volume / 5)):02d}')
    kx = sx + 14 + (sw - 28) * menu_volume / 100.0
    try:
        if frame is not None and settings_vol_items['track'] is not None:
            canvas.itemconfigure(settings_vol_items['track'], image=frame)
        if settings_vol_items['knob'] is not None:
            canvas.coords(settings_vol_items['knob'], kx, sy + sh / 2)
    except Exception:
        pass
    _settings_draw_volume_value()


def _vol_from_x(x):
    sx, sy, sw, sh = NX_VOL_SLIDER
    v = (x - (sx + 14)) / float(sw - 28) * 100.0
    return int(max(0, min(100, round(v / 5.0) * 5)))


def settings_vol_press(event):
    global settings_vol_drag
    settings_vol_drag = True
    settings_vol_move(event)


def settings_vol_move(event):
    global menu_volume
    if not settings_vol_drag or page != 'settings':
        return
    v = _vol_from_x(event.x)
    if v != menu_volume:
        menu_volume = v
        _settings_vol_update()


def settings_vol_release(_event=None):
    """Let go: save the volume, say it, and play the click once so you hear the level."""
    global settings_vol_drag
    if not settings_vol_drag:
        return
    settings_vol_drag = False
    _remember_setting('menu_volume', int(menu_volume))
    set_status('MENU SOUND  \u2022  ' + ('MUTED' if menu_volume == 0 else f'VOLUME {menu_volume}'),
               '#ff82df' if theme_mode == 'NEON' else '#49bde6')
    _play_menu_click()


def change_menu_volume(direction):
    """Keyboard-free helper (used by tests): step the volume by 10 and save it."""
    global menu_volume
    new = max(0, min(100, int(menu_volume) + 10 * direction))
    if new == menu_volume:
        return
    menu_volume = new
    _remember_setting('menu_volume', int(menu_volume))
    if page == 'settings':
        _settings_vol_update()


def _settings_step_once():
    global repoke_timer_seconds, settings_step_changed
    n = settings_step_count
    step = 10 if n < 12 else (30 if n < 30 else 60)
    new = max(10, min(3600, int(repoke_timer_seconds) + settings_step_dir * step))
    if new != repoke_timer_seconds:
        repoke_timer_seconds = new
        settings_step_changed = True
        _settings_draw_timer_value()


def _settings_step_tick():
    global settings_step_job, settings_step_count
    if settings_step_dir == 0 or page != 'settings':
        settings_step_job = None
        return
    settings_step_count += 1
    _settings_step_once()
    settings_step_job = root.after(70, _settings_step_tick)


def _settings_step_start(direction):
    """Press [-] / [+]: change once, then keep going (faster) while the button is held."""
    global settings_step_job, settings_step_dir, settings_step_count, settings_step_changed
    _settings_step_stop()
    settings_step_dir = direction
    settings_step_count = 0
    settings_step_changed = False
    _settings_step_once()
    settings_step_job = root.after(380, _settings_step_tick)


def _settings_step_stop(_event=None):
    global settings_step_job, settings_step_dir, settings_step_changed
    if settings_step_job is not None:
        try: root.after_cancel(settings_step_job)
        except Exception: pass
        settings_step_job = None
    was_active = settings_step_dir != 0
    settings_step_dir = 0
    if was_active and settings_step_changed:
        settings_step_changed = False
        if not _save_app_settings():
            set_status('COULD NOT SAVE TIMER SETTING', '#ff8bcf' if theme_mode == 'NEON' else '#e47782')
        else:
            set_status(f'REPOKE TIMER  \u2022  {_nx_fmt_time(repoke_timer_seconds)}', '#ff82df' if theme_mode == 'NEON' else '#49bde6')


def _draw_settings_switch(tag, rect, target_state, start_state, token):
    """Glass slider (Pillow track + moving glowing thumb) for one settings row."""
    sx, sy, sw, sh = rect
    switch_pad = NX_SWITCH_PAD
    main_card_bounds[tag] = (sx, sy, sx+sw, sy+sh)
    main_card_style_by_tag[tag] = 'settings_switch'
    start_colors = _settings_switch_palette(start_state)
    palette = 'neon' if theme_mode == 'NEON' else 'normal'
    start_frame = 14 if start_state else 0
    track_art = ui_art.get(f'nx_toggle_{palette}_{start_frame:02d}')
    if track_art is not None:
        track_id = add(canvas.create_image(sx-switch_pad, sy-switch_pad, image=track_art, anchor='nw'))
    else:
        track_id = add(canvas.create_rectangle(sx, sy, sx+sw, sy+sh,
                    fill=start_colors['fill'], outline=start_colors['edge'], width=2))
    positions = _settings_switch_positions(sx, sw, sy)
    knob_x, label_x, cy = positions[start_state]
    thumb_art = ui_art.get(f'nx_toggle_thumb_{palette}')
    if thumb_art is not None:
        thumb_id = add(canvas.create_image(knob_x, cy, image=thumb_art, anchor='center'))
    else:
        thumb_id = add(canvas.create_oval(knob_x-11, cy-11, knob_x+11, cy+11,
                                          fill=start_colors['knob'], outline=start_colors['edge'], width=1))
    label_id = add(canvas.create_text(label_x, cy, text=('ON' if start_state else 'OFF'),
                                      font=('Segoe UI', 9, 'bold'), fill=start_colors['label']))
    if start_state != target_state:
        _animate_settings_switch(token, start_state, target_state, 0, 14,
                                 track_id, label_id, thumb_id, sx, sy, sw)


def _draw_model_name_entry(rect):
    """MODEL'S NAME entry (Advanced Notes): native Entry inside the baked glass well, saved as you type."""
    global ai_reply_extra
    wx, wy, ww, wh = rect
    neon = theme_mode == 'NEON'
    well = '#10061c' if neon else '#0a1220'
    accent = '#ff62dc' if neon else '#45c5f2'
    muted = '#8f7aa3' if neon else '#6f869c'
    txt = '#fff7ff' if neon else '#f1f6fc'
    holder = tk.Frame(root, bg=well, bd=0, highlightthickness=0)
    holder.place(x=wx + 10, y=wy + 6, width=ww - 20, height=wh - 12)
    ai_reply_extra.append(holder)
    var = tk.StringVar(value=model_names)
    entry = tk.Entry(holder, textvariable=var, font=('Segoe UI', 10), bg=well, fg=txt, insertbackground=accent,
                     relief='flat', bd=0, highlightthickness=0, selectbackground='#54204f' if neon else '#174261',
                     selectforeground='white')
    entry.pack(fill='both', expand=True)
    placeholder = "Model's name, e.g. Lily, Meg"
    state = {'ph': False, 'job': None}
    def show_ph():
        if not var.get().strip():
            state['ph'] = True; var.set(placeholder); entry.config(fg=muted)
    def hide_ph(_e=None):
        if state['ph']:
            state['ph'] = False; var.set(''); entry.config(fg=txt)
    def commit(_e=None):
        global model_names
        value = '' if state['ph'] else re.sub(r'\s+', ' ', var.get()).strip()[:120]
        if value != model_names:
            model_names = value
            _save_app_settings()
    def on_write(*_):
        if state['ph']:
            return
        global model_names
        model_names = re.sub(r'\s+', ' ', var.get()).strip()[:120]
        try:
            if state['job'] is not None: root.after_cancel(state['job'])
            state['job'] = root.after(500, commit)
        except Exception:
            pass
    def focus_out(_e=None):
        commit(); show_ph()
    entry.bind('<FocusIn>', hide_ph)
    entry.bind('<FocusOut>', focus_out)
    entry.bind('<Return>', lambda e: (commit(), canvas.focus_set(), 'break')[-1])
    if not model_names:
        show_ph()
    var.trace_add('write', on_write)


def draw_settings(animate_switch_from=None, animate_anti_from=None, animate_sound_from=None, animate_bg_from=None, animate_poke_from=None, animate_keys_from=None):
    global page, status_text_item, active_card_tag, main_card_image_items, main_card_style_by_tag, main_card_bounds
    page='settings'; clear_page()
    animation_token = settings_switch_animation_token
    main_card_bounds = {}
    main_card_image_items = {}
    main_card_style_by_tag = {}
    draw_header('SETTINGS','Appearance, repoke timer and sounds')

    theme_accent = '#ff38c8' if theme_mode == 'NEON' else '#49bde6'
    # All four setting rows (titles + descriptions) are baked into one glass panel.
    art = ui_art.get(f'nx_panel_settings_{_nx_t()}')
    if art is not None:
        add(canvas.create_image(NX_SET_PANEL[0] - NX_M, NX_SET_PANEL[1] - NX_M, image=art, anchor='nw'))
    else:
        for _ty, _tt in ((160,'CHANGE THEME'),(304,'REPOKE TIMER'),(376,'ANTI 3-SECONDS BLOCK'),(448,'NOTIFICATION SOUND'),(480,'ANIMATED BACKGROUND'),(512,'POKE ALERTS'),(544,'MENU SOUND VOLUME')):
            add(canvas.create_text(176,_ty,text=_tt,font=('Segoe UI',13,'bold'),fill=WHITE,anchor='w'))

    # --- CHANGE THEME
    x,y,theme_w,theme_h = NX_THEME_BTN
    key = f'nx_theme_btn_{_nx_t()}_{theme_mode.lower()}'
    main_card_style_by_tag['settings_theme']=key
    main_card_bounds['settings_theme']=(x,y,x+theme_w,y+theme_h)
    art=ui_art.get(key)
    if art:
        main_card_image_items['settings_theme']=add(canvas.create_image(x-NX_THEME_BTN_M,y-NX_THEME_BTN_M,image=art,anchor='nw'))
    else:
        add(canvas.create_rectangle(x,y,x+theme_w,y+theme_h,fill='#09121e',outline=theme_accent,width=1))
        add(canvas.create_text(x+theme_w/2,y+theme_h/2,text=theme_mode,font=('Segoe UI',9,'bold'),fill=WHITE))
    nx_hover_tags.add('settings_theme')

    # --- REPOKE TIMER: [-] [m:ss] [+] in place, no popup
    for tag, rect, kind in (('settings_step_minus', NX_STEP_MINUS, 'minus'), ('settings_step_plus', NX_STEP_PLUS, 'plus')):
        _nx_place(tag, f'nx_step_{_nx_t()}_{kind}', rect[0], rect[1], rect[2], rect[3], kind, theme_accent, margin=NX_STEP_M)
    val_art = ui_art.get(f'nx_step_{_nx_t()}_value')
    vx, vy, vw, vh = NX_STEP_VALUE
    if val_art is not None:
        add(canvas.create_image(vx - NX_STEP_M, vy - NX_STEP_M, image=val_art, anchor='nw'))
    else:
        add(canvas.create_rectangle(vx, vy, vx+vw, vy+vh, fill='#09121e', outline=theme_accent, width=1))
    _settings_draw_timer_value()

    # --- NOTIFICATION SOUND
    sound_target = bool(notify_sound)
    sound_start = bool(animate_sound_from) if animate_sound_from is not None else sound_target
    _draw_settings_switch('settings_sound', NX_SWITCH_SOUND, sound_target, sound_start, animation_token)

    # --- ANIMATED BACKGROUND
    bg_target = bool(animated_bg)
    bg_start = bool(animate_bg_from) if animate_bg_from is not None else bg_target
    _draw_settings_switch('settings_bg', NX_SWITCH_BG, bg_target, bg_start, animation_token)

    # --- SHORTCUTS ON SCREEN
    ks_target = bool(shortcut_overlay_on)
    ks_start = bool(animate_keys_from) if animate_keys_from is not None else ks_target
    _draw_settings_switch('settings_keys', NX_SWITCH_KEYS, ks_target, ks_start, animation_token)

    # --- MENU SOUND VOLUME: slider (drag, or click anywhere on the track)
    sx, sy, sw, sh = NX_VOL_SLIDER
    main_card_bounds['settings_vol'] = (sx - 12, sy, sx + sw + 12, sy + sh)
    main_card_style_by_tag['settings_vol'] = 'settings_slider'
    _settings_vol_build()

    status_text_item = add(canvas.create_text(450, 519, text='', font=('Segoe UI', 8, 'bold'), fill=theme_accent))
    draw_back_button(535)


def toggle_animated_bg_setting():
    global animated_bg
    previous = animated_bg
    animated_bg = not animated_bg
    _remember_setting('animated_bg', bool(animated_bg))
    try: _set_theme_background(theme_mode)
    except Exception: pass
    draw_settings(animate_bg_from=previous)
    set_status('ANIMATED BACKGROUND ON  \u2022  PAUSES AUTOMATICALLY WHEN PokeFlow IS IN THE BACKGROUND' if animated_bg
               else 'ANIMATED BACKGROUND OFF  \u2022  STILL IMAGE, LOWEST CPU USE',
               '#ff82df' if theme_mode == 'NEON' else '#49bde6')


def toggle_poke_badges_setting():
    global poke_badges_enabled
    previous = poke_badges_enabled
    poke_badges_enabled = not poke_badges_enabled
    _remember_setting('poke_badges', bool(poke_badges_enabled))
    if not poke_badges_enabled:
        _pb_hide_now()
    draw_additional_features(animate_poke_from=previous) if page == 'additional' else draw_settings()
    set_status('POKE ALERTS ON  \u2022  HOVER A FAN ON THE LIST TO SEE HIS POKE STAGE' if poke_badges_enabled
               else 'POKE ALERTS OFF',
               '#ff82df' if theme_mode == 'NEON' else '#49bde6')


# ======================= SHORTCUTS ON SCREEN (small list in the bottom-left corner of the screen) =======================
_ks = {'win': None, 'key': None, 'shown': False, 'close': None, 'hover': False, 'job': None}
_KS_W = 300


def _ks_rows():
    L = lambda c: str(c or '').upper()[:1]
    return [('Ctrl+' + L(shortcut_poke), 'Prepare poke / cancel'),
            ('Ctrl+S', 'Prepare poke with "babe" / cancel'),
            ('Ctrl+' + L(shortcut_send), 'Send, anti 3 seconds / cancel'),
            ('Ctrl+' + L(shortcut_timer), 'Save ID + repoke timer'),
            ('Ctrl+' + L(shortcut_draft), 'AI draft'),
            ('Ctrl+B', 'Fix banned words'),
            (_quit_label().replace(' + ', '+'), 'Close PokeFlow')]


def _ks_render(tname, rows, hover_x=False):
    """Glass card: SHORTCUTS header with an x, then keycap + action per row. Drawn 4x and scaled down."""
    from PIL import Image, ImageDraw
    SS = 4
    T = _PH_THEME.get(tname, _PH_THEME['normal'])
    W, H = _KS_W, 40 + 25 * len(rows) + 10
    im = Image.new('RGB', (W * SS, H * SS), (1, 0, 1))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, W * SS - 1, H * SS - 1), 14 * SS, fill=T['bg'], outline=T['line'], width=SS * T['lw'])
    d.text((16 * SS, 21 * SS), 'SHORTCUTS', font=_ph_font(12 * SS, True), fill=T['ui'], anchor='lm')
    cx, cy, r = (W - 22) * SS, 21 * SS, 10 * SS                      # x button
    if hover_x:
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=T['line'])
    k = 4 * SS
    d.line((cx - k, cy - k, cx + k, cy + k), fill=T['sub'], width=2 * SS)
    d.line((cx - k, cy + k, cx + k, cy - k), fill=T['sub'], width=2 * SS)
    d.line((16 * SS, 36 * SS, (W - 16) * SS, 36 * SS), fill=T['line'], width=SS)
    kf, af = _ph_font(10 * SS, True), _ph_font(10 * SS, False)
    col = max(int(d.textlength(k_, font=kf)) for k_, _ in rows) + 14 * SS + 12 * SS     # one aligned action column
    for i, (key, act) in enumerate(rows):
        y = (40 + 25 * i + 12) * SS
        kw = int(d.textlength(key, font=kf)) + 14 * SS
        d.rounded_rectangle((16 * SS, y - 9 * SS, 16 * SS + kw, y + 9 * SS), 6 * SS, outline=T['ui'], width=SS)
        d.text((16 * SS + kw / 2, y), key, font=kf, fill=T['ui'], anchor='mm')
        d.text((16 * SS + col, y), act, font=af, fill=T['text'] if 'text' in T else T['sub'], anchor='lm')
    return im.resize((W, H), Image.LANCZOS)


def _ks_close():
    """The x on the card: hides it and turns the setting off (Settings -> SHORTCUTS ON SCREEN brings it back)."""
    global shortcut_overlay_on
    shortcut_overlay_on = False
    _remember_setting('shortcut_overlay', False)
    _ks_hide()
    try:
        if page == 'settings':
            draw_settings(animate_keys_from=True)
    except Exception:
        pass
    try: set_status('SHORTCUTS HIDDEN  •  SETTINGS → SHORTCUTS ON SCREEN SHOWS THEM AGAIN', '#ff82df' if theme_mode == 'NEON' else '#49bde6')
    except Exception: pass


def _ks_hide():
    """Fade the card out (~190 ms) and take it off the screen."""
    w = _ks.get('win')
    if w is not None and _ks['shown'] and not _ks.get('fading'):
        _ks['fading'] = True

        def gone():
            try: w['top'].withdraw()
            except Exception: pass
            _ks['shown'] = False
            _ks['fading'] = False
        _ph_fade(w, 0.0, 12, gone)


def _ks_build():
    tname = 'neon' if theme_mode == 'NEON' else 'normal'
    rows = _ks_rows()
    key = (tname, tuple(rows))
    w = _ks.get('win')
    if w is not None and _ks['key'] == key:
        return w
    if w is not None:
        try: w['top'].destroy()
        except Exception: pass
    im, imh = _ks_render(tname, rows), _ks_render(tname, rows, True)
    W, H = im.size
    top = _pop_window(W, H, -3000, -3000)
    cv = tk.Canvas(top, width=W, height=H, bd=0, highlightthickness=0, bg=POP_KEY, cursor='arrow')
    cv.pack(fill='both', expand=True)
    ph = [ImageTk.PhotoImage(im, master=cv), ImageTk.PhotoImage(imh, master=cv)]
    item = cv.create_image(0, 0, image=ph[0], anchor='nw')
    xr = (W - 36, 7, W - 8, 35)

    def on_x(ev):
        return xr[0] <= ev.x <= xr[2] and xr[1] <= ev.y <= xr[3]

    def motion(ev):
        hv = on_x(ev)
        if hv != _ks['hover']:
            _ks['hover'] = hv
            cv.itemconfigure(item, image=ph[1 if hv else 0])
            cv.configure(cursor='hand2' if hv else 'arrow')

    def leave(_ev=None):
        if _ks['hover']:
            _ks['hover'] = False
            cv.itemconfigure(item, image=ph[0]); cv.configure(cursor='arrow')

    def click(ev):
        if on_x(ev):
            _ks_close()
    cv.bind('<Motion>', motion); cv.bind('<Leave>', leave); cv.bind('<Button-1>', click)
    top.withdraw()
    w = {'top': top, 'cv': cv, 'ph': ph, 'W': W, 'H': H, 'alpha': 0.0, 'job': None}
    _ks['win'], _ks['key'], _ks['shown'] = w, key, False
    return w


def _ks_wanted_key():
    return ('neon' if theme_mode == 'NEON' else 'normal', tuple(_ks_rows()))


def _ks_show_new():
    """Build the card for the current theme / shortcuts and fade it in (bottom-left corner)."""
    w = _ks_build()
    left, top_, right, bottom = _pop_work_area()
    w['top'].geometry('%dx%d+%d+%d' % (w['W'], w['H'], int(left + 14), int(bottom - w['H'] - 14)))
    w['alpha'] = 0.0; w['job'] = None
    try: w['top'].attributes('-alpha', 0.0)
    except Exception: pass
    w['top'].deiconify()
    try: w['top'].attributes('-topmost', True)
    except Exception: pass
    _ks['shown'] = True
    _ph_fade(w, 1.0, 14)                                  # ~220 ms fade in


def _ks_tick():
    """Every 0.25 s: card on/off, and a smooth fade out -> new look -> fade in when the theme or a shortcut changes.
    It stays up while hotkeys run (it sits in the corner, away from everything they read)."""
    try: _pop_theme_watch()
    except Exception: pass
    try:
        if not shortcut_overlay_on:
            _ks_hide()
        elif _ks.get('fading'):
            pass
        elif not _ks['shown']:
            _ks_show_new()
        elif _ks['key'] != _ks_wanted_key():
            w = _ks['win']
            _ks['fading'] = True

            def swap():
                try: w['top'].withdraw()
                except Exception: pass
                _ks['shown'] = False
                _ks['fading'] = False
                _ks_show_new()
            _ph_fade(w, 0.0, 12, swap)                    # ~190 ms fade out, then the new theme fades in
    except Exception:
        _ks['fading'] = False
    _ks['job'] = root.after(250, _ks_tick)


def toggle_shortcut_overlay_setting():
    global shortcut_overlay_on
    previous = shortcut_overlay_on
    shortcut_overlay_on = not shortcut_overlay_on
    _remember_setting('shortcut_overlay', bool(shortcut_overlay_on))
    if not shortcut_overlay_on:
        _ks_hide()
    draw_settings(animate_keys_from=previous)
    set_status('SHORTCUTS ON SCREEN  •  BOTTOM-LEFT CORNER  •  x ON THE CARD HIDES THEM' if shortcut_overlay_on
               else 'SHORTCUTS ON SCREEN OFF',
               '#ff82df' if theme_mode == 'NEON' else '#49bde6')



def toggle_anti_block_setting():
    global anti_block_enabled
    previous = anti_block_enabled
    anti_block_enabled = not anti_block_enabled
    _remember_setting('anti_block_enabled', bool(anti_block_enabled))
    draw_additional_features(animate_anti_from=previous) if page == 'additional' else draw_settings()
    set_status('ANTI 3-SECONDS BLOCK ON  \u2022  RETRIES UNTIL THE COMPOSER CLEARS' if anti_block_enabled
               else 'ANTI 3-SECONDS BLOCK OFF  \u2022  ONE SEND ATTEMPT PER SHORTCUT',
               '#ff82df' if theme_mode == 'NEON' else '#49bde6')


def toggle_notify_sound_setting():
    global notify_sound
    previous = notify_sound
    notify_sound = not notify_sound
    _remember_setting('notify_sound', bool(notify_sound))
    draw_settings(animate_sound_from=previous)
    if notify_sound:
        _play_repoke_alert()                       # let the user hear what it sounds like
    set_status('NOTIFICATION SOUND ON  \u2022  TIMER ALERTS PLAY A SOUND' if notify_sound
               else 'NOTIFICATION SOUND OFF  \u2022  TIMER ALERTS ARE SILENT',
               '#ff82df' if theme_mode == 'NEON' else '#49bde6')


def toggle_save_profile_ids_setting():
    global save_profile_ids, prepared_profile_id
    previous = save_profile_ids
    save_profile_ids = not save_profile_ids
    if not _save_app_settings():
        save_profile_ids = previous
        draw_settings()
        set_status('COULD NOT SAVE SETTING • CHECK APP DATA PERMISSIONS', '#ff8bcf' if theme_mode == 'NEON' else '#e47782')
        return
    if not save_profile_ids:
        # A later Ctrl+E must not attribute this send to a tracked history record.
        prepared_profile_id = ''
        status = 'SAVE FAN HISTORY OFF • HISTORY DISABLED'
    else:
        status = 'SAVE FAN HISTORY ON • HISTORY ENABLED'
    draw_settings(animate_switch_from=previous)
    set_status(status, '#ff82df' if theme_mode == 'NEON' else '#49bde6')


def _ai_autostart_ollama():
    """If Ollama exists, start its local server quietly during app startup."""
    def work():
        try:
            ok, message = _ai_start_ollama_service()
        except Exception as exc:
            ok, message = False, f'Ollama auto-start failed ({type(exc).__name__}).'
        if not ok:
            try: print('[PokeFlow AI]', message)
            except Exception: pass
    threading.Thread(target=work, daemon=True, name='PokeFlow-Ollama-Autostart').start()


class _GlassScrollbar(tk.Canvas):
    """Slim themed scrollbar (replaces the grey system one). Works with Text.yview."""
    def __init__(self, master, bg, thumb, command=None, **kw):
        super().__init__(master, width=10, bg=bg, highlightthickness=0, bd=0, **kw)
        self._thumb_col = thumb; self._cmd = command; self._lo = 0.0; self._hi = 1.0
        self.bind('<Button-1>', self._press); self.bind('<B1-Motion>', self._press)
        self.bind('<Configure>', lambda e: self._paint())
    def set(self, lo, hi):
        self._lo, self._hi = float(lo), float(hi); self._paint()
    def _paint(self):
        try:
            self.delete('all')
            h = max(1, self.winfo_height())
            if self._hi - self._lo >= 0.999: return
            y1 = 2 + self._lo * (h - 4); y2 = max(y1 + 18, 2 + self._hi * (h - 4))
            self.create_rectangle(3, y1, 8, y2, fill=self._thumb_col, outline=self._thumb_col)
        except Exception:
            pass
    def _press(self, e):
        try:
            h = max(1, self.winfo_height()); span = self._hi - self._lo
            if self._cmd: self._cmd('moveto', max(0.0, min(1.0 - span, e.y / h - span / 2)))
        except Exception:
            pass


class _CanvasLabel:
    """Tiny shim so the notes logic can keep calling label.config(text=, fg=)."""
    def __init__(self, x, y, anchor, font, fg, text=''):
        self.item = add(canvas.create_text(x, y, text=text, anchor=anchor, font=font, fill=fg))
    def config(self, **kw):
        opts = {}
        if 'text' in kw: opts['text'] = kw['text']
        if 'fg' in kw: opts['fill'] = kw['fg']
        try: canvas.itemconfigure(self.item, **opts)
        except Exception: pass
    configure = config


def _ai_summarize_advanced_notes(notes_widget, palette):
    source = notes_widget.get('1.0', 'end-1c').strip()
    if not source:
        messagebox.showinfo('AI Summary', 'Add some notes first, then try AI Summary.')
        return
    if len(source) > 24000:
        if not messagebox.askyesno('AI Summary', 'These notes exceed 24,000 characters. Summarize the first 24,000 characters?'):
            return
    neon = palette == 'neon'
    accent = '#ff62dc' if neon else '#45c5f2'
    well = '#10061c' if neon else '#0a1220'
    txt = '#fff7ff' if neon else '#f1f6fc'
    muted = '#d1bfdf' if neon else '#a8bfd5'
    win = tk.Toplevel(root)
    win.title('PokeFlow \u2022 AI Notes Summary')
    win.geometry('780x620'); win.resizable(False, False)
    win.configure(bg=well)
    win.transient(root)
    _schedule_native_titlebar_theme('NEON' if neon else 'NORMAL', win)
    cv = tk.Canvas(win, width=780, height=620, bd=0, highlightthickness=0, bg=well)
    cv.pack(fill='both', expand=True)
    bg_img = ui_art.get(f'nx_sum_bg_{palette}')
    if bg_img is not None:
        cv.create_image(0, 0, image=bg_img, anchor='nw')
    else:
        cv.create_text(34, 62, text='AI NOTES SUMMARY', anchor='w', font=('Segoe UI', 16, 'bold'), fill=accent)
    wx, wy, ww, wh = 30, 106, 720, 404
    holder = tk.Frame(win, bg=well, bd=0, highlightthickness=0)
    holder.place(x=wx + 8, y=wy + 8, width=ww - 16, height=wh - 16)
    sb = _GlassScrollbar(holder, well, accent)
    sb.pack(side='right', fill='y')
    output = tk.Text(holder, wrap='word', font=TEXT_FONT, bg=well, fg=txt, insertbackground=accent,
                     selectbackground='#54204f' if neon else '#174261', selectforeground='white',
                     relief='flat', bd=0, highlightthickness=0, padx=10, pady=8, yscrollcommand=sb.set)
    output.pack(side='left', fill='both', expand=True)
    sb._cmd = output.yview
    output.tag_configure('head', foreground=accent, font=('Segoe UI', 10, 'bold'), spacing1=8, spacing3=2)
    output.tag_configure('cite', foreground=muted, font=('Segoe UI', 8))
    output.tag_configure('note', foreground=muted, font=('Segoe UI', 9, 'italic'))
    output.insert('1.0', 'Summarizing notes locally\u2026', 'note')
    output.config(state='disabled')
    status_item = cv.create_text(320, 553, text='Ollama is working in the background.', anchor='w',
                                 font=('Segoe UI', 9), fill=muted)
    def set_status(text, color=None):
        try: cv.itemconfigure(status_item, text=text, fill=color or muted)
        except Exception: pass
    def render(text):
        output.config(state='normal'); output.delete('1.0', 'end')
        for raw in (text or '').splitlines(True):
            line = raw.strip()
            if line and (line.isupper() or (line.endswith(':') and len(line) < 48)) and not line.startswith(('-', '\u2022', '*')):
                output.insert('end', raw, 'head')
                continue
            pos = 0
            for m in re.finditer(r'\[L[\d,\s\-L]+\]', raw):
                output.insert('end', raw[pos:m.start()]); output.insert('end', m.group(0), 'cite'); pos = m.end()
            output.insert('end', raw[pos:])
        output.config(state='disabled')
    held = {'text': ''}
    btns = {}
    def add_btn(key, x, y, w, h, fn, label):
        style = f'nx_btn_{palette}_{key}'
        art = ui_art.get(style); hov = ui_art.get(style + '_hover')
        if art is None:
            b = tk.Button(win, text=label, command=fn, relief='flat', bg=well, fg=accent, bd=0, cursor='hand2')
            b.place(x=x, y=y, width=w, height=h); return
        item = cv.create_image(x - 8, y - 8, image=art, anchor='nw')
        btns[key] = (x, y, w, h, fn)
        cv.tag_bind(item, '<Enter>', lambda e: (cv.itemconfigure(item, image=hov or art), cv.configure(cursor='hand2')))
        cv.tag_bind(item, '<Leave>', lambda e: (cv.itemconfigure(item, image=art), cv.configure(cursor='')))
        cv.tag_bind(item, '<Button-1>', lambda e: fn())
    def copy_summary():
        text = held['text'].strip()
        if text:
            root.clipboard_clear(); root.clipboard_append(text); root.update_idletasks()
            set_status('Summary copied to clipboard.', '#70e4b3')
    add_btn('sum_copy', 30, 534, 150, 38, copy_summary, 'COPY SUMMARY')
    add_btn('sum_close', 190, 534, 110, 38, win.destroy, 'CLOSE')
    win.bind('<Escape>', lambda e: win.destroy())
    def work():
        try:
            summary = _ai_summarize_notes(source, model_names=model_names); error = None
        except Exception as exc:
            summary = ''; error = str(exc)
        def finish():
            try:
                if not win.winfo_exists(): return
            except Exception: return
            if error:
                render('AI summary failed: ' + error)
                set_status('Check that Ollama and the Qwen model are installed.', '#ff9b9b')
            else:
                held['text'] = summary; render(summary)
                set_status('Ready. Verify important details before relying on the summary.', '#70e4b3')
        try: root.after(0, finish)
        except Exception: pass
    threading.Thread(target=work, daemon=True, name='PokeFlow-AI-Notes-Summary').start()
    return win


def draw_notes():
    global page, notes_state, main_card_bounds, main_card_image_items, main_card_style_by_tag, active_card_tag
    global ai_reply_extra, ai_click_map
    page='notes'; clear_page()
    main_card_bounds = {}; main_card_image_items = {}; main_card_style_by_tag = {}; active_card_tag = None
    ai_click_map = {}
    draw_header('ADVANCED NOTES','Search, date sorting and restore \u2014 all in the same window')
    palette = 'neon' if theme_mode == 'NEON' else 'normal'
    t = palette
    notes_accent = '#ff62dc' if palette == 'neon' else '#45c5f2'
    well = '#10061c' if palette == 'neon' else '#0a1220'            # identical to the baked wells
    notes_match_bg = '#58235f' if palette == 'neon' else '#164d70'
    notes_current_bg = '#d916ae' if palette == 'neon' else '#237fb4'
    notes_muted = '#c8b8d8' if palette == 'neon' else '#a8bfd5'
    txt_col = '#fff7ff' if palette == 'neon' else '#f1f6fc'
    _nx_panel('notes', NX_NOTES_BOX, '#0d1521' if palette == 'normal' else '#100b1c')
    if notes_state.get('frame') is not None:
        try: notes_state['frame'].destroy()
        except Exception: pass
        notes_state['frame'] = None
    match_label = _CanvasLabel(854, 156, 'e', ('Segoe UI', 9, 'bold'), notes_muted, '0 matches')
    sort_status = _CanvasLabel(46, 227, 'w', ('Segoe UI', 8, 'bold'), notes_accent, 'DATED NOTES (0)   \u2022   UNDATED NOTES (0)')
    # --- search entry in baked well
    sx, sy, sw, sh = 46, 166, 400, 36
    search_var=tk.StringVar()
    entry_holder = tk.Frame(root, bg=well, bd=0, highlightthickness=0)
    entry_holder.place(x=sx + 10, y=sy + 6, width=sw - 20, height=sh - 12)
    ai_reply_extra.append(entry_holder)
    search_entry=tk.Entry(entry_holder,textvariable=search_var,font=('Segoe UI',10),bg=well,fg=notes_muted,insertbackground=notes_accent,relief='flat',bd=0,highlightthickness=0,selectbackground=notes_match_bg,selectforeground='white')
    search_entry.pack(fill='both', expand=True)
    placeholder_text = 'Search notes...'
    placeholder_visible = {'value': True}
    search_entry.insert(0, placeholder_text)
    # --- notes text in baked well
    _draw_model_name_entry((560, 210, 294, 32))
    tx, ty, tw, th_ = 46, 274, 808, 220
    text_holder = tk.Frame(root, bg=well, bd=0, highlightthickness=0)
    text_holder.place(x=tx + 8, y=ty + 8, width=tw - 16, height=th_ - 16)
    ai_reply_extra.append(text_holder)
    scrollbar = _GlassScrollbar(text_holder, well, notes_accent); scrollbar.pack(side='right', fill='y')
    notes_text=tk.Text(text_holder,wrap='word',undo=True,font=TEXT_FONT,bg=well,fg=txt_col,insertbackground=notes_accent,selectbackground=('#79356f' if palette=='neon' else '#165d85'),selectforeground='white',relief='flat',bd=0,highlightthickness=0,padx=10,pady=8,yscrollcommand=scrollbar.set)
    notes_text.pack(side='left',fill='both',expand=True); scrollbar._cmd = notes_text.yview
    notes_text.tag_configure('match',background=notes_match_bg,foreground='white'); notes_text.tag_configure('current_match',background=notes_current_bg,foreground='white')
    matches=[]; current=-1
    def refresh_matches(*_):
        nonlocal matches,current
        q=search_var.get(); notes_text.tag_remove('match','1.0','end'); notes_text.tag_remove('current_match','1.0','end'); matches=[]; current=-1
        if not q or (placeholder_visible['value'] and q == placeholder_text):
            match_label.config(text='0 matches',fg=notes_muted)
            return
        start='1.0'
        while True:
            pos=notes_text.search(q,start,stopindex='end',nocase=True)
            if not pos: break
            end=f'{pos}+{len(q)}c'; matches.append((pos,end)); notes_text.tag_add('match',pos,end); start=end
        if matches:
            current=0; notes_text.tag_remove('match',*matches[0]); notes_text.tag_add('current_match',*matches[0]); notes_text.see(matches[0][0]); match_label.config(text=f'1 / {len(matches)} matches',fg=NEON_YELLOW)
        else: match_label.config(text='0 matches',fg='#ff8bcf')
    def move_match(direction):
        nonlocal current
        if not matches: refresh_matches(); return
        if current>=0: notes_text.tag_remove('current_match',*matches[current]); notes_text.tag_add('match',*matches[current])
        current=(current+direction)%len(matches); notes_text.tag_remove('match',*matches[current]); notes_text.tag_add('current_match',*matches[current]); notes_text.see(matches[current][0]); match_label.config(text=f'{current+1} / {len(matches)} matches',fg=NEON_YELLOW)
    def clear_search():
        if placeholder_visible['value']:
            search_entry.focus_set()
            return
        search_var.set('')
        search_entry.focus_set()
    # --- glass image buttons (same renderer/hover glow as every other button)
    def place_btn(key, rect, command, label, tag=None):
        x, y, w, h = rect
        tag = tag or f'notes_{key}'
        _nx_place(tag, _ai_summary_style() if key == 'summary' else f'nx_btn_{t}_{key}', x, y, w, h, label, notes_accent, margin=8,
                  hover=not (key == 'summary' and not _ai_is_ready()))
        ai_click_map[tag] = command
        return tag
    place_btn('up', (454,166,36,36), lambda:move_match(-1), 'UP')
    place_btn('down', (496,166,36,36), lambda:move_match(1), 'DOWN')
    place_btn('clear', (540,166,66,36), clear_search, 'CLEAR')
    place_btn('summary', (732,166,122,36), lambda:_ai_gate() and _ai_summarize_advanced_notes(notes_text,palette), 'AI SUMMARY')
    class _SortShim:
        """Keeps sort_btn.config(text=...) working while the button is canvas art."""
        def __init__(self): self.command = lambda: None; self.mode = 'sort'
        def config(self, **kw):
            if 'command' in kw: self.command = kw['command']
            if 'text' in kw:
                self.mode = 'restore' if 'RESTORE' in kw['text'].upper() else 'sort'
                tag = 'notes_sort'
                style = f'nx_btn_{t}_{self.mode}'
                main_card_style_by_tag[tag] = style
                item, art = main_card_image_items.get(tag), ui_art.get(style)
                if item and art:
                    try: canvas.itemconfigure(item, image=art)
                    except Exception: pass
    sort_btn = _SortShim()
    place_btn('sort', (614,166,110,36), lambda: sort_btn.command(), 'SORT BY DATE')
    # Date sorting implementation.
    date_re=re.compile(r'^\s*(?:(?:OT|NOTE|NOTES|ON|OFF)\s+)?(?:(?P<y>20\d{2})[-/.](?P<m>\d{1,2})[-/.](?P<d>\d{1,2})|(?P<d2>\d{1,2})[-/.](?P<m2>\d{1,2})(?:[-/.](?P<y2>\d{2,4}))?)\b',re.I)
    def parse_note_date(line):
        m=date_re.match(line)
        if not m:return None
        try:
            if m.group('y'): y,mo,d=int(m.group('y')),int(m.group('m')),int(m.group('d'))
            else:
                d,mo=int(m.group('d2')),int(m.group('m2')); yr=m.group('y2'); y=int(yr)+2000 if yr and len(yr)==2 else (int(yr) if yr else 2000)
            return datetime(y,mo,d)
        except (TypeError,ValueError): return None
    original={'text':None,'sorted':False}
    def sort_notes():
        if original['sorted']:
            notes_text.delete('1.0','end'); notes_text.insert('1.0',original['text'] or ''); original['sorted']=False; sort_btn.config(text='SORT BY DATE'); refresh_matches(); sort_status.config(text='DATED NOTES (not sorted)   •   UNDATED NOTES (not sorted)   • normal order restored',fg=NEON_CYAN); return
        raw=notes_text.get('1.0','end-1c')
        if not raw.strip(): messagebox.showinfo('Sort by date','There are no notes to sort.'); return
        parts=re.split(r'(\n[ \t]*\n)',raw); paragraphs=[]; current=''
        for part in parts:
            if re.fullmatch(r'\n[ \t]*\n',part or ''):
                if current: paragraphs.append(current); current=''
            else: current+=part
        if current: paragraphs.append(current)
        blocks=[]
        if len(paragraphs)>1:
            for para in paragraphs:
                first=next((ln for ln in para.splitlines() if ln.strip()),''); blocks.append((parse_note_date(first),para))
        else:
            lines=raw.splitlines(keepends=True); starts=[]
            for i,line in enumerate(lines):
                dt=parse_note_date(line)
                if dt is not None: starts.append((i,dt))
            if starts:
                prefix=''.join(lines[:starts[0][0]])
                if prefix.strip(): blocks.append((None,prefix.rstrip('\n')))
                for i,(st,dt) in enumerate(starts):
                    en=starts[i+1][0] if i+1<len(starts) else len(lines); blocks.append((dt,''.join(lines[st:en]).rstrip('\n')))
        dated=[b for b in blocks if b[0] is not None]; undated=[b for b in blocks if b[0] is None and b[1].strip()]
        if not dated:
            messagebox.showinfo('Sort by date',"I couldn't sort these notes by date because I couldn't find any recognizable dates.\n\nThe notes were not changed."); sort_status.config(text='DATED NOTES (0)   •   UNDATED NOTES (1)   • no dates found',fg='#ff8bcf'); return
        original['text']=raw; original['sorted']=True; dated.sort(key=lambda x:x[0],reverse=True); ordered=dated+undated; out='\n\n'.join(x[1] for x in ordered); out += '\n' if raw.endswith('\n') and out else ''
        notes_text.delete('1.0','end'); notes_text.insert('1.0',out); refresh_matches(); sort_btn.config(text='↩ RESTORE NOTES'); sort_status.config(text=f'DATED NOTES ({len(dated)})   •   UNDATED NOTES ({len(undated)})   • newest first',fg=NEON_YELLOW)
    sort_btn.config(command=sort_notes)
    search_var.trace_add('write',refresh_matches)
    def _search_focus_in(_event=None):
        if placeholder_visible['value']:
            placeholder_visible['value'] = False
            search_var.set('')
            search_entry.config(fg=txt_col)
    def _search_focus_out(_event=None):
        if not search_var.get().strip():
            placeholder_visible['value'] = True
            search_var.set(placeholder_text)
            search_entry.config(fg=notes_muted)
    def _focus_search(_event=None):
        search_entry.focus_set()
        if placeholder_visible['value']:
            _search_focus_in()
        search_entry.select_range(0,'end')
        return 'break'
    search_entry.bind('<FocusIn>',_search_focus_in)
    search_entry.bind('<FocusOut>',_search_focus_out)
    notes_text.bind('<Control-f>',_focus_search)
    search_entry.bind('<Control-f>',_focus_search); search_entry.bind('<Return>',lambda e:(move_match(1),'break')); search_entry.bind('<Shift-Return>',lambda e:(move_match(-1),'break'))
    # Matching navigation button remains inside the same window.
    draw_back_button(535)

notes_state={'frame':None}

# Anti 3-second block toggle is shared by the send engine.
anti_block_enabled = bool(app_settings['anti_block_enabled'])
notify_sound = bool(app_settings.get('notify_sound', True))
animated_bg = bool(app_settings.get('animated_bg', True))
poke_badges_enabled = bool(app_settings.get('poke_badges', True))
shortcut_overlay_on = bool(app_settings.get('shortcut_overlay', True))
AW_DEFAULT_MSG = "hey {name} 😘 thank you so much for subscribing, i'm so happy you're here... how's your day going?"
autowelcome_on = bool(app_settings.get('autowelcome', False))
autowelcome_msg = str(app_settings.get('autowelcome_msg') or AW_DEFAULT_MSG)
quit_key = str(app_settings.get('quit_key') or 'Delete')          # key that closes PokeFlow completely (Help page)
quit_ctrl = bool(app_settings.get('quit_ctrl', False))
_QUIT_VK = {'Delete': 0x2E, 'End': 0x23, 'Home': 0x24, 'Insert': 0x2D, 'Pause': 0x13, 'Scroll_Lock': 0x91,
            'Prior': 0x21, 'Next': 0x22, **{f'F{i}': 0x6F + i for i in range(1, 13)},
            **{c: ord(c) for c in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'}}
_QUIT_NAMES = {'Prior': 'Page Up', 'Next': 'Page Down', 'Scroll_Lock': 'Scroll Lock'}


def _quit_label():
    name = _QUIT_NAMES.get(quit_key, quit_key)
    return ('Ctrl + ' + name) if quit_ctrl else name
menu_volume = int(app_settings.get('menu_volume', 100))

def update_anti_toggle():
    # Redraw main page so the toggle reflects current state.
    if page=='main': draw_main()

def set_mode(mode):
    global active_mode
    active_mode=mode
    update_poke_status()

def update_poke_status():
    # Refresh only the small status footer; mode selection is also reflected by colors.
    if page!='poke': return
    # remove old mode footer by simply redrawing poke page; this is lightweight.
    draw_poke()

# Page navigation

def _apply_theme_mode(target_theme, preserve_save_profile_ids=None):
    global theme_mode, video_background_enabled, video_cap, video_job, save_profile_ids
    # Theme redraws must never reset the user's saved history preference.
    if preserve_save_profile_ids is not None:
        save_profile_ids = bool(preserve_save_profile_ids)
        try:
            _save_app_settings()
        except Exception:
            pass
    theme_mode = target_theme
    _remember_setting('theme_mode', target_theme)
    # Keep the native Windows caption styled to match the selected theme.
    _schedule_native_titlebar_theme(target_theme)
    # NEON starts the bundled rainy ping-pong clip; NORMAL uses its original still.
    _set_theme_background(target_theme)
    draw_settings()
    try: root.after(400, lambda: _art_preload(target_theme))
    except Exception: pass


def switch_theme_with_fade():
    '''Switch themes under a complete, reversible fade overlay.'''
    global theme_transition_busy, theme_mode, video_background_enabled
    if theme_transition_busy:
        return

    target = 'NEON' if theme_mode == 'NORMAL' else 'NORMAL'
    preserve_history_preference = bool(save_profile_ids)
    if Image is None or ImageTk is None:
        _apply_theme_mode(target, preserve_history_preference)
        return

    # Include both endpoints. The prior fade skipped its brightest frame and
    # faded back only to alpha 35 before deleting the overlay, causing a visible
    # flash/pop. Keep symmetric steps so the animation is smooth in both directions.
    alphas = [0, 32, 64, 96, 128, 160, 192, 224, 255]
    theme_transition_busy = True
    try:
        overlay_id = canvas.create_image(0, 0, image=_theme_fade_photo(0), anchor='nw')
        canvas.tag_raise(overlay_id)
    except Exception:
        theme_transition_busy = False
        _apply_theme_mode(target, preserve_history_preference)
        return

    def finish_transition():
        global theme_transition_busy
        try:
            canvas.delete(overlay_id)
        except Exception:
            pass
        theme_transition_busy = False

    def fade_in(index):
        if index >= 0:
            try:
                canvas.itemconfig(overlay_id, image=_theme_fade_photo(alphas[index]))
                canvas.tag_raise(overlay_id)
            except Exception:
                finish_transition()
                return
            try:
                root.after(24, lambda: fade_in(index - 1))
            except Exception:
                finish_transition()
            return
        finish_transition()

    def fade_out(index=0):
        if index < len(alphas):
            try:
                canvas.itemconfig(overlay_id, image=_theme_fade_photo(alphas[index]))
                canvas.tag_raise(overlay_id)
            except Exception:
                # Do not leave the theme toggle permanently locked if Tk rejects
                # an animation frame; still apply the selected theme and clean up.
                try:
                    _apply_theme_mode(target, preserve_history_preference)
                finally:
                    finish_transition()
                return
            try:
                root.after(24, lambda: fade_out(index + 1))
            except Exception:
                try:
                    _apply_theme_mode(target, preserve_history_preference)
                finally:
                    finish_transition()
            return

        # The overlay is now fully opaque. Commit the new theme and redraw its
        # settings controls while covered, then reveal it back to alpha zero.
        try:
            _apply_theme_mode(target, preserve_history_preference)
        except Exception:
            # Retain a correct theme state and keep the button usable even if a
            # transient redraw fails. The fallback makes the next toggle reversible.
            theme_mode = target
            _remember_setting('theme_mode', target)
            try:
                _set_theme_background(target)
                draw_settings()
            except Exception:
                pass
        try:
            canvas.tag_raise(overlay_id)
        except Exception:
            pass
        fade_in(len(alphas) - 1)

    try:
        root.after(1, fade_out)
    except Exception:
        try:
            _apply_theme_mode(target, preserve_history_preference)
        finally:
            finish_transition()


def _hit_card(event, tag):
    bounds = main_card_bounds.get(tag)
    return bool(bounds and bounds[0] <= event.x <= bounds[2] and bounds[1] <= event.y <= bounds[3])


def go_main():
    if notes_state.get('frame') is not None:
        notes_state['frame'].destroy(); notes_state['frame']=None
    draw_main()

def go_poke(): draw_poke()
def go_help(): draw_help()

def on_click(event):
    global video_background_enabled, theme_mode, history_sort_newest, history_page_index, help_edit_action, history_acct_filter
    if theme_transition_busy:
        return
    if page!='main' and _hit_card(event, 'back_main'):
        _play_menu_click()
    if page=='main':
        if any(_hit_card(event, _t) for _t in ('main_poke','main_notes','main_anti','main_settings','main_report_bug','main_additional','main_help')):
            _play_menu_click()
        if _hit_card(event, 'main_poke'):
            history_page_index = 0
            draw_history()
        elif _hit_card(event, 'main_notes'):
            draw_notes()
        elif _hit_card(event, 'main_anti'):
            if _ai_gate():
                draw_ai_reply()
        elif _hit_card(event, 'main_settings'):
            draw_settings()
        elif _hit_card(event, 'main_report_bug'):
            draw_report_bug()
        elif _hit_card(event, 'main_additional'):
            draw_additional_features()
        elif _hit_card(event, 'main_help'):
            go_help()
    elif page=='poke':
        if _hit_card(event, 'mode_online'):
            set_mode('ONLINE')
        elif _hit_card(event, 'mode_offline'):
            set_mode('OFFLINE')
        elif _hit_card(event, 'back_main'):
            go_main()
    elif page=='history':
        if _hit_card(event, 'history_delete_all'):
            delete_all_history()
        elif _hit_card(event, 'history_sort'):
            history_sort_newest = not history_sort_newest
            _remember_setting('history_sort_newest', bool(history_sort_newest))
            history_page_index = 0
            draw_history()
        elif any(_hit_card(event, f'history_acct_{i}') for i in range(5)):
            i = next(i for i in range(5) if _hit_card(event, f'history_acct_{i}'))
            history_acct_filter = ([''] + _history_accounts())[i] if i <= len(_history_accounts()) else ''
            history_page_index = 0
            draw_history()
        elif _hit_card(event, 'history_prev'):
            history_page_index = max(0, history_page_index-1)
            draw_history()
        elif _hit_card(event, 'history_next'):
            total_pages = max(1, (len(_history_records()) + HISTORY_PAGE_SIZE - 1) // HISTORY_PAGE_SIZE)
            history_page_index = min(total_pages-1, history_page_index+1)
            draw_history()
        elif _hit_card(event, 'back_main'):
            go_main()
        else:
            copy_tag = next((tag for tag in main_card_bounds
                             if tag.startswith('history_copy_profile_') and _hit_card(event, tag)), None)
            if copy_tag:
                copy_history_profile_id(copy_tag[len('history_copy_profile_'):])
                return
            timer_tag = next((tag for tag in main_card_bounds
                              if tag.startswith('history_timer_profile_') and _hit_card(event, tag)), None)
            if timer_tag:
                _tpid = timer_tag[len('history_timer_profile_'):]
                if _tpid in repoke_timers or _tpid in pending_repoke_profiles:
                    reset_repoke_timer_for_profile(_tpid)
                else:
                    start_repoke_timer_for_profile(_tpid)
                return
            delete_tag = next((tag for tag in main_card_bounds
                               if tag.startswith('history_delete_profile_') and _hit_card(event, tag)), None)
            if delete_tag:
                delete_history_profile(delete_tag[len('history_delete_profile_'):])
    elif page=='bug':
        _bug_click(event)
    elif page=='additional':
        if _hit_card(event, 'back_main'):
            go_main()
        elif _hit_card(event, 'add_aw'):
            toggle_autowelcome_setting()
        elif _hit_card(event, 'add_poke'):
            toggle_poke_badges_setting()
        elif _hit_card(event, 'add_anti'):
            toggle_anti_block_setting()
    elif page=='ai_reply':
        if _hit_card(event, 'back_main'):
            go_main()
        else:
            for _tag, _fn in list(ai_click_map.items()):
                if _hit_card(event, _tag):
                    _fn()
                    break
    elif page=='help':
        _clicked = next((a for a in ('poke','send','timer','draft','quit') if _hit_card(event, f'help_shortcut_{a}')), None)
        if _hit_card(event, 'back_main'):
            help_edit_action = None
            go_main()
        elif _clicked:
            help_edit_action = None if help_edit_action == _clicked else _clicked
            draw_help()
            if help_edit_action:
                try: canvas.focus_set()
                except Exception: pass
        elif help_edit_action:
            help_edit_action = None
            draw_help()
    elif page=='notes':
        if _hit_card(event, 'back_main'):
            go_main()
        else:
            for _tag, _fn in list(ai_click_map.items()):
                if _hit_card(event, _tag):
                    _fn()
                    break
    elif page=='settings':
        if _hit_card(event, 'settings_theme'):
            switch_theme_with_fade()
        elif _hit_card(event, 'settings_sound'):
            toggle_notify_sound_setting()
        elif _hit_card(event, 'settings_bg'):
            toggle_animated_bg_setting()
        elif _hit_card(event, 'settings_keys'):
            toggle_shortcut_overlay_setting()
        elif _hit_card(event, 'settings_vol'):
            settings_vol_press(event)
        elif _hit_card(event, 'settings_step_minus'):
            _settings_step_start(-1)
        elif _hit_card(event, 'settings_step_plus'):
            _settings_step_start(1)
        elif _hit_card(event, 'back_main'):
            go_main()
canvas.bind('<Button-1>',on_click)
def _on_canvas_release(event=None):
    _settings_step_stop(event)
    settings_vol_release(event)
canvas.bind('<ButtonRelease-1>',_on_canvas_release)
canvas.bind('<B1-Motion>',settings_vol_move)
canvas.bind('<Key>',_help_on_key)
canvas.bind('<Motion>',_nx_on_motion)
canvas.bind('<Leave>',_nx_on_leave)

# Ctrl+configurable letter = prepare poke, send, or save ID + start repoke timer.
# Ctrl+Q prepares; Ctrl+E sends; Ctrl+T saves the visible ID and starts a timer only.
user32=ctypes.windll.user32
VK_CONTROL=0x11
q_was_down=False; e_was_down=False; t_was_down=False; last_trigger=0; last_send_trigger=0; last_timer_trigger=0
prepared_message=''; prepared_profile_id=''; prepared_mode=''; send_in_progress=False; send_cancel_requested=False

def _ctrl_q_combo_down():
    try:
        return bool((user32.GetAsyncKeyState(VK_CONTROL)&0x8000) and (user32.GetAsyncKeyState(ord(shortcut_poke.upper()))&0x8000))
    except Exception:
        return False

def _watch_poke_cancel():
    # Watch from a lightweight daemon thread so a quick Ctrl+Q tap is not missed
    # while PyAutoGUI is in a short mouse movement call.
    global poke_cancel_requested
    while poke_in_progress and poke_cancel_armed and not poke_cancel_requested:
        if _ctrl_q_combo_down():
            poke_cancel_requested = True
            return
        time.sleep(.004)

def _check_poke_cancel():
    global poke_cancel_requested
    if poke_in_progress and poke_cancel_armed and (poke_cancel_requested or _ctrl_q_combo_down()):
        poke_cancel_requested = True
        raise PokeCancelled()

def _poke_sleep(seconds):
    # Short cancellable waits used during fan-name selection and message preparation.
    deadline=time.monotonic()+max(0.0,seconds)
    while time.monotonic()<deadline:
        _check_poke_cancel()
        time.sleep(min(.01,max(0.0,deadline-time.monotonic())))

def _composer_visual_signal(win, mode):
    """Return visible composer-text strength, 0 for empty/unpopulated, None if unreadable.

    This is passive screenshot analysis only: no pointer movement, clicking, or
    clipboard access. Sampling the actual text row avoids picking up message bubbles
    or emoji controls. Window capture is DPI-normalized to match automation coordinates.
    """
    image = None
    crop = None
    try:
        import numpy as np
        image = _capture_window_image(win)
        width, height = image.size
        if mode == 'OFFLINE':
            # The offline chat column is narrower and starts farther left.
            x1, x2 = int(width * .325), int(width * .590)
        else:
            # Exclude the attachment/action buttons on the far right; measure the
            # text area only so a static icon cannot keep the send loop alive.
            x1, x2 = int(width * .410), int(width * .620)
        # Focus on the actual message-entry row, including the muted
        # 'Type a message...' placeholder. Keep the emoji toolbar below the crop.
        # This row is the authoritative visual state for Ctrl+E completion.
        y1, y2 = int(height * .82), int(height * .89)
        x1 = max(0, min(width - 1, x1)); x2 = max(x1 + 1, min(width, x2))
        y1 = max(0, min(height - 1, y1)); y2 = max(y1 + 1, min(height, y2))
        crop = image.crop((x1, y1, x2, y2)).convert('RGB')
        a = np.asarray(crop, dtype=np.int16)
        # Only NEUTRAL WHITE pixels count = typed message text. The grey 'Type a message...' placeholder is too dark,
        # emojis are coloured, and the white scroll bar / focus border are long solid rows that are skipped.
        # (The old brightness count saw ~4000-5000 on an EMPTY composer, so Ctrl+E never saw the text disappear.)
        mn, mx = a.min(axis=2), a.max(axis=2)
        white = (mn >= 190) & ((mx - mn) <= 25)
        line_rows = white.mean(axis=1) >= .4
        signal = int(white[~line_rows].sum())
        return signal if signal >= 250 else 0
    except Exception:
        return None
    finally:
        for item in (crop, image):
            if item is not None:
                try: item.close()
                except Exception: pass

_composer_placeholder_template_gray = None


def _composer_placeholder_visible(win, mode):
    """Detect the empty composer by matching its visible 'Type a message' text.

    Pixel-template matching only (no OCR). Searches the mode-appropriate composer
    area because FansMetric places the input at different horizontal positions in
    ONLINE and OFFLINE layouts. The runtime screenshot remains in memory only.

    Returns True when the placeholder is confidently present, False when it is not
    present, and None if visual matching could not be performed.
    """
    global _composer_placeholder_template_gray
    image = None
    converted = None
    try:
        if cv2 is None:
            return None
        import numpy as np
        template_path = Path(__file__).parent / 'ui_assets' / 'composer_placeholder_type_message.png'
        if _composer_placeholder_template_gray is None:
            if not template_path.is_file():
                return None
            _composer_placeholder_template_gray = cv2.imread(str(template_path), cv2.IMREAD_GRAYSCALE)
        template = _composer_placeholder_template_gray
        if template is None or template.size == 0:
            return None

        image = _capture_window_image(win)
        converted = image.convert('RGB')
        gray = cv2.cvtColor(np.asarray(converted), cv2.COLOR_RGB2GRAY)
        height, width = gray.shape
        # The input begins at different horizontal positions in the two FansMetric
        # layouts, so scan only the composer-row band across both known start positions.
        # Matching the literal placeholder makes this wider horizontal search safe;
        # unrelated message text is not treated as an empty composer.
        x1, x2 = int(width * .28), int(width * .73)
        # This is the user's marked input row, not the emoji toolbar or warning dialog.
        y1, y2 = int(height * .79), int(height * .91)
        x1 = max(0, min(width - 1, x1)); x2 = max(x1 + 1, min(width, x2))
        y1 = max(0, min(height - 1, y1)); y2 = max(y1 + 1, min(height, y2))
        roi = gray[y1:y2, x1:x2]
        best_score = -1.0
        # The template comes from FansMetric's real placeholder. Try scales that
        # cover common Windows DPI/window-size variations after window normalization.
        for scale in (.65, .72, .79, .85, .92, 1.00, 1.08, 1.16):
            tw = max(8, int(round(template.shape[1] * scale)))
            th = max(8, int(round(template.shape[0] * scale)))
            if tw >= roi.shape[1] or th >= roi.shape[0]:
                continue
            interpolation = cv2.INTER_AREA if scale < 1.0 else cv2.INTER_CUBIC
            resized = cv2.resize(template, (tw, th), interpolation=interpolation)
            result = cv2.matchTemplate(roi, resized, cv2.TM_CCOEFF_NORMED)
            _, score, _, _ = cv2.minMaxLoc(result)
            if score > best_score:
                best_score = float(score)
        # Provided empty-composer samples score around .81-.86; populated message
        # samples score below .65. Leave a margin to avoid treating normal text as empty.
        return best_score >= .74
    except Exception:
        return None
    finally:
        for item in (converted, image):
            if item is not None:
                try: item.close()
                except Exception: pass


def _composer_placeholder_stably_visible(win, mode, checks=8, interval=.12):
    """Require the empty placeholder to persist while no rate-limit warning appears.

    The warning can disappear and reappear between attempts, so its absence alone is
    never success. A candidate placeholder is sampled repeatedly for about 0.84 s;
    any warning or lost placeholder invalidates the candidate.
    """
    for index in range(max(2, int(checks))):
        if _three_second_warning_visible(win):
            return 'warning'
        placeholder = _composer_placeholder_visible(win, mode)
        if placeholder is not True:
            return 'changed'
        if index < checks - 1:
            time.sleep(interval)
    # One final warning check closes the race between the final screenshot and return.
    if _three_second_warning_visible(win):
        return 'warning'
    return 'stable'


def _composer_cleared_from_signal(before, after):
    """Return True/False/None for cleared/still populated/unreadable composer."""
    if before is None or after is None:
        return None
    if before <= 0:
        return False
    if after <= 0:
        return True
    # Positive signal means text is still visible in the composer; don't stop just
    # because a partial screenshot or partial text string dropped below a ratio.
    return False


_rate_limit_warning_template_gray = None

def _three_second_warning_visible(win):
    """Detect FansMetric's 'Please allow 3 seconds' alert by pixels, not OCR.

    This is a small reference crop of the warning dialog only. Runtime screenshots
    remain in memory and are closed immediately; the function does not call OCR.
    The alert must be absent before an empty composer can count as a successful send.
    """
    global _rate_limit_warning_template_gray
    image = None
    converted = None
    try:
        if cv2 is None:
            return False
        import numpy as np
        template_path = Path(__file__).parent / 'ui_assets' / 'three_second_warning_template.png'
        if _rate_limit_warning_template_gray is None:
            if not template_path.is_file():
                return False
            _rate_limit_warning_template_gray = cv2.imread(str(template_path), cv2.IMREAD_GRAYSCALE)
        template = _rate_limit_warning_template_gray
        if template is None or template.size == 0:
            return False

        image = _capture_window_image(win)
        converted = image.convert('RGB')
        rgb = np.asarray(converted, dtype=np.uint8)
        frame = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        # Downsample the search image once; test a few common DPI/window-scale ratios.
        search = cv2.resize(frame, (max(1, frame.shape[1] // 2), max(1, frame.shape[0] // 2)),
                            interpolation=cv2.INTER_AREA)
        base_h, base_w = template.shape[:2]
        for scale in (.70, .80, .90, 1.00, 1.10, 1.20, 1.30):
            tw = max(8, int(round(base_w * scale * .5)))
            th = max(8, int(round(base_h * scale * .5)))
            if tw >= search.shape[1] or th >= search.shape[0]:
                continue
            resized_template = cv2.resize(template, (tw, th), interpolation=cv2.INTER_AREA)
            result = cv2.matchTemplate(search, resized_template, cv2.TM_CCOEFF_NORMED)
            _, score, _, _ = cv2.minMaxLoc(result)
            if score >= .74:
                return True
        return False
    except Exception:
        # The send loop still falls back to composer checks if template matching fails.
        return False
    finally:
        for item in (converted, image):
            if item is not None:
                try: item.close()
                except Exception: pass

def _composer_cleared_verified(win, mode, before, after):
    """Only confirm send when the actual empty-composer placeholder is stable."""
    cleared = _composer_cleared_from_signal(before, after)
    if cleared is not True:
        return cleared
    return _composer_placeholder_stably_visible(win, mode) == 'stable'


def _empty_composer_confirmed_after_block(win, mode):
    """Confirm a successful send from a stable placeholder, not warning flicker."""
    return _composer_placeholder_stably_visible(win, mode) == 'stable'


def _mark_prepared_message_as_sent():
    global prepared_message, prepared_profile_id, prepared_mode
    if prepared_message and prepared_profile_id:
        try:
            record_successful_send(prepared_profile_id)
        except Exception:
            pass
    prepared_message = ''
    prepared_profile_id = ''
    prepared_mode = ''


def send_current_message():
    global send_in_progress
    already = send_in_progress
    try:
        _send_current_message_impl()
    except Exception as exc:
        # An unexpected error must never leave Ctrl+E 'busy' (it would then only ever say STOPPING).
        if not already:
            send_in_progress = False
        try: set_status('SEND ERROR  \u2022  ' + str(exc)[:80], '#ff8bcf')
        except Exception: pass


def _uia_call(fn, timeout=1.5):
    """Runs fn(reader) in a short thread with its own UI Automation setup (it can not run on the window thread). None = failed."""
    res = {'v': None}
    def work():
        try:
            import uiautomation as auto
            import uia_reader as _ur
            with auto.UIAutomationInitializerInThread():
                res['v'] = fn(_ur.UiaReader())
        except Exception as exc:
            res['err'] = exc
    t = threading.Thread(target=work, daemon=True, name='PokeFlow-UIA')
    t.start()
    t.join(timeout)
    if res.get('err') is not None:
        _pb_log(f'Reader call failed: {res["err"]!r}'[:160])
    return res['v']


def _uia_composer_state(win, full=False):
    """{'text': what is in the chat message box ('' = empty), 'three': the '3 seconds' warning texts on the page}.
    Quick path = the focused message box only; full=True also reads the whole page (for the warning)."""
    hwnd = int(getattr(win, '_hWnd', 0))
    def fn(rd):
        out = {'text': None, 'three': []}
        if not full:
            text, _r = rd.focused_composer_text()
            if text is not None:
                out['text'] = text
                return out
        data = rd.read_chat(hwnd)
        out['three'] = list((data.get('alerts') or {}).get('three_list') or [])
        c = _sw_pick_chat(data) or ((data.get('chats') or [None])[0])
        el = c.get('composer_el') if c else None
        if el is not None:
            v = el.GetCurrentPropertyValue(30045)
            v = (v if isinstance(v, str) else '').strip()
            out['text'] = '' if v.lower().startswith('type a message') else v
        return out
    return _uia_call(fn)


def _send_via_reader(win, dc):
    """Ctrl+E without screenshots: Esc+Enter, then READ the message box. Empty twice in a row (and no new '3 seconds' warning)
    = sent; text still there = blocked, press again. Returns True when done, False = use the old picture checks instead."""
    global send_in_progress, send_cancel_requested
    if not dc or dc.get('composer') is None:
        return False
    if not (dc.get('composer_text') or '').strip():
        st = _uia_composer_state(win, full=True)
        if st is None or st['text'] is None:
            return False
        if not st['text']:
            send_in_progress = False
            set_status('Composer is empty  •  nothing to send', '#ffb86b')
            return True
        dc['composer_text'] = st['text']
    _norm = lambda t: ' '.join(str(t or '').split())
    orig = _norm(dc.get('composer_text'))           # the message Ctrl+E is sending - Enter is only ever pressed on THIS text
    seen_empty = False
    baseline = set((dc.get('alerts') or {}).get('three_list') or [])
    _pb_log(f'Ctrl+E (reader): start, {len(dc.get("composer_text") or "")} chars, anti-block={anti_block_enabled}')
    if anti_block_enabled:
        set_status('SENDING  •  Anti 3-sec Block ON', NEON_YELLOW)
        while (user32.GetAsyncKeyState(VK_CONTROL)&0x8000) or (user32.GetAsyncKeyState(ord(str(shortcut_send).upper()[:1] or "E"))&0x8000):
            time.sleep(.02)
        _pb_hide_now(10.0)
        _pb_wait_idle()
    deadline = time.monotonic() + (60.0 if anti_block_enabled else 3.0)
    attempts, empty, fails, cancel_was_down, warned = 0, 0, 0, False, False
    while time.monotonic() < deadline:
        ctrl_now = bool(user32.GetAsyncKeyState(VK_CONTROL)&0x8000)
        e_now = bool(user32.GetAsyncKeyState(ord(str(shortcut_send).upper()[:1] or "E"))&0x8000)
        cancel_pressed = anti_block_enabled and ctrl_now and e_now and not cancel_was_down
        cancel_was_down = ctrl_now and e_now
        if cancel_pressed or send_cancel_requested:
            send_cancel_requested = False
            send_in_progress = False
            set_status('SEND STOPPED  •  user cancelled', '#ff8bcf')
            return True
        if empty == 0 and not fails:
            if attempts and not anti_block_enabled:
                break                                          # Auto-Retry OFF: one press only
            attempts += 1
            _safe_esc()
            time.sleep(.04)
            _sent_enter()
            time.sleep(.2)
        else:
            time.sleep(.15)                                    # text gone / read failed: no more keys, only (re)read
        st = _uia_composer_state(win, full=bool(empty))
        if st is None or st['text'] is None:
            fails += 1
            if fails >= 3:
                _pb_log('Ctrl+E (reader): message box not readable 3x -> picture checks')
                return False if attempts <= 1 else _send_reader_unsure(attempts)
            continue
        fails = 0
        if set(st['three']) - baseline:
            warned = True
            empty = 0
            if attempts % 5 == 0:
                set_status(f'SENDING  •  3-second warning active; retrying ({attempts})...', NEON_YELLOW)
            continue
        if st['text'] != '' and _norm(st['text']) != orig:
            # Different text in the box = you already started typing the NEXT message. Never press Enter on it.
            send_in_progress = False
            if seen_empty:
                _mark_prepared_message_as_sent()
                _pb_log(f'Ctrl+E (reader): box now holds new typing ({len(st["text"])} chars) -> first message counted as sent, stopped')
                set_status('MESSAGE SENT  •  stopped, you are typing the next one', '#9ff7ff')
            else:
                _pb_log('Ctrl+E (reader): the text in the box was changed -> stopped, nothing more pressed')
                set_status('SEND STOPPED  •  you changed the text in the box', '#ffb86b')
            return True
        if st['text'] == '':
            seen_empty = True
            empty += 1
            if empty >= 2:
                _mark_prepared_message_as_sent()
                send_in_progress = False
                _pb_log(f'Ctrl+E (reader): sent after {attempts} attempt(s), warning seen={warned}')
                set_status(f'MESSAGE SENT  •  {attempts} attempt' + ('s' if attempts != 1 else ''), '#9ff7ff')
                return True
        else:
            empty = 0
            if attempts <= 3 or attempts % 10 == 0:
                _pb_log(f'Ctrl+E (reader) attempt {attempts}: still {len(st["text"])} chars in the box')
            if attempts % 5 == 0:
                set_status(f'SENDING  •  retrying ({attempts})...', NEON_YELLOW)
    send_in_progress = False
    if not anti_block_enabled:
        set_status('NOT SENT  •  text still in the box (3-second block?) - turn Auto-Retry ON', '#ffb86b')
    else:
        set_status('SEND TIMEOUT  •  message not confirmed sent', '#ff8bcf')
    return True


def _send_reader_unsure(attempts):
    global send_in_progress
    send_in_progress = False
    set_status(f'SEND STOPPED  •  could not read the box after {attempts} tries, check the chat', '#ffb86b')
    return True


_last_msg_sent = [0.0]          # when PokeFlow last sent a message (Ctrl+E / Autowelcome) - OnlyFans' 3-second rule


def _sent_enter():
    pyautogui.press('enter')
    _last_msg_sent[0] = time.monotonic()


def _safe_esc(wait=0.6):
    """Esc - but NEVER while Ctrl (or a Windows key) is held: Ctrl+Esc opens the Windows Start menu. Waits a moment for
    you to let go of Ctrl (after Ctrl+E); if it is still held, the Esc is skipped. Returns True when Esc was pressed."""
    def held():
        try:
            return any(user32.GetAsyncKeyState(vk) & 0x8000 for vk in (VK_CONTROL, 0x5B, 0x5C))   # Ctrl, Left/Right Win
        except Exception:
            return False
    end = time.monotonic() + wait
    while held() and time.monotonic() < end:
        time.sleep(0.02)
    if held():
        try: _pb_log('Esc skipped: Ctrl / Win key still held (Ctrl+Esc would open the Start menu)')
        except Exception: pass
        return False
    pyautogui.press('esc')
    return True


def _send_current_message_impl():
    global prepared_message, prepared_profile_id, prepared_mode, active_mode, send_in_progress, send_cancel_requested
    if send_in_progress:
        send_cancel_requested=True
        set_status('SEND STOPPED  •  user cancelled','#ff8bcf')
        return
    send_in_progress=True
    send_cancel_requested=False
    win=find_fansmetric_window()
    if not win:
        send_in_progress=False
        set_status('FansMetric window not found','#ff8bcf')
        return
    _dc = None
    try:                                                   # never send him the same message twice by accident
        _dc, _ = _ctrlq_uia(win)
        _txt = (_dc or {}).get('composer_text') or ''
        if _txt and _sent_before(_txt, _dc.get('messages')):
            _ov_txt, _ov_t = _dw['override']
            if not (_ov_txt == _txt and time.monotonic() - _ov_t < 15.0):
                _dw['override'] = (_txt, time.monotonic())
                send_in_progress = False
                _pb_log(f'Ctrl+E: same message already sent to {_dc.get("name")!r} - stopped, press again to send anyway')
                try: _nm = clean_first_name(_dc.get('name') or '')
                except Exception: _nm = ''
                _pop_info(f"Already sent to {_nm or 'him'}", 'This exact message is already in his chat. Press Ctrl+E again within 15 s to send it anyway.', 9.0)
                set_status('NOT SENT  •  SAME MESSAGE ALREADY IN HIS CHAT', '#ffd166')
                return
            _dw['override'] = (None, 0.0)
    except Exception:
        pass

    try:
        if _send_via_reader(win, _dc):                     # reads the message box itself - no screenshots
            return
    except Exception as exc:
        _pb_log(f'Ctrl+E (reader) error: {exc!r} -> picture checks'[:160])
    if not send_in_progress:
        return

    # Ctrl+E deliberately does NOT invoke OCR or profile-header detection.
    # Ctrl+Q stores the detected FansMetric layout in prepared_mode; use that exact
    # layout for send verification. If Ctrl+E is used without a prepared poke,
    # fall back to the user's selected mode (the app defaults to ONLINE).
    mode = prepared_mode if prepared_mode in ('ONLINE', 'OFFLINE') else active_mode
    if mode not in ('ONLINE', 'OFFLINE'):
        mode = 'ONLINE'
    if active_mode != mode:
        active_mode = mode
        try: _ui(update_poke_status)
        except Exception: pass

    # Visual checks are passive only. A prepared message is enough reason to issue
    # the requested Esc/Enter sequence even if a single screenshot read fails; but
    # an unreadable/empty image is not treated as proof that the message was sent.
    initial_signal = _composer_visual_signal(win, mode)
    if prepared_message and not initial_signal:
        for _ in range(5):                                    # the very first screenshot sometimes misses the text
            time.sleep(.08)
            again = _composer_visual_signal(win, mode)
            if again:
                initial_signal = again
                break
    initial_placeholder = _composer_placeholder_visible(win, mode)
    if initial_placeholder is True:
        send_in_progress = False
        set_status('Composer is empty  •  nothing to send', '#ffb86b')
        return
    if initial_signal is None and not prepared_message:
        send_in_progress=False
        set_status('Could not read the composer area; no prepared message to send','#ffb86b')
        return
    if initial_signal == 0 and not prepared_message:
        send_in_progress=False
        set_status('Composer appears empty; nothing to send','#ffb86b')
        return
    composer_text_seen = initial_signal is not None and initial_signal > 0
    last_populated_signal = initial_signal if composer_text_seen else None

    if not anti_block_enabled:
        # Non-retry mode deliberately performs exactly one Esc/Enter attempt.
        _safe_esc()
        time.sleep(.04)
        _sent_enter()
        time.sleep(.22)
        after_signal = _composer_visual_signal(win, mode)
        if _three_second_warning_visible(win):
            send_in_progress = False
            set_status('3-SECOND BLOCK ACTIVE  •  turn Auto-Retry ON to keep trying', '#ffb86b')
            return
        placeholder_state = _composer_placeholder_visible(win, mode)
        if placeholder_state is True and _composer_placeholder_stably_visible(win, mode) == 'stable':
            _mark_prepared_message_as_sent()
            send_in_progress = False
            set_status('MESSAGE SENT  •  1 attempt', '#9ff7ff')
            return
        if after_signal is not None and after_signal > 0:
            composer_text_seen = True
            last_populated_signal = after_signal
            cleared = False
        elif after_signal == 0 and composer_text_seen:
            cleared = _composer_cleared_verified(win, mode, last_populated_signal, after_signal)
        else:
            # If screenshot analysis never saw the text, zero-after-zero cannot prove
            # success; leave the prepared state available for another Ctrl+E attempt.
            cleared = None
        if cleared is True:
            _mark_prepared_message_as_sent()
            set_status('MESSAGE SENT  •  1 attempt','#9ff7ff')
        elif cleared is None:
            set_status('SEND ATTEMPTED  •  could not verify visually','#ffb86b')
        else:
            set_status('SEND ATTEMPTED  •  composer still contains text','#ffb86b')
        send_in_progress=False
        return

    set_status('SENDING  •  Anti 3-sec Block ON',NEON_YELLOW)
    deadline=time.monotonic()+60.0
    attempts=0
    # Ignore the initiating Ctrl+E press so it isn't immediately interpreted as cancel.
    while (user32.GetAsyncKeyState(VK_CONTROL)&0x8000) or (user32.GetAsyncKeyState(ord(str(shortcut_send).upper()[:1] or "E"))&0x8000):
        time.sleep(.02)
    cancel_was_down=False
    unreadable_checks=0
    unseen_empty_checks=0
    rate_limit_seen=False
    gone_checks=0
    _pb_hide_now(10.0)
    _pb_wait_idle()
    _pb_log(f'Ctrl+E start: anti-block ON, composer signal={initial_signal}, placeholder={initial_placeholder}')
    while time.monotonic()<deadline:
        ctrl_now=bool(user32.GetAsyncKeyState(VK_CONTROL)&0x8000)
        e_now=bool(user32.GetAsyncKeyState(ord(str(shortcut_send).upper()[:1] or "E"))&0x8000)
        cancel_pressed=ctrl_now and e_now and not cancel_was_down
        cancel_was_down=ctrl_now and e_now
        if cancel_pressed or send_cancel_requested:
            send_cancel_requested=False
            send_in_progress=False
            set_status('SEND STOPPED  •  user cancelled','#ff8bcf')
            return
        attempts += 1
        # Deliberately only these two key events: no mouse movement/clicking, no
        # Ctrl+A/C, and no clipboard interactions inside Ctrl+E.
        if gone_checks > 0 and composer_text_seen:
            time.sleep(.12)                                   # text just vanished: stop pressing keys, only confirm
        else:
            _safe_esc()
            time.sleep(.04)
            _sent_enter()
            time.sleep(.18)
        # Check the rate-limit warning BEFORE deciding from the composer pixels.
        # Some layouts (notably OFFLINE) can produce an empty-looking input row while
        # FansMetric is still rejecting the send. A visible warning always means retry.
        warning_active = _three_second_warning_visible(win)
        if warning_active:
            rate_limit_seen = True
            unseen_empty_checks = 0
            if attempts % 5 == 0:
                set_status(f'SENDING  •  3-second warning active; retrying ({attempts})...', NEON_YELLOW)
            continue

        # The composer placeholder is the primary success signal. Unlike the rate-
        # limit dialog, it is not expected to blink on every rejected attempt.
        # Do not send more keys while confirming a candidate empty state.
        placeholder_state = _composer_placeholder_visible(win, mode)
        if placeholder_state is True:
            confirmation = _composer_placeholder_stably_visible(win, mode)
            if confirmation == 'stable' and (composer_text_seen or prepared_message):
                _mark_prepared_message_as_sent()
                send_in_progress = False
                set_status(f'MESSAGE SENT  •  {attempts} attempts', '#9ff7ff')
                return
            if confirmation == 'warning':
                rate_limit_seen = True
                unseen_empty_checks = 0
                # The warning reappeared during confirmation; retry on next cycle.
                continue
            # Placeholder disappeared or was inconsistent. Do not call this a send;
            # return to the retry loop rather than trusting a single empty-looking frame.
            unseen_empty_checks = 0
            if attempts % 5 == 0:
                set_status(f'SENDING  •  verifying composer placeholder ({attempts})...', NEON_YELLOW)
            time.sleep(.08)
            continue

        after_signal = _composer_visual_signal(win, mode)
        if after_signal is None:
            unreadable_checks += 1
            if attempts % 5 == 0:
                set_status(f'SENDING  •  composer unreadable; retrying ({attempts})...',NEON_YELLOW)
            # Don't stop after one bad screenshot. Keep retrying; the hard deadline
            # and the second Ctrl+E cancellation remain the safety exits.
            continue
        unreadable_checks=0
        if attempts <= 3 or attempts % 10 == 0:
            _pb_log(f'Ctrl+E attempt {attempts}: composer signal={after_signal}, warning={rate_limit_seen}')
        if after_signal > 0 and composer_text_seen and last_populated_signal and after_signal < .55 * last_populated_signal:
            after_signal = 0                                  # most of the text is gone: treat as empty (leftover = emoji etc.)
        if after_signal == 0 and not composer_text_seen and attempts >= 25 and not rate_limit_seen:
            send_in_progress = False
            _pb_log('Ctrl+E: never saw text and no 3-second warning after 25 tries -> stopped')
            set_status('SEND STOPPED  •  could not confirm, check the chat', '#ffb86b')
            return
        if after_signal > 0 and composer_text_seen and gone_checks >= 1:
            # The text vanished (no 3-second box) and now there is text again = you started typing the next message.
            # Count the first one as sent and stop - pressing Enter now would send your new typing.
            _pb_log('Ctrl+E: text gone then new text appeared -> counted as sent, stopped (user typing)')
            _mark_prepared_message_as_sent()
            send_in_progress = False
            set_status(f'MESSAGE SENT  •  stopped, you are typing the next one', '#9ff7ff')
            return
        if after_signal > 0:
            composer_text_seen = True
            last_populated_signal = after_signal
            unseen_empty_checks = 0
            gone_checks = 0
            cleared = False
        elif _three_second_warning_visible(win):
            # FansMetric can briefly show an empty-looking composer while the
            # rate-limit dialog is active. That is a rejected send, not success:
            # keep the ESC -> ENTER loop going until the dialog disappears.
            rate_limit_seen = True
            gone_checks = 0
            unseen_empty_checks = 0
            cleared = False
            if attempts % 5 == 0:
                set_status(f'SENDING  •  3-second warning active; retrying ({attempts})...', NEON_YELLOW)
        elif composer_text_seen:
            unseen_empty_checks = 0
            cleared = _composer_cleared_verified(win, mode, last_populated_signal, after_signal)
            if cleared is not True:
                # Backup for when the 'Type a message...' picture does not match on this screen/size: the text has been gone
                # from the composer for several checks in a row and no 'Please allow 3 seconds' box is up -> it was sent.
                gone_checks += 1
                if gone_checks >= 3:
                    _pb_log(f'Ctrl+E: composer empty for {gone_checks} checks, no warning -> counted as sent')
                    cleared = True
        elif rate_limit_seen:
            # OCR is not involved here. Once the rate-limit popup has been observed,
            # a series of empty composer reads after that popup disappears is treated
            # as a possible accepted send, but only after multiple stable confirmations.
            unseen_empty_checks += 1
            if unseen_empty_checks >= 3:
                if _empty_composer_confirmed_after_block(win, mode):
                    _mark_prepared_message_as_sent()
                    send_in_progress = False
                    set_status(f'MESSAGE SENT  •  {attempts} attempts', '#9ff7ff')
                    return
                unseen_empty_checks = 0
            cleared = False
        else:
            # If the composer detector missed its text from the start, keep trying
            # through transient empty frames. Only pause after eight empty reads when
            # no visible rate-limit popup has been found, avoiding blind indefinite sends.
            unseen_empty_checks += 1
            if unseen_empty_checks >= 8:
                if _three_second_warning_visible(win):
                    rate_limit_seen = True
                    unseen_empty_checks = 0
                    cleared = False
                else:
                    send_in_progress=False
                    set_status('SEND PAUSED  •  composer text not visible and no warning detected','#ffb86b')
                    return
            else:
                cleared = False
        if cleared is None:
            unreadable_checks += 1
            if attempts % 5 == 0:
                set_status(f'SENDING  •  verification unavailable; retrying ({attempts})...',NEON_YELLOW)
            continue
        if cleared is True:
            _mark_prepared_message_as_sent()
            send_in_progress=False
            set_status(f'MESSAGE SENT  •  {attempts} attempts','#9ff7ff')
            return
        if attempts % 5 == 0:
            set_status(f'SENDING  •  retrying ({attempts})...',NEON_YELLOW)
    send_in_progress=False
    set_status('SEND TIMEOUT  •  message not confirmed sent','#ff8bcf')

# ----- Ctrl+G: AI draft from the fan's newest message(s) on screen -----
import chat_reader as _chat_reader

POP_DRAFT_W, POP_DRAFT_H = 520, 360
POP_DRAFT_WELL = (34, 178, 452, 108)
POP_DRAFT_BTN = {'dr_copy': (34, 300, 130, 38), 'dr_regen': (174, 300, 150, 38), 'dr_close': (334, 300, 110, 38)}
POP_QP_W, POP_QP_H = 520, 500
POP_QP_ROW = (34, 104, 40, 452, 34)               # x, y0, step, w, h
draft_popup = {'item': None, 'cv': None, 'text': None, 'status': None, 'token': 0, 'busy': False, 'message': '', 'followup': False, 'name': ''}


def _pop_info(title, sub, life=7.0, kind='info', acct=None, hwnd=None):
    """Small notice (same glass toast) for things like 'no new message from him'."""
    if threading.current_thread() is not threading.main_thread():
        return _ui(_pop_info, title, sub, life, kind, acct, hwnd)
    return _pop_show_toast(kind, title, sub, [] if kind in ('bundle', 'spend', 'welcome') else [('pop_ok', lambda it: _pop_close_toast(it))],
                           life=life, acct=acct, hwnd=hwnd)


def _pop_corner_window(w, h, art_key, extra_gap=0):
    """Keyed, non-activating window that starts off-screen on the right and slides into the bottom-right corner."""
    th = _pop_theme()
    left, top, right, bottom = _pop_work_area()
    win = _pop_track(_pop_window(w, h, right + 60, top))
    cv = tk.Canvas(win, width=w, height=h, bd=0, highlightthickness=0, bg=POP_KEY)
    cv.pack(fill='both', expand=True)
    art = ui_art.get(f"{art_key}_{th['t']}")
    if art is not None:
        cv.create_image(0, 0, image=art, anchor='nw')
    x = right - w - 4
    y = bottom - 12 - (h - 14) - extra_gap
    item = {'win': win, 'cv': cv, 'w': w, 'h': h, 'x': x, 'y': y, 'cx': right + 30, 'cy': y, 'closed': False}
    try: win.geometry(f"{w}x{h}+{item['cx']}+{y}")
    except Exception: pass
    _pop_move(item, x, y, frames=20, ease=_pop_ease_pop)
    return item


def _pop_slide_out(item):
    if item is None or item.get('closed'):
        return
    item['closed'] = True
    left, top, right, bottom = _pop_work_area()
    _pop_move(item, right + 30, item.get('cy', item['y']), frames=10, ease=lambda t: t * t, done=lambda: _pop_destroy(item))


# ---- AI draft pop-up --------------------------------------------------------
def _draft_close():
    item = draft_popup['item']
    draft_popup.update(item=None, cv=None, text=None, status=None, busy=False)
    draft_popup['token'] += 1
    _pop_slide_out(item)
    _pop_layout_toasts()


def _draft_set_status(text, color=None):
    cv, st = draft_popup.get('cv'), draft_popup.get('status')
    if cv is None or st is None:
        return
    try: cv.itemconfigure(st, text=text, fill=color or _pop_theme()['muted'])
    except Exception: pass


def _draft_put(text):
    box = draft_popup.get('text')
    if box is None:
        return
    try:
        box.config(state='normal'); box.delete('1.0', 'end'); box.insert('1.0', text); box.config(state='disabled')
    except Exception:
        pass


def _draft_current_text():
    box = draft_popup.get('text')
    try: return box.get('1.0', 'end-1c').strip() if box is not None else ''
    except Exception: return ''


def _draft_generate(message):
    """Run the local model in a background thread and show the result in the pop-up."""
    draft_popup['token'] += 1
    token = draft_popup['token']
    draft_popup.update(busy=True, message=message)
    _draft_put('Generating locally… the first reply can take a little longer while the model loads.')
    _draft_set_status('WORKING…')
    label = app_settings.get('ai_model') or ''
    if label not in AI_MODEL_SPECS:
        label = AI_DEFAULT_MODEL_LABEL
    length = app_settings.get('ai_length') or 'Short'
    cpu_only = bool(app_settings.get('ai_cpu_only'))

    def work():
        draft, note, error = None, '', None
        try:
            if draft_popup.get('followup'):
                draft, note = _ai_generate_followup(message, model_label=label, cpu_only=cpu_only, fan_name=draft_popup.get('name') or '')
            else:
                draft, note = _ai_generate_reply(message, model_label=label, length=length, cpu_only=cpu_only, fan_name=draft_popup.get('name') or '',
                                                 mode=app_settings.get('ai_mode') or 'Auto', context=draft_popup.get('context') or '')
        except Exception as exc:
            error = str(exc) or type(exc).__name__

        def finish():
            if token != draft_popup['token'] or draft_popup['item'] is None:
                return
            draft_popup['busy'] = False
            if error:
                _draft_put(error); _draft_set_status('FAILED', _pop_theme()['bad'])
            else:
                _draft_put(draft or ''); _draft_set_status('READY • NOT SENT', _pop_theme()['good'])
        try: root.after(0, finish)
        except Exception: pass
    threading.Thread(target=work, daemon=True, name='PokeFlow-Draft').start()


def _draft_copy():
    text = _draft_current_text()
    if not text or draft_popup.get('busy'):
        return
    try:
        pyperclip.copy(text)
        if pyperclip.paste().strip() != text.strip():
            raise RuntimeError('clipboard check failed')
        _draft_set_status('COPIED • PRESS CTRL+V IN THE CHAT', _pop_theme()['good'])
    except Exception:
        _draft_set_status('COULD NOT COPY', _pop_theme()['bad'])


def _draft_regenerate():
    if draft_popup.get('busy') or not draft_popup.get('message'):
        return
    _draft_generate(draft_popup['message'])


def _draft_show(message, followup=False, name='', context=''):
    """Open (or reuse) the draft pop-up for `message` and start generating.
    followup=True: `message` is HER last message and the fan went quiet -> a short nudge is drafted instead."""
    if draft_popup['item'] is not None:
        old = draft_popup['item']
        draft_popup.update(item=None, cv=None, text=None, status=None)
        _pop_slide_out(old)
    th = _pop_theme()
    item = _pop_corner_window(POP_DRAFT_W, POP_DRAFT_H, 'nx_pop_draft')
    cv = item['cv']
    shown = ('He went quiet after your message: ' + message) if followup else message
    shown = ' '.join(shown.split())
    if len(shown) > 140:                                  # 2 lines max - it must never run into the DRAFT box below
        shown = shown[:139].rsplit(' ', 1)[0] + '…'
    cv.create_text(34, 128, text=shown, anchor='nw', width=452, justify='left', font=('Segoe UI', 9), fill=th['txt'])
    status = cv.create_text(486, 112, text='', anchor='e', font=('Segoe UI', 8, 'bold'), fill=th['muted'])
    wx, wy, ww, wh = POP_DRAFT_WELL
    holder = tk.Frame(item['win'], bg=th['well'], bd=0, highlightthickness=0)
    holder.place(x=wx + 8, y=wy + 8, width=ww - 16, height=wh - 16)
    box = tk.Text(holder, wrap='word', font=TEXT_FONT, bg=th['well'], fg=th['txt'], relief='flat', bd=0,
                  highlightthickness=0, padx=6, pady=4, insertbackground=th['accent'])
    box.pack(fill='both', expand=True)
    box.config(state='disabled')
    for bkey, fn in (('dr_copy', _draft_copy), ('dr_regen', _draft_regenerate), ('dr_close', _draft_close)):
        bx, by, bw, bh = POP_DRAFT_BTN[bkey]
        _pop_add_button(cv, bkey, bx, by, bw, bh, fn)
    draft_popup.update(item=item, cv=cv, text=box, status=status, message=message, followup=bool(followup), name=name or '', context=context or '')
    _pop_layout_toasts()
    _draft_generate(message)
    return item


def _capture_fan_messages():
    """Screenshot FansMetric, OCR it in memory and return chat_reader's verdict (nothing is saved)."""
    win = find_fansmetric_window()
    if not win:
        raise RuntimeError('FansMetric window not found.')
    if getattr(win, 'isMinimized', False):
        raise RuntimeError('FansMetric is minimized. Open it and try again.')
    image = _capture_window_image(win, normalize=False)
    try:
        rows = _run_screen_ocr(image)
        size = image.size
    finally:
        try: image.close()
        except Exception: pass
    clean = []
    for box, text, conf in rows:
        pts = _ocr_box_points(box)
        if pts:
            clean.append((pts, text, conf))
    return _chat_reader.read_fan_messages(clean, size)


draft_scan_busy = False


def _draft_from_reader():
    """Ctrl+G via the reader: his newest message(s) + YOUR message before them (so the AI knows where the chat is).
    Returns (result like chat_reader's, his first name, your previous message) or (None, '', '') when not available."""
    win = find_fansmetric_window()
    if win is None:
        return None, '', ''
    chat, why = _ctrlq_uia(win)
    msgs = (chat or {}).get('messages') or []
    if not msgs:
        _pb_log(f"Ctrl+G reader: no messages ({why or 'empty chat'}) - using OCR")
        return None, '', ''
    try:
        fan_name = clean_first_name(chat['name'])
        if fan_name.casefold() in _GENERIC_FAN_NAMES:
            fan_name = ''
    except Exception:
        fan_name = ''
    last_me = max((i for i, m in enumerate(msgs) if m['side'] == 'me'), default=-1)
    his = [m['text'] for m in msgs[last_me + 1:] if m['side'] == 'fan']
    _pb_log(f"Ctrl+G reader: {len(msgs)} messages, his new: {len(his)}")
    if not his:
        my_last = msgs[last_me]['text'] if last_me >= 0 else ''
        return ({'ok': False, 'reason': 'His last message is already answered.', 'messages': [], 'text': '', 'my_last': my_last},
                fan_name, '')
    mine_before = [m['text'] for m in msgs[:last_me + 1] if m['side'] == 'me'][-2:]
    return ({'ok': True, 'reason': '', 'messages': his[-4:], 'text': '\n'.join(his[-4:])}, fan_name, '\n'.join(mine_before))


def start_draft_from_screen():
    """Ctrl+G: read his newest message(s), then draft a reply in a pop-up."""
    global draft_scan_busy
    if draft_scan_busy:
        return
    if not _ai_gate():
        return
    draft_scan_busy = True
    set_status('READING HIS LAST MESSAGE…', '#ff82df' if theme_mode == 'NEON' else '#49bde6')

    def work():
        global draft_scan_busy
        result, error, fan_name, context = None, None, '', ''
        try:
            result, fan_name, context = _draft_from_reader()          # reader first: the real chat text, both sides
            if result is None:
                result = _capture_fan_messages()                       # fallback: screenshot + OCR as before
        except Exception as exc:
            error = str(exc) or type(exc).__name__

        def finish():
            global draft_scan_busy
            draft_scan_busy = False
            if error:
                set_status('COULD NOT READ THE CHAT', '#ff8bcf')
                _pop_info('Could not read the chat', error[:80])
            elif not result['ok'] and result.get('my_last'):
                set_status('HE WENT QUIET • DRAFTING A FOLLOW-UP…', '#ff82df' if theme_mode == 'NEON' else '#49bde6')
                _draft_show(result['my_last'], followup=True, name=fan_name)
            elif not result['ok']:
                set_status('NO NEW MESSAGE FROM HIM', '#ffd166')
                _pop_info('Nothing to reply to', result['reason'][:90])
            else:
                set_status('DRAFTING A REPLY…', '#ff82df' if theme_mode == 'NEON' else '#49bde6')
                _draft_show(result['text'], name=fan_name, context=context)
        try: root.after(0, finish)
        except Exception: pass
    threading.Thread(target=work, daemon=True, name='PokeFlow-ReadChat').start()


# ----- Ctrl+B: fix the words FansMetric flags as "Banned: ..." in the message box -----
BANNED_PATH = POKE_HISTORY_PATH.parent / 'banned_words.json'
BANNED_DEFAULTS = {
    '_help': 'Left = the banned word or phrase (lowercase). Right = what to write instead. Leave the right side empty ("") to just remove it. Words that are not listed here are removed. Longer phrases win ("a little" before "little").',
    'replace': {'a little': 'a bit', 'little': 'tiny'},
}
banned_busy = False
b_was_down = [False]
last_banned_trigger = [0.0]


def _load_banned_map():
    try:
        if not BANNED_PATH.exists():
            BANNED_PATH.parent.mkdir(parents=True, exist_ok=True)
            BANNED_PATH.write_text(json.dumps(BANNED_DEFAULTS, indent=2, ensure_ascii=False), encoding='utf-8')
        data = json.loads(BANNED_PATH.read_text(encoding='utf-8'))
        rep = data.get('replace', {}) if isinstance(data, dict) else {}
        return {str(k).strip().lower(): str(v) for k, v in rep.items() if str(k).strip()}
    except Exception:
        return dict(BANNED_DEFAULTS['replace'])


def _banned_from_banner_text(text):
    """'Banned: "little"' / 'Banned: "a", "b"'  ->  ['little'] / ['a', 'b']"""
    m = re.search(r'banned\s*[:;.]?\s*(.*)', text or '', re.I)
    if not m:
        return []
    rest = m.group(1)
    quoted = re.findall(r'["“”„\'‘’]([^"“”„\'‘’]{1,40})["“”„\'‘’]', rest)
    items = quoted if quoted else re.split(r'[,;]', rest)
    out = []
    for it in items:
        w = re.sub(r'^[\s"“”„\'‘’]+|[\s"“”„\'‘’.]+$', '', it).lower()
        if w and w not in out:
            out.append(w)
    return out


def _read_banned_banner(win):
    """OCR the FansMetric window and return the banned words named in the red 'Banned: ...' banner ([] = none seen)."""
    image = _capture_window_image(win, normalize=False)
    try:
        rows = _run_screen_ocr(image)
    finally:
        try: image.close()
        except Exception: pass
    words = []
    for _box, text, _conf in rows:
        if re.search(r'banned', str(text), re.I):
            for w in _banned_from_banner_text(str(text)):
                if w not in words:
                    words.append(w)
    return words


def _fix_banned_text(text, banned, mapping):
    """Returns (new_text, [(old, new)]). Banned words from the banner + every listed word that is in the text are replaced
    (or removed when there is no replacement)."""
    changes = []
    wanted = set(w.lower() for w in banned)
    for key in mapping:
        if re.search(r'(?<!\w)' + re.escape(key) + r'(?!\w)', text, re.I):
            wanted.add(key)
    def case_like(src, rep):
        if not rep:
            return rep
        if len(src) > 1 and src.isupper():
            return rep.upper()
        if src[:1].isupper():
            return rep[:1].upper() + rep[1:]
        return rep
    for word in sorted(wanted, key=len, reverse=True):
        rep = mapping.get(word, '')
        pat = re.compile(r'(?<!\w)' + re.escape(word) + r'(?!\w)', re.I)
        if not pat.search(text):
            if word not in banned or word in mapping:
                continue
            pat = re.compile(re.escape(word), re.I)               # flagged inside a longer word: still fix it
            if not pat.search(text):
                continue
        text = pat.sub(lambda m: case_like(m.group(0), rep), text)
        changes.append((word, rep))
    text = re.sub(r'[ \t]{2,}', ' ', text)
    text = re.sub(r'[ \t]+([,.!?…;:])', r'\1', text)
    text = re.sub(r'[ \t]+\n', '\n', text)
    return text.strip(), changes


def fix_banned_words():
    global banned_busy
    if banned_busy or send_in_progress or poke_in_progress:
        return
    banned_busy = True
    prior = None
    try:
        win = find_fansmetric_window()
        if not win:
            raise RuntimeError('FansMetric window not found.')
        if getattr(win, 'isMinimized', False):
            raise RuntimeError('FansMetric is minimized.')
        _pb_hide_now(10.0)
        _pb_wait_idle()
        mapping = _load_banned_map()
        set_status('FIXING BANNED WORDS...', NEON_YELLOW)
        prior = pyperclip.paste()
        all_changes = []
        for round_no in range(3):
            chat, why = _ctrlq_uia(win, focus_composer=True)      # reader: the banner + the box text, no OCR, no clipboard copy
            if chat and chat.get('focused') and (chat.get('composer_text') or '').strip():
                banned = _banned_from_banner_text((chat.get('alerts') or {}).get('banned') or '')
                text = chat['composer_text']
                _pb_log(f'Ctrl+B (reader) round {round_no + 1}: banner={banned} text={len(text)} chars')
                new, changes = _fix_banned_text(text, banned, mapping)
                if not changes or new == text.strip():
                    break
                pyautogui.hotkey('ctrl', 'a')
                time.sleep(.05)
                pyperclip.copy(new)
                pyautogui.hotkey('ctrl', 'v')
                time.sleep(.45)
                all_changes.extend(changes)
                continue
            if chat and chat.get('focused') and not (chat.get('composer_text') or '').strip():
                raise RuntimeError('The message box is empty.')
            _pb_log(f'Ctrl+B: reader not usable ({why or "box not focused"}) -> OCR backup')
            banned = _read_banned_banner(win)
            sentinel = '__pokeflow_%d__' % int(time.time() * 1000)
            text = sentinel
            for attempt in range(2):
                pyperclip.copy(sentinel)
                pyautogui.hotkey('ctrl', 'a')
                time.sleep(.05)
                pyautogui.hotkey('ctrl', 'c')
                time.sleep(.14)
                text = pyperclip.paste()
                if text != sentinel:
                    break
                mode = active_mode if active_mode in ('ONLINE', 'OFFLINE') else 'ONLINE'
                x, y = point(win, OFFLINE_COMPOSER_CLICK if mode == 'OFFLINE' else ONLINE_COMPOSER_CLICK)
                pyautogui.click(x, y)                       # focus was not in the message box: click it and try once more
                time.sleep(.08)
            if text == sentinel or not text.strip():
                raise RuntimeError('The message box is empty or could not be read.')
            new, changes = _fix_banned_text(text, banned, mapping)
            if not changes or new == text.strip():
                break
            pyperclip.copy(new)
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(.45)                                 # let FansMetric re-check the text (the banner updates)
            all_changes.extend(changes)
        if all_changes:
            shown = ', '.join('%s → %s' % (a, b if b else '(removed)') for a, b in all_changes[:4])
            _pb_log('Ctrl+B fixed: ' + shown)
            set_status('BANNED WORDS FIXED  •  ' + shown, '#9ff7ff')
        else:
            set_status('NO BANNED WORD FOUND', '#ffb86b')
    except Exception as exc:
        _pb_log('Ctrl+B error: %r' % (exc,))
        set_status('BANNED FIX FAILED', '#ff8bcf')
        try: _pop_info('Banned words not fixed', str(exc)[:90])
        except Exception: pass
    finally:
        banned_busy = False
        if prior is not None:
            try: pyperclip.copy(prior)
            except Exception: pass


g_was_down=[False, False]
s_was_down=[False]
last_babe_trigger=[0.0]
last_draft_trigger=[0.0]

quit_was_down = [False]


def _run_hotkey(fn, *a, **k):
    """Ctrl+Q / Ctrl+S / Ctrl+E / Ctrl+T run in their own thread, so the PokeFlow window keeps drawing smoothly
    while they read FansMetric and paste / send (it used to freeze 0.5-2.8 s on every press)."""
    def go():
        with _hotkey_lock:                      # one action at a time, in the order pressed (as before)
            fn(*a, **k)
    threading.Thread(target=go, daemon=True, name='PokeFlow-Hotkey').start()


_hotkey_lock = threading.Lock()


def poll_global_hotkeys():
    global q_was_down,e_was_down,t_was_down,last_trigger,last_send_trigger,last_timer_trigger,send_cancel_requested,poke_cancel_requested
    ctrl=bool(user32.GetAsyncKeyState(VK_CONTROL)&0x8000)
    def down(letter):
        try: return bool(user32.GetAsyncKeyState(ord(letter.upper())) & 0x8000)
        except Exception: return False
    q=down(shortcut_poke); e=down(shortcut_send); t=down(shortcut_timer); g=down(shortcut_draft); sk=down('S')
    shift=bool(user32.GetAsyncKeyState(0x10)&0x8000)
    if POKEFLOW_LITE:
        e = t = g = False                                  # Lite: only Ctrl+Q and Ctrl+S
    if ctrl and (q or e or t or g or (sk and not shift)):
        _pb_hide_now(1.5)                                # the action itself keeps badges quiet while it runs
    if ctrl and q and not q_was_down:
        now=time.monotonic()
        if now-last_trigger>.5:
            last_trigger=now
            if poke_in_progress:
                poke_cancel_requested=True; set_status('POKE CANCELLING...','#ff8bcf')
            else:
                _run_hotkey(personalize, active_mode)
    if ctrl and sk and not shift and not s_was_down[0]:           # Ctrl+S: copy the ID and paste the message with "babe" (no name)
        now=time.monotonic()
        if now-last_babe_trigger[0]>.5:
            last_babe_trigger[0]=now
            if poke_in_progress:
                poke_cancel_requested=True; set_status('POKE CANCELLING...','#ff8bcf')
            else:
                _run_hotkey(personalize, active_mode, keep_babe=True)
    s_was_down[0]=sk
    bk=down('B') and not POKEFLOW_LITE
    if ctrl and bk and not shift and not b_was_down[0]:           # Ctrl+B: replace / remove the words FansMetric flags as banned
        now=time.monotonic()
        if now-last_banned_trigger[0]>.8:
            last_banned_trigger[0]=now
            root.after(1,fix_banned_words)
    b_was_down[0]=bk
    if ctrl and e and not e_was_down:
        now=time.monotonic()
        if now-last_send_trigger>.8:
            last_send_trigger=now
            if send_in_progress: send_cancel_requested=True; set_status('SEND STOPPING...','#ff8bcf')
            else: _run_hotkey(send_current_message)
    if ctrl and t and not t_was_down:
        now=time.monotonic()
        if now-last_timer_trigger>.8:
            last_timer_trigger=now
            if poke_in_progress:
                poke_cancel_requested=True; set_status('POKE CANCELLING...','#ff8bcf')
            else:
                _run_hotkey(save_profile_id_and_start_repoke_timer)
    if ctrl and g and not shift and not g_was_down[0]:
        now=time.monotonic()
        if now-last_draft_trigger[0]>.8:
            last_draft_trigger[0]=now
            root.after(1,start_draft_from_screen)
    g_was_down[0]=g
    try:                                                       # close PokeFlow completely (default: Delete, changeable in Help)
        vk = _QUIT_VK.get(quit_key)
        qk = bool(vk and user32.GetAsyncKeyState(vk) & 0x8000) and not POKEFLOW_LITE
        typing_here = False
        try:                                                    # typing in PokeFlow's own boxes: Delete deletes text
            typing_here = isinstance(root.focus_get(), (tk.Text, tk.Entry))
        except Exception:
            pass
        if qk and not quit_was_down[0] and (ctrl == quit_ctrl) and not (page == 'help' and help_edit_action) and not typing_here:
            _pb_log('Quit key pressed (%s) - closing PokeFlow' % _quit_label())
            root.after(1, _exit_application)
        quit_was_down[0] = qk
    except Exception:
        pass
    q_was_down=q; e_was_down=e; t_was_down=t; root.after(20,poll_global_hotkeys)

# ---------------- System tray lifecycle ----------------
tray_icon = None

def _restore_from_tray():
    try:
        root.deiconify()
        root.state('normal')
        root.lift()
        root.focus_force()
    except Exception:
        pass

def _tray_open(icon, item):
    try: root.after(0, _restore_from_tray)
    except Exception: pass

def _tray_exit(icon, item):
    try: root.after(0, _exit_application)
    except Exception: pass

def _exit_application():
    global tray_icon, video_cap, video_job
    try:
        if video_job is not None: root.after_cancel(video_job)
    except Exception: pass
    try:
        if video_cap is not None: video_cap.release()
    except Exception: pass
    try:
        if tray_icon is not None:
            tray_icon.stop()
            tray_icon = None
    except Exception: pass
    try: root.destroy()
    except Exception: pass

def minimize_to_tray():
    # The window close button hides PokeFlow in the Windows notification area.
    global tray_icon
    if not TRAY_READY or TrayImage is None:
        # Safe fallback on systems without a tray backend: minimize to the taskbar.
        try: root.iconify()
        except Exception: pass
        set_status('MINIMIZED  •  PokeFlow is still running', NEON_YELLOW)
        return
    try:
        if tray_icon is None:
            ico_path = ui_asset_dir / 'pokeflow_app.png'
            if ico_path.exists():
                tray_image = TrayImage.open(ico_path).convert('RGBA')
            else:
                tray_image = TrayImage.new('RGBA',(64,64),(10,16,25,255))
            resampling = getattr(getattr(TrayImage, 'Resampling', TrayImage), 'LANCZOS')
            tray_image = tray_image.resize((64,64), resampling)
            tray_menu = pystray.Menu(
                pystray.MenuItem('Open PokeFlow', _tray_open, default=True),
                pystray.MenuItem('Exit PokeFlow', _tray_exit)
            )
            tray_icon = pystray.Icon('PokeFlow', tray_image, 'PokeFlow is running', tray_menu)
            tray_icon.run_detached()
        root.withdraw()
    except Exception:
        # If Windows prevents tray registration, don't kill the user's session.
        tray_icon = None
        try: root.iconify()
        except Exception: pass

# ---------------- Poke badges: "Poke 1/3" next to every fan on the FansMetric list ----------------
import poke_badges as _pbmod

_pb = {'view': None, 'quiet_until': 0.0, 'wins': {}, 'stop': False, 'thread': None}


def _pb_stage_for(pid):
    try:
        st = poke_state.get(_profile_state_key(pid))
        return int(st.get('stage', 0)) if st else 0
    except Exception:
        return 0


def _pb_hide_now(quiet_seconds=0.0):
    """Hide all badges at once (before a hotkey action takes screenshots, or when the setting is turned off)."""
    if quiet_seconds:
        _pb['quiet_until'] = max(_pb['quiet_until'], time.monotonic() + quiet_seconds)
    _ph['pid'] = None; _ph['rect'] = None
    try: root.after(0, _ph_hide, True)
    except Exception: pass
    for _t in list(_pa['toasts']):
        try: root.after(0, _pa_close, _t)
        except Exception: pass
    _pb['view'] = None
    for w in list(_pb['wins'].values()):
        w['shown'] = False
        w['a'] = 0.0
        try: _ui(w['win'].withdraw)
        except Exception: pass


def _pb_make_window():
    win = tk.Toplevel(root)
    try: win.overrideredirect(True)
    except Exception: pass
    try: win.attributes('-topmost', True)
    except Exception: pass
    cv = tk.Canvas(win, bd=0, highlightthickness=0, bg='#17181c')
    cv.pack(fill='both', expand=True)
    if os.name == 'nt':                               # never takes focus and lets clicks pass through to FansMetric
        try:
            win.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(win.winfo_id()) or win.winfo_id()
            style = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
            ctypes.windll.user32.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x00000080 | 0x00000020)
        except Exception:
            pass
    try: win.attributes('-alpha', 0.0)
    except Exception: pass
    win.withdraw()
    return {'win': win, 'cv': cv, 'key': None, 'shown': False, 'a': 0.0, 'x': 0.0, 'y': 0.0}


_pb_font_cache = {}


def _pb_font(px):
    from PIL import ImageFont
    f = _pb_font_cache.get(px)
    if f is None:
        for path in (Path(__file__).with_name('tools') / 'fonts' / 'Poppins-Bold.ttf', 'C:/Windows/Fonts/segoeuib.ttf', 'arial.ttf'):
            try:
                f = ImageFont.truetype(str(path), px); break
            except Exception:
                f = None
        if f is None:
            f = ImageFont.load_default()
        _pb_font_cache[px] = f
    return f


def _pb_render(text, accent, fill, fg, bw, bh, bg):
    """Smooth badge: drawn 4x larger with Pillow and scaled down (anti-aliased edges), on the card's own colour."""
    from PIL import Image, ImageDraw
    SS = 4
    W, H = bw * SS, bh * SS
    im = Image.new('RGB', (W, H), tuple(bg))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, W - 1, H - 1), H // 2, fill=accent)
    t = 2 * SS
    d.rounded_rectangle((t, t, W - 1 - t, H - 1 - t), (H - 2 * t) // 2, fill=fill)
    r = int(H * 0.15)
    cx = int(H * 0.5 + 2 * SS)
    d.ellipse((cx - r, H // 2 - r, cx + r, H // 2 + r), fill=accent)
    d.text((cx + r + 8 * SS, H // 2 + SS * 0.5), text, font=_pb_font(max(8, int(bh * 0.38 * SS))), fill=fg, anchor='lm')
    return im.resize((bw, bh), Image.LANCZOS)


def _pb_draw(w, text, accent, fill, fg, bw, bh):
    """Outline pill with a coloured dot: [ o  Poke 1/3 ] - a smooth, anti-aliased picture instead of canvas shapes."""
    bg = _pb.get('bg', (23, 24, 28))
    cv = w['cv']
    cv.delete('all')
    cv.configure(width=bw, height=bh)
    try:
        w['win'].configure(bg='#%02x%02x%02x' % tuple(bg))
        cv.configure(bg='#%02x%02x%02x' % tuple(bg))
    except Exception:
        pass
    img = _pb_render(text, _hex_rgb(accent), _hex_rgb(fill), _hex_rgb(fg), bw, bh, bg)
    try:
        w['photo'] = ImageTk.PhotoImage(img, master=cv)
        cv.create_image(0, 0, image=w['photo'], anchor='nw')
    except Exception:
        cv.create_text(bw / 2, bh / 2, text=text, fill=fg)


def _hex_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _pb_apply():
    """Main thread, ~16 fps: glide each badge to its place, fade in/out, show the stage live from the poke history."""
    try:
        view = _pb['view']
        now = time.monotonic()
        on = bool(poke_badges_enabled and view is not None and now >= _pb['quiet_until'] and not poke_in_progress
                  and now - view['t'] < 8.0)
        targets = {}
        if on:
            for c in view['cards']:
                bh = int(max(20, min(28, c['h'] * 1.6)))
                bw = int(bh * 3.7)
                # hidden when scrolled under the tab strip or past the bottom edge of the window
                if c['cy'] - bh / 2 < view['clip_top'] or c['cy'] + bh / 2 > view['height'] - 2:
                    continue
                if _pb_stage_for(c['id']) <= 0:
                    continue                           # never poked: no badge at all
                targets[c['id']] = (int(view['left'] + c['x']), int(view['top'] + c['cy'] - bh / 2), bw, bh)
        for pid, (x, y, bw, bh) in targets.items():
            w = _pb['wins'].get(pid)
            if w is None:
                if len(_pb['wins']) > 60:
                    continue
                w = _pb['wins'][pid] = _pb_make_window()
            stage = _pb_stage_for(pid)
            accent, fill, fg = _pbmod.badge_colors(stage, theme_mode)
            text = _pbmod.badge_text(stage)
            key = (text, accent, bw, bh, tuple(_pb.get('bg', (23, 24, 28))))
            if w['key'] != key:
                _pb_draw(w, text, accent, fill, fg, bw, bh)
                w['key'] = key
            if not w['shown']:
                w['x'], w['y'] = float(x), float(y)             # first appearance: no gliding in from elsewhere
            else:
                w['x'] += (x - w['x']) * 0.7
                w['y'] += (y - w['y']) * 0.7
            geo = f'{bw}x{bh}+{int(round(w["x"]))}+{int(round(w["y"]))}'
            if w.get('geo') != geo:
                w['geo'] = geo
                w['win'].geometry(geo)
            if w['a'] < 1.0 or w.get('alpha_set') != 1.0:
                w['a'] = min(1.0, w['a'] + 0.08)
                w['alpha_set'] = w['a']
                try: w['win'].attributes('-alpha', w['a'])
                except Exception: pass
            if not w['shown']:
                w['win'].deiconify()
                w['shown'] = True
        for pid, w in _pb['wins'].items():
            if pid in targets or not w['shown']:
                continue
            w['a'] = max(0.0, w['a'] - 0.10)
            try: w['win'].attributes('-alpha', w['a'])
            except Exception: pass
            if w['a'] <= 0:
                try: w['win'].withdraw()
                except Exception: pass
                w['shown'] = False
    except Exception:
        pass
    finally:
        try: root.after(16, _pb_apply)
        except Exception: pass


_PB_TPL_DIR = POKE_HISTORY_PATH.parent / 'badge_ids'
_pb_tpl = {'img': {}, 'loaded': False}


_PB_PANEL_FILE = POKE_HISTORY_PATH.parent / 'badge_panel.json'


def _pb_panel_load(st):
    try:
        d = json.loads(_PB_PANEL_FILE.read_text(encoding='utf-8'))
        r = d['panel'][1]
        st['panel'] = (float(d['panel'][0]), float('inf') if r is None else float(r), float(d['panel'][2]))
        st['panel_size'] = tuple(int(v) for v in d['size'])
    except Exception:
        pass


def _pb_panel_save(panel, size):
    try:
        r = None if panel[1] == float('inf') else panel[1]
        _PB_PANEL_FILE.write_text(json.dumps({'panel': [panel[0], r, panel[2]], 'size': list(size)}), encoding='utf-8')
    except Exception:
        pass


def _pb_tpl_load():
    """Remembered look of each poked fan's @id line (a tiny picture), so the badge can be found without reading the screen."""
    if _pb_tpl['loaded']:
        return
    _pb_tpl['loaded'] = True
    try:
        import numpy as np
        from PIL import Image as PILImage
        for f in list(_PB_TPL_DIR.glob('*.png'))[:600]:
            try:
                with PILImage.open(f) as im:
                    _pb_tpl['img'][f.stem] = np.asarray(im.convert('L'), dtype=np.uint8).copy()
            except Exception:
                pass
    except Exception:
        pass


def _pb_tpl_learn(img, cards):
    """After a full read: remember the @id line of every fan that already has poke 1-3."""
    try:
        import numpy as np
        gray = None
        for c in cards:
            box = c.get('box')
            if not box or _pb_stage_for(c['id']) <= 0:
                continue
            x0, y0, x1, y1 = int(box[0]) - 2, int(box[1]) - 2, int(box[2]) + 2, int(box[3]) + 2
            if x0 < 0 or y0 < 0 or x1 > img.size[0] or y1 > img.size[1] or x1 - x0 < 24 or y1 - y0 < 8:
                continue
            old = _pb_tpl['img'].get(c['id'])
            if old is not None and abs(old.shape[1] - (x1 - x0)) <= 2 and abs(old.shape[0] - (y1 - y0)) <= 2:
                continue
            if len(_pb_tpl['img']) >= 600 and old is None:
                continue
            if gray is None:
                gray = img.convert('L')
            tpl = gray.crop((x0, y0, x1, y1))
            _pb_tpl['img'][c['id']] = np.asarray(tpl, dtype=np.uint8).copy()
            try:
                _PB_TPL_DIR.mkdir(parents=True, exist_ok=True)
                tpl.save(_PB_TPL_DIR / (c['id'] + '.png'))
            except Exception:
                pass
    except Exception:
        pass


def _pb_tpl_scan(img, panel):
    """Find known, already-poked fans on screen by picture matching (a few milliseconds, no text reading)."""
    try:
        import numpy as np
        import cv2
    except Exception:
        return []
    known = [(pid, t) for pid, t in _pb_tpl['img'].items() if _pb_stage_for(pid) > 0]
    if not known or panel is None:
        return []
    W, H = img.size
    l, r, t = panel
    ox, oy = int(max(0, l)), int(max(0, t))
    x2 = int(min(W, r if r != float('inf') else W))
    if x2 - ox < 120 or H - oy < 120:
        return []
    area = np.asarray(img.convert('L').crop((ox, oy, x2, H)), dtype=np.uint8)
    out = []
    for pid, tpl in known:
        th, tw = tpl.shape
        if th >= area.shape[0] or tw >= area.shape[1]:
            continue
        res = cv2.matchTemplate(area, tpl, cv2.TM_CCOEFF_NORMED)
        _, mx, _, loc = cv2.minMaxLoc(res)
        if mx >= 0.93:
            out.append({'id': pid, 'x': ox + loc[0] + tw - 2 + 10, 'cy': oy + loc[1] + th / 2.0, 'h': max(8.0, th - 4.0), 'score': mx})
    out.sort(key=lambda d: d['cy'])
    return out


def _pb_hover_ok(win, pos):
    """True when FansMetric is the active window OR the mouse is right over FansMetric (nothing else on top there).
    So badges / LOADING also work while you are typing in another window (e.g. on your 2nd monitor) and only hover
    over FansMetric - no click needed first."""
    if _pb_foreground_is(win):
        return True
    if pos is None:
        return False
    try:
        u = ctypes.windll.user32
        class _PT(ctypes.Structure):
            _fields_ = [('x', ctypes.c_long), ('y', ctypes.c_long)]
        h = u.WindowFromPoint(_PT(int(pos[0]), int(pos[1])))
        if not h:
            return False
        top = u.GetAncestor(h, 2)                            # GA_ROOT: the top-level window under the mouse
        return int(top or h) == int(getattr(win, '_hWnd', -1))
    except Exception:
        return False


def _pb_foreground_is(win):
    try:
        fg = ctypes.windll.user32.GetForegroundWindow()
        return bool(fg) and int(fg) == int(getattr(win, '_hWnd', -1))
    except Exception:
        return True


def _pb_profile(img, band, rows=None):
    """Row-by-row brightness of the scrolling part of the list (one number per pixel row); used to follow scrolling.
    Only the cards' own columns and the rows below the tab strip are used, so fixed parts of the window
    (headers, the NOTIFICATIONS panel) cannot disturb the match."""
    import numpy as np
    w, h = img.size
    x0, x1 = max(0, int(band[0])), min(w, int(band[1]))
    if x1 - x0 < 20:
        x0, x1 = 0, w
    y0, y1 = (0, h) if not rows else (max(0, int(rows[0])), min(h, int(rows[1])))
    if y1 - y0 < 120:
        y0, y1 = 0, h
    col = img.convert('L').crop((x0, y0, x1, y1)).resize((1, y1 - y0))
    return np.asarray(col, dtype=np.float32).reshape(-1)


_PB_LOG = POKE_HISTORY_PATH.parent / 'badges_debug.txt'


def _pb_log(msg):
    """Tiny diagnostics file (timings and why tracking was lost) so slow or wrong badges can be explained."""
    try:
        if _PB_LOG.exists() and _PB_LOG.stat().st_size > 150000:
            _PB_LOG.write_text('', encoding='utf-8')
        with open(_PB_LOG, 'a', encoding='utf-8') as f:
            f.write(datetime.now().strftime('%H:%M:%S ') + str(msg) + '\n')
    except Exception:
        pass


def _pb_band_rows(found, panel, size, clip_top):
    """x-range of the card columns inside the FANS panel and the rows that really scroll."""
    W, H = size
    l, r, _t = panel if panel else (0, float('inf'), 0)
    left = int(max(0, l) + 4)
    right = int(min(W, r if r != float('inf') else W))
    if right - left < 200:
        left = int(max(0, min(c['x'] for c in found) - 330))
        right = int(min(W, max(c['x'] for c in found) + 420))
    top = int(max(0, min(clip_top or 0, H - 200)))
    return (left, right), (top, H)


def _pb_ocr_cards(img, panel=None):
    """Read the FANS panel. With a remembered panel box only that part of the window is read (much faster)."""
    ox = oy = 0
    src = img
    if panel is not None:
        l, r, t = panel
        W, H = img.size
        ox, oy = int(max(0, l)), int(max(0, t))
        x2 = int(min(W, r if r != float('inf') else W))
        if x2 - ox > 200 and H - oy > 200:
            src = img.crop((ox, oy, x2, H))
        else:
            ox = oy = 0
    rows = _pb_ocr_rows(src, ox, oy)
    found = _pbmod.analyze(rows)
    return found                                       # (cards, clip_top, panel) or None


def _pb_ocr_rows(src, ox=0, oy=0):
    rows = []
    for box, text, score in _run_screen_ocr(src):
        pts = _ocr_box_points(box)
        if not pts or score < 0.3:
            continue
        xs = [p[0] + ox for p in pts]; ys = [p[1] + oy for p in pts]
        rows.append((min(xs), min(ys), max(xs), max(ys), text))
    return rows


def _pb_read_list(img, st):
    """Read the FANS list. The first time only a thin strip with the 'FANS' / 'NOTIFICATIONS' headers is read to
    find the panel, then just that panel - much less to read than the whole window."""
    t0 = time.monotonic()
    panel = st.get('panel') if st.get('panel_size') == img.size else None
    how = 'panel'
    if panel is None:
        W, H = img.size
        try:
            panel = _pbmod.find_panel(_pb_ocr_rows(img.crop((0, 0, W, int(H * 0.32)))))
        except Exception:
            panel = None
        how = 'strip+panel'
    found = _pb_ocr_cards(img, panel)
    if not found and panel is not None:
        found = _pb_ocr_cards(img)
        how += '+full'
    _pb_log(f'read list ({how}): {int((time.monotonic() - t0) * 1000)} ms, cards={len(found[0]) if found else 0}, window={img.size}')
    return found


def _pb_grab(bbox):
    from PIL import ImageGrab
    return ImageGrab.grab(bbox=bbox, all_screens=True)


def _pb_fast_track(win, st, now):
    """Follow the scrolling by grabbing only the card columns (about 20 ms). Returns 'ok', 'lost' or None (not possible)."""
    org, size, rect = st.get('origin'), st.get('imgsize'), st.get('rect')
    if not org or not size or rect != (win.left, win.top, win.width, win.height) or not st.get('band'):
        return None
    try:
        import numpy as np
        band = st['band']
        x0, x1 = max(0, int(band[0])), min(size[0], int(band[1]))
        if x1 - x0 < 20:
            return None
        ry0, ry1 = st.get('rows') or (0, size[1])
        im = _pb_grab((org[0] + x0, org[1] + ry0, org[0] + x1, org[1] + ry1))
        if im.size != (x1 - x0, ry1 - ry0):
            return None
        prof = np.asarray(im.convert('L').resize((1, ry1 - ry0)), dtype=np.float32).reshape(-1)
    except Exception:
        return None
    dy, ok = _pbmod.estimate_shift(st['prof'], prof, 700)
    if not ok:
        _pb_log(f"tracking lost: err={_pbmod.LAST['err']:.1f} limit={0.30 * _pbmod.LAST['scale']:.1f} best dy={_pbmod.LAST['dy']}")
        return 'lost'
    if dy:
        for c in st['cards']:
            c['cy'] += dy
        st['prof'] = prof
        st['moved_at'] = now
        st['refine'] = True
    _pb['view'] = {'cards': [dict(c) for c in st['cards']], 'left': org[0], 'top': org[1],
                   'clip_top': st['clip_top'], 'height': size[1], 't': now}
    return 'ok'


_uia = {'reader': None, 'logged': 0, 'busy': False}


def _pb_wait_idle(limit=2.0):
    """Hotkey actions wait here until a badge read of the FansMetric window (if one is running) has finished."""
    end = time.monotonic() + limit
    while _uia['busy'] and time.monotonic() < end:
        time.sleep(0.01)



def _pb_uia_reader():
    if _uia['reader'] is None:
        try:
            import uia_reader as _ur
            _uia['reader'] = _ur.UiaReader()
        except Exception as exc:
            _uia['reader'] = False
            _pb_log(f'UI Automation not available ({exc}); using screen reading')
    return _uia['reader'] or None


def _pb_grab_area(u):
    """Grab the card columns below the tab strip (screen pixels). Returns (row profile, grey picture) or (None, None)."""
    try:
        import numpy as np
        x0, x1 = int(u['band'][0]), int(u['band'][1])
        y0, y1 = int(u['rows'][0]), int(u['rows'][1])
        if x1 - x0 < 100 or y1 - y0 < 120:
            return None, None
        im = _pb_grab((x0, y0, x1, y1))
        if im.size != (x1 - x0, y1 - y0):
            return None, None
        g = np.asarray(im.convert('L'), dtype=np.uint8)
        return g.mean(axis=1).astype(np.float32), g
    except Exception:
        return None, None


def _pb_shift_card(c, dy):
    c['cy'] += dy
    if c.get('rect'):
        l, t, r, b = c['rect']
        c['rect'] = (l, t + dy, r, b + dy)


def _pb_refine_card(area, ox, oy, c):
    """Find this fan's @id line by its remembered picture near where it should be. Exact and independent of how fresh the
    accessibility tree is. Returns True when found (the card is then placed from the picture)."""
    tpl = _pb_tpl['img'].get(c['id'])
    if tpl is None or area is None or not c.get('rect'):
        return False
    try:
        import cv2
        th, tw = tpl.shape
        l, t = int(c['rect'][0]) - 2 - ox, int(c['rect'][1]) - 2 - oy
        lx0, ly0 = max(0, l - 40), max(0, t - 380)
        lx1, ly1 = min(area.shape[1], l + tw + 40), min(area.shape[0], t + th + 380)
        if lx1 - lx0 <= tw or ly1 - ly0 <= th:
            return False
        res = cv2.matchTemplate(area[ly0:ly1, lx0:lx1], tpl, cv2.TM_CCOEFF_NORMED)
        _, mx, _, loc = cv2.minMaxLoc(res)
        if mx < 0.90:
            return False
        gx, gy = ox + lx0 + loc[0] + 2, oy + ly0 + loc[1] + 2
        w_, h_ = c['rect'][2] - c['rect'][0], c['rect'][3] - c['rect'][1]
        c['rect'] = (gx, gy, gx + w_, gy + h_)
        c['cy'] = gy + h_ / 2.0
        c['x'] = gx + w_ + 10
        return True
    except Exception:
        return False


def _pb_learn_card(area, ox, oy, c):
    """Remember the @id line of a poked fan (taken while the screen is perfectly still, so the position is right)."""
    try:
        import numpy as np
        l, t, r, b = [int(v) for v in c['rect']]
        x0, y0, x1, y1 = l - 2 - ox, t - 2 - oy, r + 2 - ox, b + 2 - oy
        if area is None or x0 < 0 or y0 < 0 or x1 > area.shape[1] or y1 > area.shape[0] or x1 - x0 < 24 or y1 - y0 < 8:
            return
        old = _pb_tpl['img'].get(c['id'])
        if old is not None and abs(old.shape[1] - (x1 - x0)) <= 2 and abs(old.shape[0] - (y1 - y0)) <= 2:
            return
        if len(_pb_tpl['img']) >= 600 and old is None:
            return
        tpl = area[y0:y1, x0:x1].copy()
        _pb_tpl['img'][c['id']] = tpl
        try:
            from PIL import Image as PILImage
            _PB_TPL_DIR.mkdir(parents=True, exist_ok=True)
            PILImage.fromarray(tpl).save(_PB_TPL_DIR / (c['id'] + '.png'))
        except Exception:
            pass
    except Exception:
        pass


def _pb_step_uia(win, st):
    """Exact method: ids from Windows' accessibility tree, positions locked to the screen by picture matching.
    Returns False when unavailable (the screen-reading method then takes over)."""
    rd = _pb_uia_reader()
    if rd is None or rd.disabled:
        return False
    u = st.setdefault('u', {})
    now = time.monotonic()
    moving = now - u.get('moved_at', 0.0) < 1.0
    slow = rd.mode == 'walk'
    due = now - u.get('read_at', 0.0) >= ((0.5 if slow else 0.10) if moving else (1.2 if slow else 0.35))
    prof = area = None
    ox = oy = 0
    if u.get('band'):
        ox, oy = int(u['band'][0]), int(u['rows'][0])
        prof, area = _pb_grab_area(u)
    # 1) follow the scroll by picture (relative movement since the last step)
    if prof is not None and u.get('prof') is not None and len(prof) == len(u['prof']) and u.get('cards'):
        dy, ok = _pbmod.estimate_shift(u['prof'], prof, 700)
        if ok:
            if dy:
                for c in u['cards']:
                    _pb_shift_card(c, dy)
                u['moved_at'] = now
                u['still_since'] = None
            elif float(abs(prof - u['prof']).mean()) < 1.5:
                u['still_since'] = u.get('still_since') or now
        else:
            u['cards'] = []                              # the page changed: wait for a fresh read
            u['still_since'] = None
            u['moved_at'] = now
    if prof is not None:
        u['prof'] = prof
    # 2) read the accessibility tree when it is due
    if due:
        _uia['busy'] = True
        try:
            data = rd.read(int(getattr(win, '_hWnd', 0)), (win.left, win.top, win.left + win.width, win.top + win.height))
        finally:
            _uia['busy'] = False
        if _uia['logged'] == 0 and getattr(rd, 'cached_error', ''):
            _pb_log('UI Automation batched read failed: ' + rd.cached_error)
        if _uia['logged'] < 6 or _uia['logged'] % 200 == 0:
            _n_ids = len(data['cards']) if data else '-'
            _pb_log('UI Automation read (%s): %s ms, %s elements, ids=%s' % (rd.mode, getattr(rd, 'last_ms', 0), getattr(rd, 'last_n', 0), _n_ids))
        _uia['logged'] += 1
        if rd.disabled:
            _pb_log('UI Automation could not read the window repeatedly - switching to screen reading')
            return False
        if data is None:
            return False
        u['read_at'] = time.monotonic()
        if data.get('no_list') or not data['cards']:
            u['cards'] = []
            _pb['view'] = None
            return True
        first = not u.get('band')
        u.update(clip_top=data['clip_top'], bottom=data['bottom'], band=data['band'], rows=(int(data['clip_top']), int(data['bottom'])))
        if first or area is None:
            prof, area = _pb_grab_area(u)
            u['prof'] = prof
            ox, oy = int(u['band'][0]), int(u['rows'][0])
        new = [c for c in data['cards'] if _pb_stage_for(c['id']) > 0]      # only fans with poke 1-3 get a badge
        verified, offs = set(), []
        for c in new:
            y_claim = c['cy']
            if _pb_refine_card(area, ox, oy, c):
                verified.add(c['id']); offs.append(c['cy'] - y_claim)
        if offs:
            offs.sort()
            d = offs[len(offs) // 2]                     # the tree's snapshot may be a little behind the screen: same shift for all
            for c in new:
                if c['id'] not in verified:
                    _pb_shift_card(c, d)
        prev = {c['id']: c['cy'] for c in u.get('cards') or []}
        if set(prev) != {c['id'] for c in new} or any(abs(c['cy'] - prev[c['id']]) > 1.5 for c in new if c['id'] in prev):
            u['moved_at'] = now
        u['cards'] = new
        # learn pictures of poked fans, only while everything has been still for a while and two reads agree
        if (area is not None and u.get('still_since') and now - u['still_since'] >= 0.6
                and u.get('last_claims') and all(abs(c['cy'] - u['last_claims'].get(c['id'], -9e9)) <= 1.0 for c in new)):
            for c in new:
                _pb_learn_card(area, ox, oy, c)
        u['last_claims'] = {c['id']: c['cy'] for c in new}
        if now - u.get('bg_at', 0.0) > 4.0 and new:
            u['bg_at'] = now
            try:
                c0 = new[0]
                px = _pb_grab((int(c0['x'] + 150), int(max(0, c0['cy'])), int(c0['x'] + 152), int(max(0, c0['cy'])) + 2))
                _pb['bg'] = px.convert('RGB').getpixel((0, 0))
            except Exception:
                pass
    elif area is not None and u.get('cards'):
        # 3) between reads: keep every known fan locked to its picture (cancels any drift of the scroll tracking)
        offs = []
        for c in u['cards']:
            before = c['cy']
            if _pb_refine_card(area, ox, oy, c):
                offs.append((c, c['cy'] - before))
        if offs:
            ids = {c['id'] for c, _ in offs}
            ds = sorted(d for _, d in offs)
            med = ds[len(ds) // 2]
            if abs(med) > 0.5:
                for c in u['cards']:
                    if c['id'] not in ids:
                        _pb_shift_card(c, med)
    if u.get('cards'):
        _pb['view'] = {'cards': [dict(c) for c in u['cards']], 'left': 0, 'top': 0,
                       'clip_top': u['clip_top'], 'height': u['bottom'], 't': time.monotonic()}
    else:
        _pb['view'] = None
    return True


def _pb_step(st):
    """One pass of the badge worker (~8-10 times a second). Follows scrolling, re-reads the list when the screen settles."""
    if not POKE_BADGE_OVERLAY:                          # hover mode: the window lookup is slow, so it is kept for a few seconds
        _t = time.monotonic()
        win = st.get('hwin')
        if win is None or _t - st.get('hwin_at', 0.0) > 3.0:
            win = find_fansmetric_window()
            st['hwin'], st['hwin_at'] = win, _t
        if win is None or getattr(win, 'isMinimized', False):
            st['hwin'] = None
            _ph_want(None, None, None)
            return
        return _pa_step(win, st)
    win = find_fansmetric_window()
    if win is None or getattr(win, 'isMinimized', False):
        _pb['view'] = None
        st.update(cards=None, prof=None)
        return
    if not _pb_foreground_is(win) or poke_in_progress or time.monotonic() < _pb['quiet_until']:
        _pb['view'] = None                              # hidden for now, but remembered: it comes back at once when you return
        return
    if _pb_step_uia(win, st):
        return
    now = time.monotonic()
    if st.get('cards'):
        got = _pb_fast_track(win, st, now)
        if got == 'ok' and not (st.get('refine') and now - st.get('moved_at', 0.0) >= 0.45):
            return                                      # still following the scroll; nothing else to do this round
        if got == 'lost':
            st['cards'] = None
            st['moved_at'] = now
    img, info = _capture_window_image(win, normalize=False, return_info=True)
    img = img.convert('RGB')
    st['origin'] = (info['crop_left_px'], info['crop_top_px'])
    st['imgsize'] = img.size
    st['rect'] = (win.left, win.top, win.width, win.height)
    cards = st.get('cards')
    if cards:
        band = st['band']
        prof = _pb_profile(img, band, st.get('rows'))
        dy, ok = _pbmod.estimate_shift(st['prof'], prof)
        if ok:
            if dy:
                for c in cards:
                    c['cy'] += dy
                st['prof'] = prof
                st['moved_at'] = now
                st['refine'] = True
        else:
            st['cards'] = cards = None                  # another page, or scrolled too far: hide until it is read again
            st['moved_at'] = now
        if cards:
            _pb['view'] = {'cards': [dict(c) for c in cards], 'left': info['crop_left_px'], 'top': info['crop_top_px'],
                           'clip_top': st['clip_top'], 'height': img.size[1], 't': now}
    else:
        _pb['view'] = None
    settled = now - st.get('moved_at', 0.0) >= (0.45 if st.get('cards') else 0.15)
    thumb = list(img.convert('L').resize((48, 27)).getdata())
    idle = st.get('idle_sig')
    if idle is not None and not st.get('cards'):
        # a page without the fan list (chat, settings...): look again only when the screen really changed
        if sum(1 for i in range(len(thumb)) if abs(thumb[i] - idle[i]) > 25) < 0.04 * len(thumb):
            return
        st['idle_sig'] = None
    if (st.get('panel') and st.get('panel_size') == img.size and _pb_tpl['img']
            and now - st.get('fast_at', 0.0) > 0.4
            and (not st.get('cards') or now - st.get('moved_at', 0.0) < 3.0)):
        # instant path: recognise fans we already know by the picture of their @id line
        st['fast_at'] = now
        fast = _pb_tpl_scan(img, st['panel'])
        if fast:
            cur = st.get('cards') or []
            have = {c['id'] for c in cur}
            new = [c for c in fast if c['id'] not in have]
            if new or not cur:
                cur = cur + new
                cur.sort(key=lambda d: d['cy'])
                clip = st.get('clip_top') or (st['panel'][2] + 150)
                band, rows_ = _pb_band_rows(cur, st['panel'], img.size, clip)
                st.update(cards=cur, band=band, rows=rows_, prof=_pb_profile(img, band, rows_), clip_top=clip, refine=True)
                _pb['view'] = {'cards': [dict(c) for c in cur], 'left': info['crop_left_px'], 'top': info['crop_top_px'],
                               'clip_top': clip, 'height': img.size[1], 't': now}
    if settled and (not st.get('cards') or st.get('refine')):
        # read the list (about a second) - if the user scrolled meanwhile, shift the result by that much
        found = _pb_read_list(img, st)
        st['refine'] = False
        if found:
            found, clip_top, panel = found
            if st.get('panel') != panel or st.get('panel_size') != img.size:
                _pb_panel_save(panel, img.size)
            st['panel'], st['panel_size'] = panel, img.size
            try:
                c0 = found[0]
                _pb['bg'] = img.getpixel((int(min(img.size[0] - 2, c0['x'] + 150)), int(min(img.size[1] - 2, max(1, c0['cy'])))))[:3]
            except Exception:
                pass
            _pb_tpl_learn(img, found)                   # remember how these fans look, so next time they appear instantly
        if not found:
            st['cards'] = None
            st['moved_at'] = time.monotonic()
            st['idle_sig'] = thumb
            return
        band, rows_ = _pb_band_rows(found, panel, img.size, clip_top)
        ocr_prof = _pb_profile(img, band, rows_)
        img2, info2 = _capture_window_image(win, normalize=False, return_info=True)
        img2 = img2.convert('RGB')
        prof2 = _pb_profile(img2, band, rows_)
        dy, ok = _pbmod.estimate_shift(ocr_prof, prof2)
        if not ok:
            _pb_log(f"after-read check failed: err={_pbmod.LAST['err']:.1f} limit={0.30 * _pbmod.LAST['scale']:.1f}")
            st['cards'] = None
            st['moved_at'] = time.monotonic()
            return
        for c in found:
            c['cy'] += dy
        st.update(cards=found, band=band, rows=rows_, prof=prof2, clip_top=clip_top, refine=bool(dy))
        if dy:
            st['moved_at'] = time.monotonic()
        _pb['view'] = {'cards': [dict(c) for c in found], 'left': info2['crop_left_px'], 'top': info2['crop_top_px'],
                       'clip_top': clip_top, 'height': img2.size[1], 't': time.monotonic()}


POKE_BADGE_OVERLAY = False        # the badges drawn over the scrolling FANS list were not reliable; heads-up alerts replace them
_pa = {'seen': None, 'last': {}, 'toasts': [], 'logged': 0}

_ph = {'win': None, 'pid': None, 'rect': None, 'show_at': 0.0, 'miss': 0.0, 'last_q': 0.0, 'band': None, 'band_at': -99.0}

POKE_NOTIF_ALERTS = False         # (old idea) toast when a poked fan appears in NOTIFICATIONS; the hover card replaced it


def _cursor_pos():
    try:
        class _PT(ctypes.Structure):
            _fields_ = [('x', ctypes.c_long), ('y', ctypes.c_long)]
        pt = _PT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return int(pt.x), int(pt.y)
    except Exception:
        return None


def _ph_row_zone(pos, rect):
    """Rough zone of the name line of a fan card (fallback and quick exit)."""
    l, t, r, b = rect
    k = max(.6, (r - l) / 320.0)
    return l + 64 * k <= pos[0] <= r - 50 * k and t + 10 * k <= pos[1] <= t + 44 * k


def _ph_on_name(pos, rect, hit):
    """True only while the mouse is on the fan's NAME text (the white "Mike"), not on the avatar, @handle, buttons or tabs."""
    if not _ph_row_zone(pos, rect):
        return False
    try:
        if hit:
            name, hr = hit
            hw, hh = hr[2] - hr[0], hr[3] - hr[1]
            if 0 < hw <= 300 and 0 < hh <= 40:               # the exact text element under the mouse
                n = str(name or '').strip()
                if not n or n.startswith('@') or n.lower() in ('edit', 'more', 'more options'):
                    return False
                return True
    except Exception:
        pass
    return True                                               # the tree gave nothing finer: the whole name line counts


def _pa_step(win, st):
    """Worker thread (~40 times a second): which fan card is the mouse on? Asks Windows' accessibility tree for the
    element under the cursor (exact, always current - scrolling cannot misplace it) and shows the poke stage at once.
    Only an element the size of a FANS-list card (about 320 x 280, exactly one @id inside) counts - Messages rows and
    NOTIFICATIONS entries are smaller - so no page layout has to be read at all."""
    rd = _pb_uia_reader()
    if rd is None:
        return
    if rd.disabled and hasattr(rd, '_revive'):
        rd._revive()                                          # it is only ever switched off for a few seconds
    if bool(rd.disabled) != bool(st.get('rd_off')):
        st['rd_off'] = bool(rd.disabled)
        _pb_log('Poke hover: reader paused after errors, retrying shortly' if rd.disabled else 'Poke hover: reader running again')
    if rd.disabled:
        return
    now = time.monotonic()
    pos = _cursor_pos()
    fg_now = _pb_hover_ok(win, pos)                       # active OR just hovered from another window / monitor
    try:
        down = bool(ctypes.windll.user32.GetAsyncKeyState(0x01) & 0x8000)
    except Exception:
        down = False
    if fg_now and ((down and not st.get('mdown')) or not st.get('fg_prev')):
        st['burst_until'] = now + 4.0                         # click / window just came back: page may be switching
        st['ready'] = False
        st['burst_t0'] = now
        st['burst_logged'] = False
    st['mdown'] = down
    st['fg_prev'] = fg_now
    gap = 0.04 if now < st.get('burst_until', 0.0) else 0.4   # probe fast right after a click so the new page's tree is built sooner
    if (poke_badges_enabled and not poke_in_progress and now >= _pb['quiet_until'] and now - st.get('keepwarm', 0.0) > gap
            and fg_now):
        st['keepwarm'] = now                                  # wakes the accessibility tree of the page now on screen
        try: rd.probe(win.left + int(win.width * 0.38), win.top + int(win.height * 0.62))
        except Exception: pass
        if (now < st.get('burst_until', 0.0) and not st.get('ready') and now - st.get('warm_t', 0.0) > 0.5
                and pos is not None and win.left <= pos[0] <= win.left + win.width and win.top <= pos[1] <= win.top + win.height):
            st['warm_t'] = now                                # right after a click: real reads make Chromium rebuild the tree
            _uia['busy'] = True
            try:
                wt = getattr(rd, 'warm_tree', None)
                res = wt(int(getattr(win, '_hWnd', 0))) if wt else None
            finally:
                _uia['busy'] = False
            if res and res[1] > 0:
                st['ready'] = True
                took = int((time.monotonic() - st.get('burst_t0', now)) * 1000)
                st['ready_logs'] = st.get('ready_logs', 0) + 1
                if st['ready_logs'] <= 12 or took > 1500:           # the log stays readable: first few + the slow ones
                    _pb_log('Poke hover: tree ready %d ms after the click (%d elements, %d ids)' % (took, res[0], res[1]))
    if (pos is None or poke_in_progress or now < _pb['quiet_until'] or not poke_badges_enabled
            or not _pb_hover_ok(win, pos)
            or not (win.left <= pos[0] <= win.left + win.width and win.top + 130 <= pos[1] <= win.top + win.height)):
        _ph_want(None, None, pos)
        return
    if not st.get('warm'):                                    # load + warm up the accessibility package once, early
        st['warm'] = True
        _uia['busy'] = True
        t0 = time.monotonic()
        try:
            rd.id_at_point(win.left + win.width // 2, win.top + win.height // 2)
        finally:
            _uia['busy'] = False
        _pb_log('Poke hover: warm-up %d ms (%s)%s' % (int((time.monotonic() - t0) * 1000), 'slow' if getattr(rd, 'fast_failed', False) else 'fast',
                (' [' + getattr(rd, 'iuia_src', '') + ']') + (' fast error: ' + rd.fast_error if getattr(rd, 'fast_error', '') else '')))
        return
    if st.get('last_pos') != pos:
        st['last_pos'] = pos
        st['mouse_moved'] = now
    fb = _ph.get('fans_band')
    since = now - st.get('burst_t0', -999.0)
    no_card_yet = bool(st.get('burst_t0')) and since < 12.0 and st.get('card_t', 0.0) < st.get('burst_t0', 0.0)
    in_col = bool(pos[1] >= win.top + 230 and win.left + .20 * win.width <= pos[0] <= win.left + .66 * win.width
                  and (not fb or fb[0] - 6 <= pos[0] <= fb[1] + 14))
    st['loading'] = False                                 # LOADING has its own window + thread now (_pl_worker)
    cc = st.get('card')                                   # (id, rect, time) of the card found a moment ago
    if cc and now - cc[2] < 0.60 and cc[1][0] <= pos[0] <= cc[1][2] and cc[1][1] <= pos[1] <= cc[1][3] and not _ph_row_zone(pos, cc[1]):
        _ph_want(None, None, pos)                         # on the card but not on the name line: no badge, no lookup needed
        return
    r = _ph['rect']
    inside = bool(r and r[0] <= pos[0] <= r[2] and r[1] <= pos[1] <= r[3])
    if inside and _ph['pid'] and now - _ph['last_q'] < 0.30 and st.get('hit_pos') == pos:
        return                                            # still on the same card; re-checked every 0.3 s (scroll)
    if not inside and now - _ph['last_q'] < 0.05:
        return                                            # never hammer FansMetric
    if _ph.get('none_pos') == pos and now - _ph['last_q'] < 0.25:
        _ph_want(None, None, pos)  # nothing here a moment ago and the mouse has not moved
        return
    _ph['last_q'] = now
    t0 = time.monotonic()
    got = rd.id_at_point(pos[0], pos[1])
    ms = int((time.monotonic() - t0) * 1000)
    if _ph.get('qlog', 0) < 25 or ms > 400:
        _ph['qlog'] = _ph.get('qlog', 0) + 1
        _pb_log('Poke hover: lookup %d ms -> %s (%s) why=%s' % (ms, got[0] if got else None, 'slow' if getattr(rd, 'fast_failed', False) else 'fast', getattr(rd, 'why', '')))
    if got:
        try:                                                  # ads / chat messages carry ids too: only the FANS column counts
            if now - st.get('band_read', 0.0) > 3.0 or not _ph.get('fans_band'):
                st['band_read'] = now
                keep = (rd.failed, rd.disabled, rd.mode)      # this extra read must never switch the reader off
                _uia['busy'] = True
                try:
                    data = rd.read(int(getattr(win, '_hWnd', 0)), (win.left, win.top, win.left + win.width, win.top + win.height))
                finally:
                    _uia['busy'] = False
                    rd.failed, rd.disabled, rd.mode = keep
                if (data and not data.get('no_list') and data.get('band') and 250 <= data['band'][1] - data['band'][0] <= 1400
                        and data.get('cards') and win.left <= data['band'][0] <= win.left + .5 * win.width):
                    _ph['fans_band'] = data['band']           # only a real FANS list (cards inside, sane width/place)
            fb = _ph.get('fans_band')
            if fb and not (fb[0] - 6 <= got[1][0] and got[1][2] <= fb[1] + 14):
                got = None
        except Exception:
            pass
    if got:
        st['ready'] = True
        st['card_t'] = now
        _ph['none_pos'] = None
        st['card'] = (got[0], got[1], now)
        st['hit_pos'] = pos
        if _ph_on_name(pos, got[1], getattr(rd, 'hit', None)):
            _ph_want(got[0], got[1], pos)
        else:
            _ph_want(None, None, pos)
    else:
        _ph['none_pos'] = pos
        _ph_want(None, None, pos)


def _ph_want(pid, rect, pos):
    """Worker thread: tell the main thread which fan card the mouse is on (None = none)."""
    now = time.monotonic()
    if pid is None:
        if _ph['pid'] == '__loading__':
            return                                         # LOADING belongs to the loading watcher (it hides it itself)
        if _ph['pid'] is None and not (_ph['win'] and _ph['win'].get('shown')):
            return
        if not _ph['miss']:
            _ph['miss'] = now                              # tiny grace so a one-frame miss does not flicker
            return
        if now - _ph['miss'] < 0.12:
            return
        _ph['miss'] = 0.0
        _ph['pid'] = None; _ph['rect'] = None
        try: root.after(0, _ph_hide)
        except Exception: pass
        return
    _ph['miss'] = 0.0
    _ph['rect'] = rect
    if pid == _ph['pid']:
        return
    _ph['pid'] = pid
    try: root.after(0, _ph_show, pid, pos)
    except Exception: pass


def _ph_fade(w, target, frames, done=None):
    """Fade the card window's opacity to `target` in `frames` steps (~16 ms each)."""
    if w.get('job') is not None:
        try: root.after_cancel(w['job'])
        except Exception: pass
        w['job'] = None
    start, n = w.get('alpha', 0.0), max(1, int(frames))
    i = [0]

    def step():
        i[0] += 1
        k = min(1.0, i[0] / n)
        k = 1 - (1 - k) ** 2                                  # ease-out
        w['alpha'] = start + (target - start) * k
        try: w['top'].attributes('-alpha', max(0.0, min(1.0, w['alpha'])))
        except Exception: pass
        if i[0] < n:
            w['job'] = root.after(16, step)
        else:
            w['job'] = None
            if done:
                done()
    step()


def _ph_hide(instant=False):
    w = _ph.get('win')
    if w is None or not w['shown']:
        return
    w['hiding'] = True

    def finish():
        if w.get('hiding'):
            try: w['top'].withdraw()
            except Exception: pass
            w['shown'] = False
            w['hiding'] = False
    if instant:
        _ph_fade(w, 0.0, 1, finish)
    else:
        _ph_fade(w, 0.0, 12, finish)                         # ~190 ms fade out


_PH_W, _PH_H = 196, 62
_PH_SUB = {0: 'nothing sent yet', 1: '1st poke sent', 2: '2nd poke sent', 3: '3rd poke sent'}


def _ph_font(px, bold):
    from PIL import ImageFont
    names = ('Poppins-Bold.ttf', 'segoeuib.ttf') if bold else ('Poppins-Regular.ttf', 'segoeui.ttf')
    for n in names:
        for path in (Path(__file__).with_name('tools') / 'fonts' / n, 'C:/Windows/Fonts/' + n):
            try:
                return ImageFont.truetype(str(path), px)
            except Exception:
                pass
    return ImageFont.load_default()


_PH_THEME = {
    'normal': dict(bg=(22, 24, 31), line=(44, 48, 60), ui=(73, 189, 230), none=(125, 135, 153), sub=(150, 160, 180), lw=1),
    'neon':   dict(bg=(30, 15, 33), line=(150, 48, 138), ui=(255, 92, 214), none=(205, 140, 200), sub=(214, 160, 208), lw=2),
}


def _ph_render(stage, tname='normal', dots=3, sub=None):
    """Side-bar tag: flat dark card, coloured bar on the left, 'POKE 2/3' + a small line. Drawn 4x and scaled down.
    stage 4 = the 'LOADING' hint. Colours follow the theme (blue NORMAL / pink NEON)."""
    from PIL import Image, ImageDraw
    SS = 4
    W, H = _PH_W, _PH_H
    T = _PH_THEME.get(tname, _PH_THEME['normal'])
    key = (1, 0, 1)
    im = Image.new('RGB', (W * SS, H * SS), key)
    d = ImageDraw.Draw(im)
    if stage == 4:
        accent = T['ui']
    elif stage > 0:
        accent = _hex_rgb(_pbmod.badge_colors(stage, theme_mode)[0])
    else:
        accent = T['none']
    d.rounded_rectangle((0, 0, W * SS - 1, H * SS - 1), 11 * SS, fill=T['bg'], outline=T['line'], width=SS * T['lw'])
    d.rounded_rectangle((8 * SS, 8 * SS, 15 * SS, (H - 8) * SS), 3 * SS, fill=accent)
    title = ('LOADING' + '.' * dots) if stage == 4 else (('POKE %d/3' % stage) if stage > 0 else 'NO POKE YET')
    if sub is None:
        sub = 'FansMetric is opening the page' if stage == 4 else _PH_SUB.get(stage, '')
    d.text((30 * SS, 24 * SS), title, font=_ph_font(14 * SS, True), fill=accent, anchor='lm')
    d.text((30 * SS, 43 * SS), sub, font=_ph_font(10 * SS, False), fill=T['sub'], anchor='lm')
    return im.resize((W, H), Image.LANCZOS)


def _ph_name_under_cursor(pos, st):
    """True when bright (white) text sits right under the mouse on a dark background = a fan name."""
    try:
        import numpy as np
        now = time.monotonic()
        if st.get('nm_pos') == pos and now - st.get('nm_t', 0.0) < 0.2:
            return st.get('nm_val', False)
        im = _pb_grab((pos[0] - 70, pos[1] - 16, pos[0] + 70, pos[1] + 16))
        a = np.asarray(im.convert('RGB'), dtype=np.int16)
        wm = (a[:, :, 0] > 190) & (a[:, :, 1] > 190) & (a[:, :, 2] > 190)
        white = float(wm.mean())
        run = 0                                               # the hovered name is UNDERLINED: a long solid white row
        for row in wm:
            cnt = 0
            for v in row:
                cnt = cnt + 1 if v else 0
                if cnt > run:
                    run = cnt
        val = bool(run >= 36 and white < .6)
        st['name_info'] = 'underline run=%d white=%.3f' % (run, white)
        st['nm_pos'], st['nm_t'], st['nm_val'] = pos, now, val
        return val
    except Exception as e:
        st['name_info'] = 'error: %r' % (e,)
        return False


def _ph_fans_tab_active(win, st):
    """True when FansMetric's first tab ("Fans - OnlyFans") is the one on screen. The active tab is drawn as a lighter box
    (about 55,65,81) on the dark strip (17,24,39). One thin screenshot of the strip is checked in two rows; the Fans tab box
    starts near the left edge, so it only counts when that stretch is (almost) all active-tab colour."""
    now = time.monotonic()
    c = st.get('fans_tab')
    if c and now - c[0] < 0.3:
        return c[1]
    ok = False
    info = ''
    try:
        import numpy as np
        k = max(.5, win.width / 1920.0)
        x0, y0 = int(win.left + 150 * k), int(win.top + 120 * k)
        w_, h_ = int(260 * k), int(30 * k)
        im = _pb_grab((x0, y0, x0 + w_, y0 + h_))
        a = np.asarray(im.convert('RGB'), dtype=np.int16)
        fr = []
        for yy in (6, 23):                                      # above and below the tab's text line
            row = a[min(a.shape[0] - 1, int(yy * k))]
            seg = row[int(40 * k):int(190 * k)]                  # x = 190 .. 340 of the window (inside the tab box)
            m = (np.abs(seg[:, 0] - 55) <= 14) & (np.abs(seg[:, 1] - 65) <= 14) & (np.abs(seg[:, 2] - 81) <= 14)
            fr.append(float(m.mean()))
        ok = min(fr) >= .85
        info = 'rows=%s px=%s' % (['%.2f' % f for f in fr], tuple(int(v) for v in a[min(a.shape[0] - 1, int(6 * k))][int(100 * k)]))
    except Exception as exc:
        ok = False
        info = 'error %r' % (exc,)
    st['fans_tab'] = (now, ok)
    st['fans_tab_info'] = info
    return ok


def _ph_build(th):
    """One reusable card window (created once; showing it later is instant)."""
    W, H = _PH_W, _PH_H
    top = _pop_window(W, H, -2000, -2000)
    cv = tk.Canvas(top, width=W, height=H, bd=0, highlightthickness=0, bg=POP_KEY)
    cv.pack(fill='both', expand=True)
    photos = {}
    try:
        for st_ in (0, 1, 2, 3, 4):
            photos[st_] = ImageTk.PhotoImage(_ph_render(st_, th['t']), master=cv)
        for n_ in range(_PL_FRAMES):                          # LOADING card frames: spinner + running dots
            photos[('L', n_)] = ImageTk.PhotoImage(_pl_render(th['t'], n_), master=cv)
    except Exception:
        photos = {}
    img_item = cv.create_image(0, 0, image=photos.get(0), anchor='nw') if photos else None
    txt = cv.create_text(20, 31, text='', anchor='w', font=('Segoe UI', 12, 'bold'), fill='#ffffff')
    if photos:
        cv.itemconfigure(txt, state='hidden')
    if os.name == 'nt':                                       # clicks and hovering pass straight through it
        try:
            hwnd = ctypes.windll.user32.GetParent(top.winfo_id()) or top.winfo_id()
            style = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
            ctypes.windll.user32.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x00000080 | 0x00000020)
        except Exception:
            pass
    top.withdraw()
    return {'top': top, 'cv': cv, 'txt': txt, 'img': img_item, 'photos': photos, 'theme': th['t'], 'W': W, 'H': H, 'shown': False, 'alpha': 0.0, 'job': None, 'hiding': False}


def _ph_animate(w, n):
    """The three dots of the LOADING card run: LOADING -> LOADING. -> LOADING.. -> LOADING... (one step every 0.3 s)."""
    if w.get('anim') is not None:
        try: root.after_cancel(w['anim'])
        except Exception: pass
        w['anim'] = None
    if _ph.get('pid') != '__loading__' or not w.get('shown'):
        return
    try: w['cv'].itemconfigure(w['img'], image=w['photos'][('L', n % _PL_FRAMES)])
    except Exception: return
    w['anim'] = root.after(65, _ph_animate, w, n + 1)


def _ph_spend_sub(pid, stage):
    """'1st poke sent • $14.40 spent' when his spend on this model was seen in his chat (Fan Info)."""
    try:
        st = poke_state.get(_profile_state_key(pid)) or {}
        spent = st.get('spent')
        if spent is None:
            return None
        base = {0: 'no poke yet', 1: '1st poke', 2: '2nd poke', 3: '3rd poke'}.get(max(0, min(3, stage)), '')
        return f"{base} \u2022 ${spent:,.2f} spent"
    except Exception:
        return None


def _ph_show(pid, pos):
    """Main thread: slim glass notification next to the cursor with ONLY the fan's poke stage."""
    if _ph['pid'] != pid or not poke_badges_enabled or poke_in_progress or time.monotonic() < _pb['quiet_until']:
        return
    _pl_hide_now()
    th = _pop_theme()
    w = _ph.get('win')
    if w is None or w['theme'] != th['t']:
        if w is not None:
            try: w['top'].destroy()
            except Exception: pass
        w = _ph['win'] = _ph_build(th)
    stage = 4 if pid == '__loading__' else _pb_stage_for(pid)
    cv = w['cv']
    spend_sub = _ph_spend_sub(pid, stage) if stage != 4 else None
    if w['photos'] and spend_sub:                         # his spend (seen in his chat) on the second line
        key = ('S', stage, spend_sub)
        if key not in w['photos']:
            try:
                w['photos'][key] = ImageTk.PhotoImage(_ph_render(max(0, min(3, stage)), w['theme'], sub=spend_sub), master=cv)
            except Exception:
                key = max(0, min(3, stage))
        cv.itemconfigure(w['img'], image=w['photos'][key])
    elif w['photos']:
        cv.itemconfigure(w['img'], image=w['photos'][('L', 0) if stage == 4 else max(0, min(3, stage))])
        if stage == 4:
            _ph_animate(w, 0)
    else:
        cv.itemconfigure(w['txt'], text=('LOADING...' if stage == 4 else (('POKE %d/3' % stage) if stage > 0 else 'NO POKE YET')), state='normal',
                         fill=_pbmod.badge_colors(min(3, stage), theme_mode)[0])
    W, H = w['W'], w['H']
    x, y = (pos[0] + 22, pos[1] + 26) if pos else (100, 100)
    try:
        left, top, right, bottom = _pop_work_area()
        if x + W > right:
            x = pos[0] - W - 14
        if y + H > bottom:
            y = pos[1] - H - 14
        x = max(left, x); y = max(top, y)
    except Exception:
        pass
    w['top'].geometry('%dx%d+%d+%d' % (W, H, int(x), int(y)))
    w['hiding'] = False
    if not w['shown']:
        w['alpha'] = 0.0
        try: w['top'].attributes('-alpha', 0.0)
        except Exception: pass
        try: w['top'].deiconify()
        except Exception: pass
        try: w['top'].attributes('-topmost', True)
        except Exception: pass
        w['shown'] = True
        _ph_fade(w, 1.0, 7)                                   # ~110 ms fade in
    elif w.get('alpha', 1.0) < 1.0:
        _ph_fade(w, 1.0, 5)                                   # came back while fading out
    _ph['show_at'] = time.monotonic()


def _pa_feed(ids):
    """ids = fans currently listed in NOTIFICATIONS. A fan that was not there on the previous read is new."""
    now = time.monotonic()
    cur = set(ids)
    if _pa['seen'] is None:                              # first read: everything already there is old news
        _pa['seen'] = cur
        return
    fresh = [i for i in ids if i not in _pa['seen']]
    _pa['seen'] = cur
    for pid in fresh:
        if now - _pa['last'].get(pid, -999.0) < 45.0:    # same fan flickering in and out of the list
            continue
        stage = _pb_stage_for(pid)
        if stage <= 0:
            continue                                       # no poke yet: nothing to warn about
        _pa['last'][pid] = now
        try: root.after(0, _pa_show, pid, stage)
        except Exception: pass


def _pa_render(pid, stage, w, h):
    """Smooth dark pill: colour dot - @id - "Poke N/3". Drawn at 4x and scaled down."""
    from PIL import Image, ImageDraw
    SS = 4
    accent, fill, fg = _pbmod.badge_colors(stage, theme_mode)
    A, F = _hex_rgb(accent), _hex_rgb(fill)
    im = Image.new('RGB', (w * SS, h * SS), (16, 18, 24))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, w * SS - 1, h * SS - 1), h * SS // 2, fill=A)
    t = 2 * SS
    d.rounded_rectangle((t, t, w * SS - 1 - t, h * SS - 1 - t), (h * SS - 2 * t) // 2, fill=(22, 24, 31))
    r = int(h * SS * 0.16)
    cx = int(h * SS * 0.5)
    d.ellipse((cx - r, h * SS // 2 - r, cx + r, h * SS // 2 + r), fill=A)
    d.text((cx + r + 10 * SS, h * SS // 2), '@' + pid, font=_pb_font(int(h * 0.36 * SS)), fill=(236, 240, 248), anchor='lm')
    pf = _pb_font(int(h * 0.36 * SS))
    pw = int(d.textlength(_pbmod.badge_text(stage), font=pf))
    bx1 = w * SS - 12 * SS
    bx0 = bx1 - pw - 22 * SS
    d.rounded_rectangle((bx0, 8 * SS, bx1, h * SS - 8 * SS), (h * SS - 16 * SS) // 2, fill=F, outline=A, width=2 * SS)
    d.text(((bx0 + bx1) / 2, h * SS // 2), _pbmod.badge_text(stage), font=pf, fill=_hex_rgb(fg), anchor='mm')
    return im.resize((w, h), Image.LANCZOS)


def _pa_show(pid, stage):
    """Main thread: slide a small alert in at the bottom-right of the FansMetric window, click-through, gone after ~7 s."""
    if poke_in_progress or time.monotonic() < _pb['quiet_until'] or not poke_badges_enabled:
        return
    win = find_fansmetric_window()
    if win is None or getattr(win, 'isMinimized', False):
        return
    for t in list(_pa['toasts']):                        # same fan again: replace
        if t['pid'] == pid:
            _pa_close(t)
    w_, h_ = 330, 52
    tw = _pb_make_window()
    top = tw['win']
    try:
        img = _pa_render(pid, stage, w_, h_)
        tw['photo'] = ImageTk.PhotoImage(img, master=tw['cv'])
        tw['cv'].configure(width=w_, height=h_, bg='#101218')
        tw['cv'].create_image(0, 0, image=tw['photo'], anchor='nw')
    except Exception:
        tw['cv'].configure(width=w_, height=h_, bg='#101218')
        tw['cv'].create_text(w_ / 2, h_ / 2, text='@%s   %s' % (pid, _pbmod.badge_text(stage)), fill='#ffffff')
    tw.update(pid=pid, born=time.monotonic(), w=w_, h=h_)
    _pa['toasts'].append(tw)
    _pa_layout()
    try:
        top.deiconify(); top.attributes('-topmost', True)
    except Exception:
        pass
    _pa_tick()


def _pa_layout():
    win = find_fansmetric_window()
    if win is None:
        return
    x = int(win.left + win.width - 360)
    y = int(win.top + win.height - 110)
    for i, t in enumerate(reversed(_pa['toasts'][-4:])):
        try: t['win'].geometry('%dx%d+%d+%d' % (t['w'], t['h'], x, y - i * (t['h'] + 8)))
        except Exception: pass


def _pa_close(t):
    try: t['win'].destroy()
    except Exception: pass
    try: _pa['toasts'].remove(t)
    except Exception: pass


def _pa_tick():
    now = time.monotonic()
    for t in list(_pa['toasts']):
        age = now - t['born']
        if age > 7.0 or not poke_badges_enabled or now < _pb['quiet_until'] or poke_in_progress:
            _pa_close(t); continue
        a = min(1.0, age / 0.25, (7.0 - age) / 0.5)
        try: t['win'].attributes('-alpha', max(0.0, min(0.97, a)))
        except Exception: pass
    if _pa['toasts']:
        _pa_layout()
        try: root.after(33, _pa_tick)
        except Exception: pass


def _pb_worker():
    _pb_tpl_load()
    st = {}
    _pb_panel_load(st)
    time.sleep(2)                                      # the OCR warm-up runs in parallel
    while not _pb['stop']:
        try:
            if poke_badges_enabled:
                _pb_step(st)
            else:
                st.clear()
        except Exception:
            st.clear()
            time.sleep(1.0)
        if not POKE_BADGE_OVERLAY:
            time.sleep(0.025)
        else:
            time.sleep(0.01 if time.monotonic() - st.get('moved_at', 0.0) < 1.2 else 0.07)


# ======================= LOADING hint (own window + own thread, independent of the badge pipeline) =======================
# Shows a small animated "LOADING" card next to the mouse while it rests on a fan NAME (FansMetric underlines the hovered
# name) and no poke badge is on screen. It keeps going until the real badge appears, then gets out of the way.
_pl = {'win': None, 'shown': False, 'want': False, 'anim': None, 'n': 0, 'hold': 0.0, 'stop': False, 'thread': None}
_PL_FRAMES = 16


def _pl_render(tname, n):
    """One frame of the loading card: spinning arc, 'LOADING' with running dots, small sub line. Drawn 4x, scaled down."""
    from PIL import Image, ImageDraw
    SS = 4
    W, H = _PH_W, _PH_H
    T = _PH_THEME.get(tname, _PH_THEME['normal'])
    im = Image.new('RGB', (W * SS, H * SS), (1, 0, 1))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((0, 0, W * SS - 1, H * SS - 1), 14 * SS, fill=T['bg'], outline=T['line'], width=SS * T['lw'])
    cx, cy, R = 31 * SS, (H // 2) * SS, 12 * SS
    base = T['line'] if tname == 'normal' else (88, 38, 84)
    d.ellipse((cx - R, cy - R, cx + R, cy + R), outline=base, width=3 * SS)           # faint track
    ang = n * (360.0 / _PL_FRAMES)
    steps = 14
    for i in range(steps):                                                           # comet tail: fading segments
        k = (i + 1) / steps
        col = tuple(int(base[c] + (T['ui'][c] - base[c]) * k) for c in range(3))
        a0 = ang - 150 + i * (150.0 / steps)
        d.arc((cx - R, cy - R, cx + R, cy + R), a0, a0 + 150.0 / steps + 4, fill=col, width=3 * SS)
    dots = (n * 4 // _PL_FRAMES) % 4
    d.text((54 * SS, 24 * SS), 'LOADING' + '.' * dots, font=_ph_font(14 * SS, True), fill=T['ui'], anchor='lm')
    d.text((54 * SS, 43 * SS), 'badge is on its way', font=_ph_font(10 * SS, False), fill=T['sub'], anchor='lm')
    return im.resize((W, H), Image.LANCZOS)


def _pl_build(th):
    W, H = _PH_W, _PH_H
    top = _pop_window(W, H, -2000, -2000)
    cv = tk.Canvas(top, width=W, height=H, bd=0, highlightthickness=0, bg=POP_KEY)
    cv.pack(fill='both', expand=True)
    frames = [ImageTk.PhotoImage(_pl_render(th['t'], n), master=cv) for n in range(_PL_FRAMES)]
    item = cv.create_image(0, 0, image=frames[0], anchor='nw')
    if os.name == 'nt':                                       # clicks and hovering pass straight through it
        try:
            hwnd = ctypes.windll.user32.GetParent(top.winfo_id()) or top.winfo_id()
            style = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
            ctypes.windll.user32.SetWindowLongW(hwnd, -20, style | 0x08000000 | 0x00000080 | 0x00000020)
        except Exception:
            pass
    top.withdraw()
    return {'top': top, 'cv': cv, 'frames': frames, 'item': item, 'theme': th['t'], 'W': W, 'H': H, 'alpha': 0.0, 'job': None}


def _pl_tick():
    """Main thread, every ~65 ms while the card is shown: next spinner frame."""
    w = _pl.get('win')
    _pl['anim'] = None
    if not _pl['shown'] or w is None:
        return
    _pl['n'] = (_pl['n'] + 1) % _PL_FRAMES
    try: w['cv'].itemconfigure(w['item'], image=w['frames'][_pl['n']])
    except Exception: return
    _pl['anim'] = root.after(65, _pl_tick)


def _pl_apply(on, pos):
    """Main thread: show / move / hide the loading card."""
    if not on:
        if _pl['shown']:
            _pl['shown'] = False
            w = _pl.get('win')
            if w is not None:
                def fin():
                    if not _pl['shown']:
                        try: w['top'].withdraw()
                        except Exception: pass
                _ph_fade(w, 0.0, 6, fin)
        return
    if poke_in_progress or not poke_badges_enabled:
        return
    th = _pop_theme()
    w = _pl.get('win')
    if w is None or w['theme'] != th['t']:
        if w is not None:
            try: w['top'].destroy()
            except Exception: pass
        w = _pl['win'] = _pl_build(th)
    W, H = w['W'], w['H']
    x, y = (pos[0] + 22, pos[1] + 26) if pos else (100, 100)
    try:
        left, top, right, bottom = _pop_work_area()
        if x + W > right: x = pos[0] - W - 14
        if y + H > bottom: y = pos[1] - H - 14
        x = max(left, x); y = max(top, y)
    except Exception:
        pass
    w['top'].geometry('%dx%d+%d+%d' % (W, H, int(x), int(y)))
    if not _pl['shown']:
        _pl['shown'] = True
        w['alpha'] = 0.0
        try: w['top'].attributes('-alpha', 0.0)
        except Exception: pass
        try: w['top'].deiconify()
        except Exception: pass
        try: w['top'].attributes('-topmost', True)
        except Exception: pass
        _ph_fade(w, 1.0, 7)
        if _pl['anim'] is None:
            _pl['anim'] = root.after(65, _pl_tick)
    elif w.get('alpha', 1.0) < 1.0:
        _ph_fade(w, 1.0, 5)


def _pl_badge_visible():
    """Main thread: is a poke badge REALLY on screen right now? (asks the window itself, no flags)"""
    w = _ph.get('win')
    if w is None:
        return False
    try:
        if not w['top'].winfo_ismapped() or w.get('hiding'):
            return False                                      # not on screen / on its way out
        return w.get('alpha', 0.0) >= .05 or time.monotonic() - _ph.get('show_at', 0.0) < .3   # (just appearing counts)
    except Exception:
        return False


def _pl_decide(pos):
    """Main thread, mouse is on a fan name. ONE card window, two priorities: poke badge (1) beats LOADING (0).
    If the badge worker has a fan for this spot, its badge is (or is about to be) in the card - nothing to do.
    Otherwise the same card shows LOADING; the moment the badge worker finds the fan it simply replaces it."""
    pid = _ph.get('pid')
    state = 'badge' if (pid and pid != '__loading__') else 'loading'
    if state != _pl.get('vis_logged'):
        _pl['vis_logged'] = state
        _pb_log('Loading hint: %s' % ('poke badge has the card (%s)' % pid if state == 'badge' else 'card shows LOADING'))
    if state == 'badge' or pid == '__loading__':
        return
    _ph['pid'] = '__loading__'
    _ph['rect'] = None
    _ph['miss'] = 0.0
    _ph_show('__loading__', pos)


def _pl_off():
    """Main thread: mouse left the name - LOADING goes (a poke badge in the card is left alone)."""
    if _ph.get('pid') == '__loading__':
        _ph['pid'] = None
        _pl['vis_logged'] = None
        _ph_hide()


def _pl_hide_now():
    """Main thread: a real badge is about to show - the loading card leaves at once."""
    if _pl['shown']:
        _pl['shown'] = False
        w = _pl.get('win')
        if w is not None:
            _ph_fade(w, 0.0, 1, lambda: w['top'].withdraw())


_PL_MIN = 16                                              # shortest underline that counts (short names like 'Bas', 'U')


def _pl_underline(pos):
    """(length of the hovered name's underline, white share). FansMetric underlines a fan name while the mouse is on it:
    a thin white line (1-3 px) right under the letters (gap <= 3 px), under the mouse, starting and ending inside the picture.
    Not counted: thick bars (scroll bars, buttons), borders running through the picture (message box), the tab marker under
    SUBSCRIPTION (it sits ~10 px below its text), anything with white right below it."""
    import numpy as np
    im = _pb_grab((pos[0] - 150, pos[1] - 18, pos[0] + 150, pos[1] + 22))
    a = np.asarray(im.convert('RGB'), dtype=np.int16)
    wm = (a[:, :, 0] > 185) & (a[:, :, 1] > 185) & (a[:, :, 2] > 185)
    n, cw = wm.shape
    mx = pos[0] - (pos[0] - 150)                              # mouse column inside the picture (150)
    runs, spans = [], []
    for row in wm:
        best, bs, start = 0, (0, -1), None
        for k in range(cw + 1):
            v = bool(row[k]) if k < cw else False
            if v and start is None:
                start = k
            elif not v and start is not None:
                if start > 0 and k < cw and k - start > best:       # must begin AND end inside the picture
                    best, bs = k - start, (start, k - 1)
                start = None
        runs.append(best)
        spans.append(bs)
    best_thin = 0
    i = 0
    while i < n:
        if runs[i] >= _PL_MIN:
            j = i
            while j + 1 < n and runs[j + 1] >= _PL_MIN:
                j += 1
            if (j - i + 1 <= 3 and 14 <= i <= 33 and j + 3 < n and runs[i - 2] < _PL_MIN
                    and runs[j + 2] < _PL_MIN and runs[j + 3] < _PL_MIN):
                x0, x1 = spans[i]
                if x0 - 6 <= mx <= x1 + 6:                    # the mouse is above / on this line, not next to it
                    near = int(wm[max(0, i - 4):i, x0:x1 + 1].sum())        # letters right on top of the line
                    text = float(wm[max(0, i - 14):i, x0:x1 + 1].mean())
                    under = float(wm[j + 2:min(n, j + 8), x0:x1 + 1].mean())
                    if near >= 3 and .04 <= text <= .6 and under < .2 and max(runs[max(0, i - 14):i]) < max(_PL_MIN, runs[i] - 2):
                        best_thin = max(best_thin, max(runs[i:j + 1]))
            i = j + 1
        else:
            i += 1
    return best_thin, float(wm.mean())


def _pl_names(win, fbd):
    """Find the fan NAMES on the Fans page straight from the screen pixels (no accessibility tree needed, so it works
    while FansMetric is still 'loading'). Every fan card has a white 2-px marker under its SUBSCRIPTION tab, ~118 px long,
    starting at the card's left edge; the name is the white text 149-160 px above that marker, from 70 px into the card
    (avatar skipped; the pencil icon is grey so it is not part of the name). Returns [(l, t, r, b)] in screen pixels."""
    import numpy as np
    if fbd:
        x0, x1 = int(fbd[0]) - 8, int(fbd[1]) + 8
    else:
        x0, x1 = int(win.left + .22 * win.width), int(win.left + .70 * win.width)
    y0, y1 = int(win.top + 180), int(win.top + win.height - 8)
    im = _pb_grab((x0, y0, x1, y1))
    a = np.asarray(im.convert('RGB'), dtype=np.int16)
    wm = (a[:, :, 0] > 185) & (a[:, :, 1] > 185) & (a[:, :, 2] > 185)
    H, W = wm.shape
    long_ = []                                                # per row: [(start, length)] of white runs 100..140 px
    for y in range(H):
        row = wm[y]
        if row.sum() < 100:
            long_.append(())
            continue
        d = np.diff(np.concatenate(([0], row.astype(np.int8), [0])))
        st_, en_ = np.flatnonzero(d == 1), np.flatnonzero(d == -1)
        long_.append(tuple((int(a0), int(b0 - a0)) for a0, b0 in zip(st_, en_) if 100 <= b0 - a0 <= 140))
    names = []
    for y in range(1, H - 2):
        for (sx, ln) in long_[y]:
            if not any(abs(sx - s2) <= 2 for s2, _ in long_[y + 1]):
                continue                                      # the marker is 2 rows thick
            if any(abs(sx - s2) <= 2 for s2, _ in long_[y - 1]) or any(abs(sx - s2) <= 2 for s2, _ in long_[y + 2]):
                continue                                      # not 3+ rows (bars)
            if not wm[max(0, y - 22):max(0, y - 9), sx:sx + ln].any():
                continue                                      # 'SUBSCRIPTION' text sits right above the marker
            ty0, ty1 = y - 165, y - 141
            if ty0 < 0:
                continue                                      # name scrolled away above
            z = wm[ty0:ty1, sx + 70:min(W, sx + 310)]
            cols = np.flatnonzero(z.any(axis=0))
            if not len(cols):
                continue
            end = cols[0]
            for c in cols[1:]:                                # letters + spaces of the name; stop at a big gap
                if c - end > 30:
                    break
                end = c
            rows = np.flatnonzero(z[:, cols[0]:end + 1].any(axis=1))
            if y0 + ty0 + int(rows.min()) < win.top + 250:
                continue                                      # under the USERS / POSTS header: not a visible name
            names.append((x0 + sx + 70 + int(cols[0]), y0 + ty0 + int(rows.min()), x0 + sx + 70 + int(end), y0 + ty0 + int(rows.max())))
    return names


def _pl_tooltip(pos):
    """FansMetric's own grey name tooltip (colour 138,150,163) that pops up right ABOVE the name the mouse is on.
    Returns its box (screen pixels) or None. It is a solid block ~20+ px wide and 16-30 px tall."""
    import numpy as np
    x0, y0 = pos[0] - 170, pos[1] - 64
    im = _pb_grab((x0, y0, pos[0] + 170, pos[1] + 4))
    a = np.asarray(im.convert('RGB'), dtype=np.int16)
    m = (np.abs(a[:, :, 0] - 138) <= 8) & (np.abs(a[:, :, 1] - 150) <= 8) & (np.abs(a[:, :, 2] - 163) <= 8)
    rows = []
    for y in range(m.shape[0]):
        d = np.diff(np.concatenate(([0], m[y].astype(np.int8), [0])))
        st_, en_ = np.flatnonzero(d == 1), np.flatnonzero(d == -1)
        best = max(((int(b - a_), int(a_), int(b)) for a_, b in zip(st_, en_)), default=(0, 0, 0))
        rows.append(best)
    y = 0
    H = len(rows)
    while y < H:
        if rows[y][0] >= 8:                                   # a row of the box (edges of letters split it - 8 px is enough)
            j = y
            while j + 1 < H and rows[j + 1][0] >= 8:
                j += 1
            h = j - y + 1
            if 14 <= h <= 34:
                xs0 = min(r[1] for r in rows[y:j + 1]); xs1 = max(r[2] for r in rows[y:j + 1])
                fill = float(m[y:j + 1, xs0:xs1].mean()) if xs1 > xs0 else 0.0
                if xs1 - xs0 >= 22 and fill >= .55 and xs0 - 60 <= 170 <= xs1 + 60:   # roughly above the mouse
                    return (x0 + xs0, y0 + y, x0 + xs1, y0 + j)
            y = j + 1
        else:
            y += 1
    return None


_pl_btn_cache = {'pos': None, 't': 0.0, 'v': None}


def _pl_button_at(pos):
    """Name of the FansMetric button under the mouse (None = not a button). Asked only while a grey tooltip is up,
    and remembered for 1.5 s at the same spot, so it costs nothing while you just move around."""
    c = _pl_btn_cache
    now = time.monotonic()
    if c['pos'] and abs(c['pos'][0] - pos[0]) <= 6 and abs(c['pos'][1] - pos[1]) <= 6 and now - c['t'] < 1.5:
        return c['v']
    v = _uia_call(lambda rd: rd.button_at(pos[0], pos[1]), timeout=0.5)
    c.update(pos=pos, t=now, v=v)
    return v


def _pl_worker():
    time.sleep(3)
    _pb_log('Loading hint: watcher started')
    probe_t = 0.0
    win, win_at, last_pos, still_since = None, 0.0, None, 0.0
    on, off_since, last_diag, last_state = False, 0.0, 0.0, None
    names, names_t, sum_t = [], 0.0, 0.0
    while not _pl['stop']:
        time.sleep(0.09)
        try:
            now = time.monotonic()
            why = ''
            want = False
            pos = _cursor_pos()
            if not poke_badges_enabled or poke_in_progress or now < _pb.get('quiet_until', 0.0):
                why = 'badges off / busy'
            else:
                if win is None or now - win_at > 3.0:
                    win = find_fansmetric_window(); win_at = now
                if win is None or getattr(win, 'isMinimized', False):
                    win = None; why = 'no FansMetric window'
                elif pos is None or not _pb_hover_ok(win, pos):
                    why = 'FansMetric not in front'
                elif not (win.left + .12 * win.width <= pos[0] <= win.left + .70 * win.width
                          and win.top + 240 <= pos[1] <= win.top + .90 * win.height):
                    why = 'mouse outside the fans area'
                else:
                    fbd = None                                    # the names are found from the screen itself; the remembered
                                                                  # fans column can be stale (chat page 'Fans' chip) - not used
                    if last_pos is None or abs(pos[0] - last_pos[0]) > 8 or abs(pos[1] - last_pos[1]) > 8:
                        last_pos, still_since = pos, now          # tiny hand jitter (a few px) does not count as moving
                    if why:
                        pass
                    elif now - still_since < 0.18:
                        why = 'mouse still moving'
                    else:
                        try:
                            if now - names_t > 0.25:              # card layout from the screen (cheap, ~4x a second)
                                names_t = now
                                names = _pl_names(win, fbd)
                            hit = [b for b in names if b[0] - 4 <= pos[0] <= b[2] + 4 and b[1] - 4 <= pos[1] <= b[3] + 5]
                            tip = _pl_tooltip(pos)                # 1st sign: FansMetric's grey name tooltip popped up above
                            btn = _pl_button_at(pos) if tip else None
                            if btn:                               # a BUTTON's tooltip ("More" on the chat's 3 dots), not a name
                                tip = None
                                hit = []
                                why = 'button tooltip, not a name (%s)' % btn
                            if btn:
                                pass
                            elif tip:
                                want = True
                                why = 'name tooltip above the mouse %s' % (tip,)
                            elif hit:
                                want = True
                                why = 'mouse on a fan name %s' % (hit[0],)
                            else:
                                run, white = _pl_underline(pos)   # backup: FansMetric underlines the hovered name
                                want = run >= _PL_MIN and white < .6
                                why = ('underline run=%d' % run) if want else ('not on a name (%d names on screen)' % len(names))
                            if now - probe_t > 6.0 and not want:  # what PokeFlow sees, for diagnosis
                                probe_t = now
                                try:
                                    from PIL import ImageDraw
                                    bx = (int(win.left + .22 * win.width), int(win.top + 180), int(win.left + .70 * win.width), int(win.top + win.height - 8))
                                    pim = _pb_grab(bx).convert('RGB')
                                    dr = ImageDraw.Draw(pim)
                                    for b in names:
                                        dr.rectangle((b[0] - bx[0], b[1] - bx[1], b[2] - bx[0], b[3] - bx[1]), outline=(0, 255, 0))
                                    dr.ellipse((pos[0] - bx[0] - 4, pos[1] - bx[1] - 4, pos[0] - bx[0] + 4, pos[1] - bx[1] + 4), outline=(255, 0, 0), width=2)
                                    pim.save(str(_PB_LOG.with_name('loading_probe.png')))
                                except Exception:
                                    pass
                        except Exception as e:
                            want = False
                            why = 'screen check failed (%r)' % (e,)
            if want:
                off_since = now                                   # last moment the name was seen under the mouse
                on_now = True
            else:
                on_now = bool(on and now - off_since < 0.25 and why.startswith('not on a name'))   # absorbs one-frame flicker
            reason = why.split(' (')[0].split(' run=')[0].split(' %s' % '(')[0]
            state = (on_now, reason)
            if state != last_state and reason != 'mouse still moving':   # every change of decision / reason is written down
                last_state = state
                _pb_log('Loading hint: %s (%s) mouse=%s' % ('ON' if on_now else 'off', why, pos))
            if on_now:
                root.after(0, _pl_decide, pos)                  # main thread: show it unless a badge is really visible
            elif on_now != on:
                root.after(0, _pl_off)
            on = on_now
        except Exception as e:
            try: _pb_log('Loading hint worker error: %r' % (e,))
            except Exception: pass
            time.sleep(1.0)



# ---- background chat watcher: "already sent this to him" warning while you type + spend alert ----
SPEND_ALERTS = True
now_m = time.monotonic
_dw = {'thread': None, 'warned': set(), 'override': (None, 0.0), 'last': None}


def _dup_norm(t):
    return ' '.join(re.sub(r'[^a-z0-9 ]+', ' ', str(t or '').lower()).split())


def _dup_match(text, messages, typing=False):
    """The message of YOURS in this chat that `text` repeats, or None. Same words = match (case / punctuation / emoji
    ignored). typing=True: also while you are still typing/pasting it - the box already holds the first 4+ words
    (20+ letters) of one of your sent messages."""
    import difflib
    a = _dup_norm(text)
    if len(a) < 10:
        return None
    for m in messages or []:
        if m.get('side') != 'me':
            continue
        b = _dup_norm(m.get('text'))
        if not b:
            continue
        if a == b:
            return m.get('text')
        if typing and len(a) >= 20 and len(a.split()) >= 4 and b.startswith(a):
            return m.get('text')
        if len(a) >= 12 and abs(len(a) - len(b)) <= 0.15 * len(a) and difflib.SequenceMatcher(None, a, b).ratio() >= 0.92:
            return m.get('text')
    return None


def _sent_before(text, messages):
    """True when `text` (typed in the box) is already one of YOUR messages in this chat (same words, ignoring case/emoji)."""
    return _dup_match(text, messages) is not None


def _dup_chat_for_box(data, rect):
    """The chat (of the last read) whose message box is the focused one."""
    chats = (data or {}).get('chats') or []
    if rect:
        cx, cy = (rect[0] + rect[2]) // 2, (rect[1] + rect[3]) // 2
        for c in chats:
            b = c.get('composer')
            if b and b[0] - 6 <= cx <= b[2] + 6 and b[1] - 6 <= cy <= b[3] + 6:
                return c
    return chats[0] if len(chats) == 1 else None


def _dup_warn(chat, text, hit):
    key = (chat.get('id') or chat.get('name') or '', _dup_norm(hit))
    if key in _dw['warned']:
        return False
    _dw['warned'].add(key)
    who = chat.get('name') or ''
    _pb_log(f'Duplicate warning: already sent to {who!r}: {str(hit)[:60]!r}')
    try:
        nm = clean_first_name(who)
    except Exception:
        nm = ''
    root.after(0, _pop_info, f"Already sent to {nm or 'him'}",
               'This message is already in his chat - change it.', 9.0)
    return True


def _dup_check_now(win, text, box_rect=None):
    """Full read of the open chat: is `text` already one of my messages? Returns (dup, fan name)."""
    chat, _why = _ctrlq_uia(win)
    if not chat:
        return False, ''
    return _sent_before(text, chat.get('messages')), chat.get('name') or ''


def _dup_watch_worker():
    """One reader thread: the open chat (+ Fan Info) is read every ~1.5 s and kept; the message box is checked every 0.15 s
    against YOUR messages of that chat, so the warning comes while you type / right after you paste."""
    time.sleep(4)
    try:
        import uiautomation as auto
        import uia_reader as _ur
    except Exception:
        return
    with auto.UIAutomationInitializerInThread():
        rd = _ur.UiaReader()
        last_text, data, data_at, last_box = None, None, 0.0, None

        def read_now(win):
            nonlocal data, data_at
            t0 = now_m()
            d = rd.read_chat(int(getattr(win, '_hWnd', 0)))
            data, data_at = d, now_m()
            took = data_at - t0
            _sw['next'] = data_at + max(1.5, 3 * took)       # a slow PC reads less often
            c = _sw_pick_chat(d)
            if c:
                ck = c.get('id') or ('name:' + (c.get('name') or ''))
                if SPEND_ALERTS:
                    _sw_feed(ck, c.get('name'), d.get('stats'))
            return d

        while not _pb.get('stop'):
            time.sleep(0.15)
            try:
                if poke_in_progress or send_in_progress:
                    continue
                win = find_fansmetric_window_cached()
                if win is None or not _pb_foreground_is(win):
                    continue
                if now_m() >= _sw['next'] and not _uia.get('busy'):
                    try:
                        read_now(win)
                    except Exception as exc:
                        _sw['next'] = now_m() + 5.0
                        _pb_log(f'Chat watch read failed: {exc!r}'[:160])
                text, rect = rd.focused_composer_text()
                if text is None or text == last_text:
                    continue
                was_empty = not last_text
                last_text = text
                if not text:
                    _dw['warned'].clear()                       # box emptied: next paste of a used message warns again
                    continue
                chat = _dup_chat_for_box(data, rect)               # 1st: the chat as last read -> instant warning
                hit = _dup_match(text, chat.get('messages'), typing=True) if chat else None
                if hit:
                    _dup_warn(chat, text, hit)
                    continue
                if was_empty and now_m() - data_at > 0.8:       # nothing yet and you just started: re-read, check again
                    try:
                        read_now(win)
                    except Exception:
                        pass
                chat = _dup_chat_for_box(data, rect)
                if not chat:
                    continue
                hit = _dup_match(text, chat.get('messages'), typing=True)
                if hit:
                    _dup_warn(chat, text, hit)
            except Exception:
                time.sleep(1.0)


# ---- "he spent money" alert: every fan you open, his Fan Info (Platform-Wide Total Spent + Last Spend) is saved;
#      next time you open him and it moved, a pop-up says he spent and when ----
_sw = {'data': None, 'cur': None, 'since': 0.0, 'prev_sig': None, 'last_sig': None, 'done': None, 'next': 0.0}
SPEND_WATCH_PATH = POKE_HISTORY_PATH.parent / 'spend_watch.json'


def _sw_load():
    if _sw['data'] is None:
        try:
            _sw['data'] = json.loads(SPEND_WATCH_PATH.read_text(encoding='utf-8')).get('fans', {})
        except Exception:
            _sw['data'] = {}
    return _sw['data']


def _sw_save():
    try:
        SPEND_WATCH_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = SPEND_WATCH_PATH.with_suffix('.tmp')
        tmp.write_text(json.dumps({'version': 1, 'fans': _sw['data'] or {}}, ensure_ascii=False, indent=1), encoding='utf-8')
        os.replace(tmp, SPEND_WATCH_PATH)
    except Exception as exc:
        _pb_log(f'Spend watch: could not save ({exc!r})')


def _sw_record(stats, now=None):
    """Fan Info numbers -> what we keep: platform total, this-model total, last spend amount and its (rough) time."""
    import uia_reader as _ur
    now = time.time() if now is None else now
    ls = _ur.parse_last_spend(stats.get('last_spend'))
    rec = {'seen': now, 'raw': str(stats.get('last_spend') or '')[:60]}
    if stats.get('platform_total') is not None:
        rec['ptotal'] = float(stats['platform_total'])
    if stats.get('total') is not None:
        rec['mtotal'] = float(stats['total'])
    if ls['amount'] is not None:
        rec['amt'] = ls['amount']
    if ls['ago'] is not None:
        rec['at'], rec['res'] = now - ls['ago'], ls['res']
    return rec


def _sw_changed(old, new):
    """Did he spend since `old`? Platform total going up is the sure sign; without it, a newer last-spend time / new amount."""
    if old.get('ptotal') is not None and new.get('ptotal') is not None:
        return new['ptotal'] > old['ptotal'] + 0.009
    if old.get('mtotal') is not None and new.get('mtotal') is not None and new['mtotal'] > old['mtotal'] + 0.009:
        return True
    if new.get('at') is None:
        return False
    if old.get('at') is None:
        return new.get('amt') is not None and old.get('amt') is None and old.get('raw', '') != new.get('raw', '')
    tol = max(old.get('res') or 60, new.get('res') or 60) + 120
    return new['at'] > old['at'] + tol


def _sw_when(rec, now=None):
    """'2 hours ago (around 15:20)' from the saved last spend."""
    import datetime as _dt
    raw = rec.get('raw', '')
    m = re.search(r'\(([^)]*ago[^)]*)\)', raw) or re.search(r'([a-z0-9 ]+ ago)', raw.lower())
    ago = m.group(1).strip() if m else ''
    if rec.get('at') is None:
        return ago
    t = _dt.datetime.fromtimestamp(rec['at'])
    res = rec.get('res') or 60
    if res <= 3600:
        when = '~' + t.strftime('%H:%M')
    elif res <= 86400:
        when = '~' + t.strftime('%b %d').replace(' 0', ' ')
    else:
        return ago
    return f'{ago} ({when})' if ago else when


def _sw_alert(name, old, new):
    """Short and readable: 'Justin spent $28' / '27 minutes ago'."""
    nm = ''
    try:
        nm = clean_first_name(name)
    except Exception:
        pass
    nm = nm or 'Your fan'
    amt = new.get('amt')
    if amt is None and old.get('ptotal') is not None and new.get('ptotal') is not None:
        amt = new['ptotal'] - old['ptotal']
    money = '' if amt is None else ('$%d' % round(amt) if abs(amt - round(amt)) < 0.005 else '$%.2f' % amt)
    title = f'{nm} spent {money}' if money else f'{nm} spent money'
    m = re.search(r'([a-z0-9 ]+ ago)', str(new.get('raw') or '').lower())
    ago = m.group(1).strip() if m else 'just now'
    _pb_log(f'Spend alert: {name!r} {old.get("raw")!r} -> {new.get("raw")!r} ptotal {old.get("ptotal")} -> {new.get("ptotal")}')
    sub = f'{ago}  \u2022  platform-wide, on any creator'
    root.after(0, lambda: _pop_info(title, sub, 14.0, kind='spend'))


def _sw_sig(stats):
    return tuple(stats.get(k) for k in ('platform_total', 'total', 'messages', 'tips', 'subscribed', 'last_spend'))


def _sw_feed(chat_key, name, stats, now=None):
    """Called with every read of the open chat. Waits until his Fan Info is really his (FansMetric shows the previous fan's
    panel for a moment after switching), then compares with what was saved and saves the new numbers."""
    now = time.monotonic() if now is None else now
    if not chat_key:
        return
    if chat_key != _sw['cur']:
        _sw['prev_sig'] = _sw['last_sig'] if _sw['cur'] else None
        _sw['cur'], _sw['since'], _sw['last_sig'], _sw['done'] = chat_key, now, None, None
        _sw['stable'] = 0
        return
    if not stats or (stats.get('last_spend') is None and stats.get('platform_total') is None and stats.get('total') is None):
        return
    sig = _sw_sig(stats)
    _sw['stable'] = _sw.get('stable', 0) + 1 if sig == _sw['last_sig'] else 0
    _sw['last_sig'] = sig
    if _sw['stable'] < 1:                                          # same numbers on 2 reads in a row
        return
    if _sw['done'] == chat_key:                                    # still in his chat: live - did the numbers just change?
        if sig == _sw.get('done_sig'):
            return
        _sw['done_sig'] = sig
        new = _sw_record(stats)
        data = _sw_load()
        old = data.get(chat_key) or {}
        new['name'] = str(name or '')[:80]
        if old and _sw_changed(old, new):
            _sw_alert(name, old, new)
        elif new.get('at') is None and old.get('at') is not None:
            new['at'], new['res'] = old['at'], old.get('res')
        data[chat_key] = new
        _sw_save()
        return
    if sig == _sw['prev_sig'] and now - _sw['since'] < 6.0:          # still the previous fan's panel? give it time
        return
    _sw['done'], _sw['done_sig'] = chat_key, sig
    new = _sw_record(stats)
    data = _sw_load()
    old = data.get(chat_key)
    new['name'] = str(name or '')[:80]
    if old and _sw_changed(old, new):
        _sw_alert(name, old, new)
    elif old and new.get('at') is None and old.get('at') is not None:
        new['at'], new['res'] = old['at'], old.get('res')         # keep the time we knew
    data[chat_key] = new
    _sw_save()


def _sw_pick_chat(data):
    chats = data.get('chats') or []
    if not chats:
        return None
    if len(chats) == 1:
        return chats[0]
    ref = data.get('focus')
    if not ref:
        return None
    for c in chats:
        l, t, r, b = c['title']
        cr = c['composer'] or c['title']
        if min(l, cr[0]) - 10 <= ref[0] <= max(r, cr[2]) + 10:
            return c
    return None


# ======================= AUTOWELCOME: welcome message to every new subscriber =======================
# Reads FansMetric's NOTIFICATIONS panel. A new "subscribed to your profile!" card (not answered yet, max 15 minutes old)
# gets your welcome message typed into ITS OWN "Send a quick reply..." box - no mouse, no keyboard, your chat is not
# touched - then after 3 seconds its Send button is pressed. "Reply sent by ..." on the card confirms it.
_aw = {'thread': None, 'sent': None, 'tries': {}, 'scrolls': {}, 'scrolled': False, 'status': 'off', 'today': 0, 'day': None, 'last': None, 'cancel': False}
AW_MAX_AGE = 15 * 60
AW_WAIT = 3.0
AW_IDLE = 0.6           # how long you must pause typing before PokeFlow fills a box / presses Send
AW_GAP = 3.2            # seconds between two sends (OnlyFans allows one every 3 s) - counts YOUR Enter presses too
AW_PENDING = 45          # after an unconfirmed Send: seconds to watch his card before ever pressing again
AW_LOG_PATH = POKE_HISTORY_PATH.parent / 'autowelcome_sent.json'


def _aw_load():
    if _aw['sent'] is None:
        try:
            d = json.loads(AW_LOG_PATH.read_text(encoding='utf-8'))
            _aw['sent'] = dict(d.get('sent') or {})
        except Exception:
            _aw['sent'] = {}
    return _aw['sent']


def _aw_mark(fan_id, name, ok):
    sent = _aw_load()
    sent[fan_id] = {'at': _now_iso(), 'name': str(name or '')[:80], 'ok': bool(ok)}
    if len(sent) > 3000:
        for k in sorted(sent, key=lambda k: sent[k].get('at') or '')[:500]:
            sent.pop(k, None)
    try:
        AW_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = AW_LOG_PATH.with_suffix('.tmp')
        tmp.write_text(json.dumps({'version': 1, 'sent': sent}, ensure_ascii=False, indent=1), encoding='utf-8')
        os.replace(tmp, AW_LOG_PATH)
    except Exception as exc:
        _pb_log(f'Autowelcome: could not save the log ({exc!r})')


def _aw_first(name):
    """His first REAL name: 'big Mike' -> 'Mike', 'Mr. James Cole' -> 'James', 'Your daddy' -> '' (no real name)."""
    words = str(name or '').replace('.', ' ').split()
    while words:
        try:
            f = clean_first_name(' '.join(words))
        except Exception:
            f = ''
        if f and f.lower() not in _GENERIC_FAN_NAMES:
            return f
        words = words[1:]
    return ''


def _aw_text(name):
    """The welcome message with {name} filled in (his first name, 'babe' when he has no real one)."""
    first = _aw_first(name)
    if not first or re.fullmatch(r'u\d+', (name or '').strip(), re.I):
        first = 'babe'
    msg = (autowelcome_msg or '').strip()
    return re.sub(r'\{\s*name\s*\}', first, msg, flags=re.I)


def _aw_set_status(text):
    if text != _aw.get('status'):
        _pb_log(f'Autowelcome status: {text}')
    _aw['status'] = text
    try:
        root.after(0, _aw_status_draw)
    except Exception:
        pass


def _aw_norm(t):
    return ' '.join(str(t or '').split())


def _aw_loose(t):
    """Same text the way a person reads it: … = ..., curly quotes = straight, invisible emoji/zero-width marks dropped."""
    import unicodedata
    t = unicodedata.normalize('NFKC', str(t or ''))
    t = t.translate({0x2018: "'", 0x2019: "'", 0x201C: '"', 0x201D: '"', 0x00A0: ' '})
    t = ''.join(ch for ch in t if ch not in '\ufe0f\ufe0e\u200b\u200c\u200d\u2060')
    return ' '.join(t.split()).casefold()


def _aw_same(box_value, text):
    """Does his box hold our welcome? Exact, or the same once special characters are evened out."""
    if box_value is None:
        return False
    if _aw_norm(box_value) == text:
        return True
    a, b = _aw_loose(box_value), _aw_loose(text)
    if a == b:
        return True
    if a and b:
        n = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), min(len(a), len(b)))
        _pb_log(f'Autowelcome: box text differs from the welcome at char {n} (box {len(a)} / welcome {len(b)} chars): '
                f'box {a[max(0, n - 12):n + 12]!r} vs welcome {b[max(0, n - 12):n + 12]!r}')
    return False


def _aw_candidates(cards):
    """Subs to welcome now. Every sub card that is NOT taken says why in badges_debug.txt (once per fan and reason)."""
    sent = _aw_load()
    out = []
    seen = _aw.setdefault('why', set())
    def skip(c, why):
        key = (c['id'], why)
        if key not in seen:
            seen.add(key)
            _pb_log(f"Autowelcome: {c.get('name') or c['id']!r} ({c['id']}) skipped - {why}")
    pend = _aw.setdefault('pending', {})
    for c in cards or []:
        if not c.get('sub'):
            continue
        if c['id'] in sent:
            continue                                                    # done (or cancelled) before - silent
        p_ = pend.get(c['id'])
        if p_ is not None and time.monotonic() - p_[0] < AW_PENDING and not c.get('replied'):
            continue                                                    # Send pressed, waiting for the card to say so
        if c.get('replied'):
            skip(c, 'already answered on the card ("Reply sent by ...")'); continue
        if (c.get('edit') is None or c.get('send') is None) and not c.get('replied') \
                and c['id'] not in _aw.setdefault('nobox', set()) and c.get('ago') is not None and c['ago'] <= AW_MAX_AGE:
            r_ = _aw.get('rect_now')
            on_screen = not r_ or r_[1] + 40 <= c['top'] <= r_[3] - 120
            cnt = _aw.setdefault('nobox_seen', {})
            cnt[c['id']] = cnt.get(c['id'], 0) + 1 if on_screen else cnt.get(c['id'], 0)
            if on_screen and cnt[c['id']] >= 4:                          # visible for ~4 s and STILL no reply box
                _aw['nobox'].add(c['id'])
                nm_ = (c.get('name') or 'him').strip()                    # pop-ups: his full display name
                _pb_log(f"Autowelcome: {c.get('name')!r} has no quick reply box even when visible - FansMetric does not "
                        f"offer it for him; told you to welcome him yourself")
                root.after(0, lambda nm_=nm_, a_=c.get('account'): _pop_show_toast('welcome', f"Can't quick-reply {nm_}",
                                                             'No reply box on his card - welcome him yourself', [], life=12.0, acct=a_))
        if c.get('edit') is None or c.get('send') is None:
            skip(c, f"no quick reply box / Send button on the card (edit={c.get('edit') is not None}, send={c.get('send') is not None}, "
                    f"asked by position={bool(c.get('by_point'))}, searched the card={c.get('ago_el') is not None}) card has: {c.get('dump', '')}"); continue
        if _aw['tries'].get(c['id'], 0) >= 3:
            continue
        if c.get('ago') is None:
            skip(c, 'no "... ago" time on the card'); continue
        if c['ago'] > AW_MAX_AGE:
            skip(c, f"older than {AW_MAX_AGE // 60} minutes ({c['ago'] // 60} min)"); continue
        out.append(c)
    return sorted(out, key=lambda c: -(c.get('ago') or 0))             # oldest first


def _aw_hidden_subs(cards, rect):
    """New, unanswered subs (< 15 min, not done) whose card has no reply box because it is outside the visible part
    of the NOTIFICATIONS panel - FansMetric only builds the box for cards on screen. Oldest first, max 3 scrolls each."""
    sent = _aw_load()
    out = []
    for c in cards or []:
        if not c.get('sub') or c.get('replied') or c['id'] in sent or c.get('id_el') is None:
            continue
        if c.get('edit') is not None and c.get('send') is not None:
            continue
        if c.get('ago') is None or c['ago'] > AW_MAX_AGE or _aw['scrolls'].get(c['id'], 0) >= 1:
            continue
        if rect and rect[1] + 40 <= c['top'] <= rect[3] - 120:
            continue                                                    # already on screen: scrolling won't help
        out.append(c)
    return sorted(out, key=lambda c: -(c.get('ago') or 0))


_kb = {'last': 0.0, 'active': False, 'thread': None}


def _kb_hook_thread():
    """Notes the time of every key you press (only the time - not which key). Mouse movement is ignored."""
    try:
        import ctypes.wintypes as wt
        u, k = ctypes.windll.user32, ctypes.windll.kernel32
        LRESULT = ctypes.c_ssize_t
        HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wt.WPARAM, wt.LPARAM)
        u.CallNextHookEx.argtypes = [ctypes.c_void_p, ctypes.c_int, wt.WPARAM, wt.LPARAM]
        u.CallNextHookEx.restype = LRESULT
        u.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, ctypes.c_void_p, wt.DWORD]
        u.SetWindowsHookExW.restype = ctypes.c_void_p
        def proc(n, w, l):
            if n >= 0 and w in (0x100, 0x104):                     # WM_KEYDOWN / WM_SYSKEYDOWN
                _kb['last'] = time.monotonic()
                try:
                    if ctypes.cast(l, ctypes.POINTER(ctypes.c_ulong))[0] == 0x0D and not (u.GetAsyncKeyState(0x10) & 0x8000):
                        _kb['enter'] = time.monotonic()            # you pressed Enter = you probably SENT a message
                except Exception:
                    pass
            return u.CallNextHookEx(None, n, w, l)
        cb = HOOKPROC(proc)
        _kb['cb'] = cb
        h = u.SetWindowsHookExW(13, cb, k.GetModuleHandleW(None), 0)   # WH_KEYBOARD_LL
        if not h:
            return
        _kb['active'] = True
        msg = wt.MSG()
        while u.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            u.TranslateMessage(ctypes.byref(msg)); u.DispatchMessageW(ctypes.byref(msg))
    except Exception:
        _kb['active'] = False


def _kb_start():
    if _kb['thread'] is None:
        _kb['thread'] = threading.Thread(target=_kb_hook_thread, daemon=True, name='PokeFlow-KeyWatch')
        _kb['thread'].start()


def _aw_user_idle(seconds=1.5):
    """True when you have not TYPED for `seconds` (mouse movement does not count - only typing can land in the wrong
    box). Without the key watcher it falls back to Windows' 'last input' (mouse + keyboard)."""
    if _kb.get('active'):
        return time.monotonic() - _kb['last'] >= seconds
    try:
        class LII(ctypes.Structure):
            _fields_ = [('cbSize', ctypes.c_uint), ('dwTime', ctypes.c_uint)]
        lii = LII(); lii.cbSize = ctypes.sizeof(LII)
        if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(lii)):
            return False
        return (ctypes.windll.kernel32.GetTickCount() - lii.dwTime) / 1000.0 >= seconds
    except Exception:
        return False


def _aw_guarded(rd, action, what='', wait_idle=True):
    """Runs one Autowelcome step on FansMetric (fill the box / press Send / close the 3-s box) WITHOUT taking your cursor:
    1) waits until you have not typed or clicked for 1.5 s (max ~30 s), 2) remembers exactly where your cursor is,
    3) does the step, 4) puts the cursor back if FansMetric moved it. Returns (done, result)."""
    if wait_idle:
        t0 = time.monotonic()
        told = False
        while not _aw_user_idle(AW_IDLE):                             # a short pause in your typing is enough: the
            if time.monotonic() - t0 > 30:                            # cursor guard below puts your cursor back anyway
                _pb_log(f'Autowelcome: you kept typing for 30 s - {what} postponed')
                return False, None
            if not told and time.monotonic() - t0 > 3:
                told = True
                _pb_log(f'Autowelcome: waiting for a short pause in your typing ({what})')
                _aw['waiting_typing'] = True
                try: root.after(0, lambda: _pop_info('Welcome is waiting', 'Pause typing for a moment - it fills / sends then', 5.0, kind='welcome'))
                except Exception: pass
            time.sleep(0.05)
        _aw['waiting_typing'] = False
    prev = prev_rt = None
    try:
        prev = rd._iuia().GetFocusedElement()
        prev_rt = tuple(prev.GetRuntimeId() or ())
    except Exception:
        prev = None
    try:
        fg = ctypes.windll.user32.GetForegroundWindow()
    except Exception:
        fg = None
    result = action()
    if prev is not None:
        for _ in range(3):                                            # FansMetric may move the cursor a moment later
            time.sleep(0.05)
            try:
                now = rd._iuia().GetFocusedElement()
                moved = tuple(now.GetRuntimeId() or ()) != prev_rt
            except Exception:
                moved = False
            if moved:
                try:
                    prev.SetFocus()
                    if fg:
                        ctypes.windll.user32.SetForegroundWindow(fg)
                    _pb_log(f'Autowelcome: FansMetric moved your cursor ({what}) - put it back')
                except Exception as exc:
                    _pb_log(f'Autowelcome: could not put your cursor back: {exc!r}'[:140])
    return True, result


def _aw_last_send():
    """When the last message went out: PokeFlow's own sends or your Enter key (whichever was later)."""
    return max(_last_msg_sent[0], _kb.get('enter', 0.0) if isinstance(_kb, dict) else 0.0)


def _aw_count_sent(nm):
    today = time.strftime('%Y-%m-%d')
    if _aw['day'] != today:
        _aw['day'], _aw['today'] = today, 0
    _aw['today'] += 1
    _aw['last'] = (nm, time.strftime('%H:%M'))


def _aw_close_block(rd, hwnd, blocked=None):
    """Close FansMetric's 'Please allow 3 seconds.' box and make sure it is really gone. True = gone."""
    for attempt in range(4):
        try:
            b = blocked if (attempt == 0 and blocked is not None) else rd.find_block(hwnd)
        except Exception:
            b = None
        if b is None:
            return True
        if b.get('close') is not None:
            try:
                _aw_guarded(rd, lambda: rd.press(b['close']), 'closing the 3-second box', wait_idle=False)
            except Exception as exc:
                _pb_log(f'Autowelcome: closing the 3-second box failed ({exc!r})'[:160])
        else:
            _pb_log('Autowelcome: 3-second box is up but its CLOSE button was not found - retrying')
        time.sleep(0.35)
    try:
        return rd.find_block(hwnd) is None
    except Exception:
        return False


def _aw_chat_back(rd, hwnd):
    """Press <- until the panel is back on the NOTIFICATIONS list (from his chat FansMetric can go to his profile first,
    so it may take 2 presses). Never presses <- on the Notifications page itself. True when back."""
    def on_notifications(url):
        return '/my/notifications' in (url or '')
    for _ in range(4):
        try:
            doc, url = rd.panel_doc(hwnd)
            if doc is None:
                return False
            if on_notifications(url):
                return True
            pc = rd.panel_chat(doc)
        except Exception:
            time.sleep(0.4)                               # page still swapping
            continue
        if pc.get('back') is None:
            _pb_log(f'Autowelcome: back arrow not found (page {url!r:.60}). PANEL: {pc.get("dump")}'[:1700])
            return False
        before = url
        _aw_guarded(rd, lambda: rd.press(pc['back']), 'going back to notifications', wait_idle=False)
        for _k in range(12):                              # wait until the page changed
            time.sleep(0.25)
            try:
                doc, url = rd.panel_doc(hwnd)
            except Exception:
                continue
            if doc is not None and url and url != before:
                break
    try:
        return on_notifications(rd.panel_doc(hwnd)[1])
    except Exception:
        return False


def _aw_chat_fallback(rd, hwnd, card, text, name, nm, holder=None):
    """After a '3 seconds' block: the card's little message icon opens HIS chat inside the Notifications panel ->
    welcome goes in there -> Send -> <- arrow back. No mouse, no keyboard; your own chat is never touched.
    Returns 'sent' | 'already' (the welcome is already in his chat) | a reason it could not."""
    chat = card.get('chat')
    if chat is None:
        return 'no message icon on his card'
    try:
        v = rd.value_of(chat) or ''
        if v and '/my/chats/chat/' not in v:
            return 'icon is not a chat link'
    except Exception:
        pass
    def toast(sub):
        def f():
            t = (holder or {}).get('t')
            if t is not None:
                _pop_close_toast(t)
            if holder is not None:
                holder['t'] = _pop_show_toast('welcome', f'Welcoming {nm} in his chat', sub, [], life=10.0, hwnd=hwnd)
        try: root.after(0, f)
        except Exception: pass
    toast('the 3-second box blocked it - sending it in his chat')
    done, _r = _aw_guarded(rd, lambda: rd.press(chat), 'opening his chat')
    if not done:
        return 'you were typing'
    pc, doc = None, None
    end = time.monotonic() + 8.0
    while time.monotonic() < end:
        time.sleep(0.3)
        try:
            doc, url = rd.panel_doc(hwnd)
            if doc is None or '/my/chats/chat/' not in (url or ''):
                continue
            pc = rd.panel_chat(doc)
        except Exception:
            pc = None                                     # FansMetric is still swapping the page: just look again
            continue
        if pc.get('edit') is not None and pc.get('texts'):
            break
    if pc is None or pc.get('edit') is None:
        _pb_log(f'Autowelcome: his chat did not open / no message box. PANEL: {(pc or {}).get("dump")}'[:1700])
        _aw_chat_back(rd, hwnd)
        return 'his chat did not open'
    key = _aw_norm(text).casefold()[:40]
    if key and any(key in ' '.join(t.split()).casefold() for t in pc['texts']):
        _pb_log(f'Autowelcome: {name!r} - the welcome is already in his chat (the blocked one went through) - not sent again')
        _aw_chat_back(rd, hwnd)
        return 'already'
    gap = 3.1 - (time.monotonic() - _aw_last_send())                 # only what OnlyFans needs - usually already over
    if gap > 0:
        time.sleep(gap)
    done, _r = _aw_guarded(rd, lambda: rd.set_value(pc['edit'], text), 'filling his chat box')
    if not done:
        _aw_chat_back(rd, hwnd)
        return 'you were typing'
    if _aw_norm(rd.value_of(pc['edit']) or '').casefold()[:40] != key:
        _pb_log(f'Autowelcome: the welcome did not go into his chat box (box={rd.value_of(pc["edit"])!r:.40}). PANEL: {pc.get("dump")}'[:1700])
        _aw_chat_back(rd, hwnd)
        return 'could not type into his chat box'
    sent = False
    for attempt in range(3):
        on = False
        for _k in range(8):                                           # the Send button switches on once text is in
            try:
                pc = rd.panel_chat(doc)
            except Exception:
                time.sleep(0.2)
                continue
            if pc.get('send') is not None and pc.get('send_on'):
                on = True
                break
            time.sleep(0.2)
        if not on:
            _pb_log(f'Autowelcome: Send in his chat stays off / not found (box={rd.value_of(pc.get("edit"))!r:.40}). '
                    f'PANEL: {pc.get("dump")}'[:1700])
            break
        done, _r = _aw_guarded(rd, lambda: rd.press(pc['send']), 'pressing Send in his chat')
        if not done:
            break
        _last_msg_sent[0] = time.monotonic()
        blocked = None
        for _k in range(16):
            time.sleep(0.25)
            try:
                blocked = rd.find_block(hwnd)
            except Exception:
                blocked = None
            if blocked is not None:
                break
            try:
                pc = rd.panel_chat(doc)
            except Exception:
                continue
            if pc.get('edit') is not None and _aw_norm(rd.value_of(pc['edit']) or '') in ('', 'type a message...', 'type a message'):
                sent = True
                break
        if sent:
            break
        if blocked is not None:
            if not _aw_close_block(rd, hwnd, blocked):
                break
            time.sleep(max(0.0, 3.1 - (time.monotonic() - _aw_last_send())))
            continue
        break
    _pb_log(f'Autowelcome: {name!r} - in his chat: ' + ('SENT' if sent else 'not confirmed'))
    back = _aw_chat_back(rd, hwnd)
    if not back:
        _pb_log('Autowelcome: could not go back to the notifications list - press the <- arrow in that panel')
    return 'sent' if sent else 'not confirmed in his chat'


def _aw_welcome(rd, hwnd, card, win=None):
    """Put the message into HIS card's quick reply box, wait 3 s (DISMISS stops it), press its Send, confirm.
    Never sends twice: once the box is empty / 'Reply sent by' shows, he is done; it is only tried again when the
    text is provably still sitting unsent in his box."""
    fid, name = card['id'], card.get('name') or card['id']
    text = _aw_norm(_aw_text(name))                                     # the quick reply box is one line
    _aw['tries'][fid] = _aw['tries'].get(fid, 0) + 1
    tries = _aw['tries'][fid]
    _aw['cancel'] = False
    def holds(el):
        return _aw_same(rd.value_of(el), text)
    ok = False
    try:
        done, _r = _aw_guarded(rd, lambda: rd.set_value(card['edit'], text), 'filling his box')
        if not done:
            _aw['tries'][fid] -= 1                                      # you were typing: not a failed try
            return False
        for _k in range(6):                                             # FansMetric shows the text a moment later
            ok = holds(card['edit'])
            if ok:
                break
            time.sleep(0.15)
    except Exception as exc:
        _pb_log(f'Autowelcome: typing into {name!r} failed: {exc!r}'[:200])
    # (No keyboard backup any more: it could paste into whatever had the cursor - your chat, your other monitor.
    #  Autowelcome never touches the keyboard or your cursor.)
    if not ok:
        _pb_log(f'Autowelcome: {name!r} - message did not go into his reply box (try {tries}): box={rd.value_of(card["edit"])!r:.60}')
        return False
    nm = (name or 'him').strip()                                       # pop-ups: his full display name ({name} = filtered)
    holder = {}
    def show():
        holder['t'] = _pop_show_toast('welcome', f'Welcoming {nm}', f'sends in {int(AW_WAIT)} seconds',
                                      [('pop_dismiss', lambda it: (_aw.__setitem__('cancel', True), _pop_close_toast(it)))], life=AW_WAIT + 4, hwnd=hwnd)
    root.after(0, show)
    def find():
        return next((c for c in (rd.notif_subs(hwnd) or []) if c['id'] == fid), None)

    def state():
        """'sent' | 'waiting' (our text still in his box) | 'gone' (card not found)"""
        c = find()
        if c is None:
            return 'gone', None
        if c.get('replied'):
            return 'sent', c
        if c.get('edit') is not None and _aw_norm(rd.value_of(c['edit'])) == '':
            return 'sent', c
        return 'waiting', c

    end = time.monotonic() + AW_WAIT
    prep = {}
    while time.monotonic() < end:
        if not prep:                                                    # checks run DURING the 3 s, not after them
            prep['done'] = True
            try:
                prep['block_before'] = rd.find_block(hwnd) is not None
            except Exception:
                prep['block_before'] = False
        if 'st' not in prep and end - time.monotonic() < 1.2:            # fresh look at his card in the last second
            prep['st'] = state()
        if _aw['cancel'] or not autowelcome_on:
            try: _aw_guarded(rd, lambda: rd.set_value(card['edit'], ''), 'emptying his box', wait_idle=False)
            except Exception: pass
            _aw_mark(fid, name, False)
            _pb_log(f'Autowelcome: {name!r} cancelled')
            _aw_set_status(f'Cancelled for {nm}')
            return True
        time.sleep(0.1)

    st, c2 = prep.get('st') or state()                                  # the panel may have moved in 3 s
    if st == 'gone':
        _pb_log(f'Autowelcome: {name!r} card not found before sending - will look again')
        return False
    if st == 'sent' and c2 is not None and c2.get('replied'):
        _aw_mark(fid, name, True)
        _pb_log(f'Autowelcome: {name!r} was answered by someone else meanwhile')
        return True
    if not holds(c2['edit']):
        try: _aw_guarded(rd, lambda: rd.set_value(c2['edit'], text), 'filling his box')
        except Exception: pass
    block_before = prep.get('block_before', False)                    # already on screen before Send: not ours
    gap = AW_GAP - (time.monotonic() - _aw_last_send())               # OnlyFans' 3-second rule: never right after ANY send
    if gap > 0:
        time.sleep(gap)
    pressed = False
    try:
        done, _r = _aw_guarded(rd, lambda: rd.press(c2['send']), 'pressing Send')
        if not done:
            _aw['tries'][fid] -= 1                                      # still typing: not sent, not a failed try
            return False
        pressed = True
        _last_msg_sent[0] = time.monotonic()
    except Exception as exc:
        _pb_log(f'Autowelcome: pressing Send for {name!r} failed: {exc!r}'[:160])
        try:                                                            # FansMetric redrew his card: fresh button, once more
            c5 = find()
            if c5 is not None and c5.get('send') is not None and c5.get('edit') is not None and holds(c5['edit']):
                done, _r = _aw_guarded(rd, lambda: rd.press(c5['send']), 'pressing Send again', wait_idle=False)
                if done:
                    pressed = True
                    _last_msg_sent[0] = time.monotonic()
                    c2 = c5
                    _pb_log(f'Autowelcome: {name!r} - Send pressed on the second try')
        except Exception as exc2:
            _pb_log(f'Autowelcome: second Send for {name!r} failed too: {exc2!r}'[:160])
    if not pressed:
        # Send was NEVER pressed: whatever his box shows now, he is NOT welcomed - try again next round (max 3 tries).
        _pb_log(f'Autowelcome: {name!r} - Send could not be pressed (try {tries}) - NOT counted as sent, will try again')
        return False
    blocked = None
    for k in range(8):                                                  # ~1.6 s: the 3-second box shows at once; a slow
        time.sleep(0.2)                                                 # 'Reply sent by' is watched in the background (pending)
        try:
            blocked = rd.find_block(hwnd) if not block_before else None  # NEW visible 3-s box = NOT sent
        except Exception:
            blocked = None
        if blocked is not None:
            break
        st, c3 = state()
        if st == 'sent':
            break
    if blocked is not None:
        closed = _aw_close_block(rd, hwnd, blocked)
        _pb_log(f'Autowelcome: {name!r} - "Please allow 3 seconds" appeared after Send. Box closed={closed}' +
                (' -> trying his chat' if closed else ' -> NOT opening his chat behind the box'))
        c4 = None
        try:
            c4 = find()
        except Exception:
            pass
        res = 'nochat' if closed else 'the 3-second box could not be closed'
        try:
            if closed:
                res = _aw_chat_fallback(rd, hwnd, (c4 or c2 or card), text, name, nm, holder)
        except Exception as exc:
            _pb_log(f'Autowelcome: chat fallback for {name!r} crashed: {exc!r}'[:200])
            try: _aw_chat_back(rd, hwnd)
            except Exception: pass
        if res in ('sent', 'already'):
            _aw_mark(fid, name, True)
            if res == 'sent':
                _aw_count_sent(nm)
            _aw_set_status('ok')
            def ok_():
                t = holder.get('t')
                if t is not None:
                    _pop_close_toast(t)
                _pop_show_toast('welcome', f'Welcomed {nm}' if res == 'sent' else f'{nm} already has the welcome',
                                'sent in his chat (after the 3-second box)' if res == 'sent' else 'it was in his chat - not sent again', [], life=6.0, hwnd=hwnd)
            root.after(0, ok_)
            return True
        _aw_mark(fid, name, False)
        _aw.setdefault('blocked', []).append((fid, name, text, time.monotonic()))
        _pb_log(f'Autowelcome: {name!r} - NOT sent: 3-second box and his chat could not be used ({res})')
        _aw_set_status('ok')
        def warn():
            t = holder.get('t')
            if t is not None:
                _pop_close_toast(t)
            _pop_show_toast('welcome', f'Welcome to {nm} was blocked', '3-second rule - send it in his chat', [], life=14.0, hwnd=hwnd)
        root.after(0, warn)
        return 'blocked'
    if st == 'waiting':
        if pressed:
            # Send WAS pressed. FansMetric in the background (other page / tab) updates the card late - the welcome
            # can already be on its way. Never press again on a guess: wait up to AW_PENDING s for 'Reply sent by'.
            _aw.setdefault('pending', {})[fid] = (time.monotonic(), name, nm)
            _aw['tries'][fid] -= 1
            _pb_log(f'Autowelcome: {name!r} - Send pressed, not confirmed yet (page in the background?) - '
                    f'watching his card up to {AW_PENDING} s before anything else')
            return 'pending'
        _pb_log(f'Autowelcome: {name!r} - NOT sent (text still in his box, pressed={pressed}, try {tries}) - will try again')
        return False
    _aw_mark(fid, name, True)                                           # sent (or card gone after pressing Send): never again
    today = time.strftime('%Y-%m-%d')
    if _aw['day'] != today:
        _aw['day'], _aw['today'] = today, 0
    _aw['today'] += 1
    _aw['last'] = (nm, time.strftime('%H:%M'))
    _pb_log(f'Autowelcome: sent to {name!r} ({fid})' + ('' if st == 'sent' else ' - card disappeared after Send, counted as sent'))
    _aw_set_status('ok')
    def done():
        t = holder.get('t')
        if t is not None:
            _pop_close_toast(t)
        _pop_show_toast('welcome', f'Welcome sent to {nm}', '', [], life=4.0, hwnd=hwnd)
    root.after(0, done)
    return True


_fmw = {'at': 0.0, 'hwnds': [], 'logged': None}


def _fansmetric_hwnds():
    """Every big, visible top-level window that belongs to the FansMetric PROGRAM (whatever its title says - a second
    account window can be titled just with the account name)."""
    out = []
    try:
        import ctypes.wintypes as wt
        u, k = ctypes.windll.user32, ctypes.windll.kernel32
        names = {}
        def exe_of(pid):
            if pid in names:
                return names[pid]
            nm = ''
            h = k.OpenProcess(0x1000, False, pid)                     # PROCESS_QUERY_LIMITED_INFORMATION
            if h:
                buf = ctypes.create_unicode_buffer(520); size = wt.DWORD(520)
                if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
                    nm = buf.value.lower()
                k.CloseHandle(h)
            names[pid] = nm
            return nm
        def cb(hwnd, _l):
            try:
                if not u.IsWindowVisible(hwnd) or u.GetWindow(hwnd, 4):     # skip hidden + owned (pop-up) windows
                    return True
                r = wt.RECT()
                u.GetWindowRect(hwnd, ctypes.byref(r))
                if r.right - r.left < 400 or r.bottom - r.top < 300:
                    return True
                pid = wt.DWORD()
                u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                exe = exe_of(pid.value)
                ln = u.GetWindowTextLengthW(hwnd)
                tb = ctypes.create_unicode_buffer(ln + 1); u.GetWindowTextW(hwnd, tb, ln + 1)
                title = tb.value.lower()
                if ('fansmetric' in exe.rsplit('\\', 1)[-1] or 'fansmetric' in title) and 'pokeflow' not in title \
                        and 'personalizer' not in title:
                    out.append(int(hwnd))
            except Exception:
                pass
            return True
        PROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        u.EnumWindows(PROC(cb), 0)
    except Exception:
        pass
    return out


def find_fansmetric_windows():
    """ALL open FansMetric windows (one per account when you run two), found by program, not by title."""
    now = time.monotonic()
    if now - _fmw['at'] > 1.0:
        _fmw['at'], _fmw['hwnds'] = now, _fansmetric_hwnds()
    wins = []
    for h in _fmw['hwnds']:
        try:
            wins.append(gw.Win32Window(h))
        except Exception:
            pass
    if not wins:                                                    # fallback: the old title search
        try:
            for w in gw.getAllWindows():
                low = (w.title or '').strip().lower()
                if 'fansmetric' in low and 'personalizer' not in low and 'pokeflow' not in low:
                    wins.append(w)
        except Exception:
            pass
    sig = tuple(sorted((int(getattr(w, '_hWnd', 0)), (w.title or '')[:40]) for w in wins))
    if sig != _fmw['logged']:
        _fmw['logged'] = sig
        try: _pb_log(f'FansMetric windows found: {len(wins)} - ' + ', '.join(f'{t!r}' for _h, t in sig))
        except Exception: pass
    return wins


def _aw_process(rd, win, wtag):
    """One FansMetric window: read its Notifications, welcome one sub if there is one.
    Returns None (Notifications not visible there), 'idle' or 'acted'."""
    hwnd = int(getattr(win, '_hWnd', 0))
    cards = rd.notif_subs(hwnd)
    if cards is None:
        return None
    acct = (cards[0].get('account') if cards else '') or wtag
    subs = tuple(sorted((c['id'], bool(c.get('replied'))) for c in cards if c.get('sub')))
    if subs != _aw.setdefault('seen_subs_w', {}).get(hwnd):
        _aw['seen_subs_w'][hwnd] = subs
        _pb_log(f"Autowelcome [{acct}]: Notifications shows {len(cards)} cards, {len(subs)} subs: " +
                ', '.join(f"{(c.get('name') or c['id'])[:18]}({'answered' if c.get('replied') else (str(c.get('ago') // 60) + 'm' if c.get('ago') is not None else '?')})"
                          for c in cards if c.get('sub'))[:400])
    for c in cards:                                      # a notification we can't read (new language?): say so once
        ln = c.get('line') or ''
        if not c.get('sub') and ln and '$' not in ln and (c['id'], 'line') not in _aw.setdefault('why', set()) \
                and not re.search(r'purchas|tip|like|comment|mention|tag|renew|message|post|stream|ppv', ln, re.I):
            _aw['why'].add((c['id'], 'line'))
            _pb_log(f"Autowelcome: notification not recognised (new language?) - {c.get('name') or c['id']!r}: {ln!r}")
    _aw['rect_now'] = getattr(rd, 'notif_rect', None)
    pend = _aw.setdefault('pending', {})
    for c in cards:                                      # an unconfirmed Send: the card now says 'Reply sent by' -> done
        p_ = pend.get(c['id'])
        if p_ is None:
            continue
        v_ = rd.value_of(c['edit']) if c.get('edit') is not None else None
        if c.get('replied') or (v_ is not None and _aw_norm(v_) == ''):
            pend.pop(c['id'], None)
            _aw_mark(c['id'], p_[1], True)
            _aw_count_sent(p_[2])
            _pb_log(f'Autowelcome: sent to {p_[1]!r} - confirmed {time.monotonic() - p_[0]:.0f} s after Send')
            _aw_set_status('ok')
        elif time.monotonic() - p_[0] >= AW_PENDING:
            pend.pop(c['id'], None)                      # text provably still in his box after this long: may retry
            _pb_log(f'Autowelcome: {p_[1]!r} - still not sent {AW_PENDING} s after Send - trying again')
    todo = _aw_candidates(cards)
    scrolled = _aw.setdefault('scrolled_w', {})
    if not todo:
        hidden = _aw_hidden_subs(cards, getattr(rd, 'notif_rect', None))
        if hidden:                                      # new sub below the visible part: no box yet
            c = hidden[0]
            _aw['scrolls'][c['id']] = _aw['scrolls'].get(c['id'], 0) + 1
            try:
                rd.scroll_into_view(c['id_el'])
                scrolled[hwnd] = True
                _pb_log(f"Autowelcome [{acct}]: {c.get('name') or c['id']!r} is outside the visible Notifications - scrolled him into view")
            except Exception as exc:
                _pb_log(f'Autowelcome: could not scroll the Notifications panel: {exc!r}'[:160])
            time.sleep(0.8)
            return 'acted'
        if scrolled.get(hwnd):                          # done: back to the newest at the top
            scrolled[hwnd] = False
            top = min((c for c in cards if c.get('id_el') is not None), key=lambda c: c['top'], default=None)
            if top is not None:
                try: rd.scroll_into_view(top['id_el'])
                except Exception: pass
        return 'idle'
    c = todo[0]
    if not _aw_welcome(rd, hwnd, c, win) and _aw['tries'].get(c['id'], 0) >= 3:
        _aw_mark(c['id'], c.get('name'), False)
        nm = (c.get('name') or 'him').strip()
        root.after(0, lambda nm=nm, h_=hwnd: _pop_info(f"Couldn't welcome {nm}", 'Send him the welcome yourself.', 9.0, hwnd=h_))
    _aw['acted_at'] = time.monotonic()                  # (no fixed pause: AW_GAP keeps 3.2 s between sends)
    return 'acted'


def _aw_worker():
    time.sleep(3)
    try:
        import uiautomation as auto
        import uia_reader as _ur
    except Exception:
        _aw_set_status('UI Automation missing')
        return
    with auto.UIAutomationInitializerInThread():
        readers = {}                                    # one reader per FansMetric window (each has its own panel)
        while not _pb.get('stop'):
            time.sleep(0.25 if time.monotonic() - _aw.get('acted_at', 0.0) < 8 else 1.0)   # a burst of new subs: no idle wait
            if not autowelcome_on or not (autowelcome_msg or '').strip():
                if _aw['status'] != 'off':
                    _aw_set_status('off')
                continue
            try:
                if poke_in_progress or send_in_progress:
                    continue
                wins = [w for w in find_fansmetric_windows() if not getattr(w, 'isMinimized', False)]
                if not wins:
                    _aw_set_status('FansMetric is not open' if not find_fansmetric_windows() else 'FansMetric is minimized')
                    continue
                live = {int(getattr(w, '_hWnd', 0)) for w in wins}
                for h in list(readers):
                    if h not in live:
                        readers.pop(h, None)
                seen = 0
                accts = []
                for n, win in enumerate(wins):
                    h = int(getattr(win, '_hWnd', 0))
                    rd = readers.get(h) or readers.setdefault(h, _ur.UiaReader())
                    try:
                        res = _aw_process(rd, win, f'window {n + 1}')
                    except Exception as exc:
                        _pb_log(f'Autowelcome error (window {n + 1}): {exc!r}'[:200])
                        readers.pop(h, None)
                        res = None
                    if getattr(rd, '_acct', ''):
                        _acct_map[h] = rd._acct
                    accts.append((getattr(rd, '_acct', '') or f'window {n + 1}', res is not None))
                    if res is not None:
                        seen += 1
                    if res == 'acted':                  # one action per round, then read everything fresh -
                        prev = dict(_aw.get('accts') or [])  # the windows not read this round keep their last state
                        for m, w in enumerate(wins[n + 1:], start=n + 1):
                            r_ = readers.get(int(getattr(w, '_hWnd', 0)))
                            nm_ = (getattr(r_, '_acct', '') if r_ is not None else '') or f'window {m + 1}'
                            accts.append((nm_, prev.get(nm_, True)))
                        break
                if accts != _aw.get('accts'):
                    _aw['accts'] = accts
                    try: root.after(0, _aw_status_draw)
                    except Exception: pass
                if seen == 0:
                    _aw_set_status('Open NOTIFICATIONS in FansMetric')
                    if not _aw.get('blind_since'):
                        _aw['blind_since'] = time.monotonic()
                    elif not _aw.get('blind_warned') and time.monotonic() - _aw['blind_since'] > 60:
                        _aw['blind_warned'] = True                  # once per blind period
                        _pb_log('Autowelcome: Notifications not visible for over 1 minute - warning shown')
                        root.after(0, lambda: _pop_show_toast('welcome', "Autowelcome can't see new subs",
                                                              'Notifications is not open on this FansMetric tab', [], life=12.0))
                    continue
                _aw['blind_since'] = None
                _aw['blind_warned'] = False
                _aw['windows'] = (seen, len(wins))
                if _aw['status'] != 'ok' and not _aw['status'].startswith('Cancelled'):
                    _aw_set_status('ok')
            except Exception as exc:
                _pb_log(f'Autowelcome error: {exc!r}'[:200])
                time.sleep(3.0)


def _aw_start():
    if not POKEFLOW_LITE:
        _kb_start()
    if _aw['thread'] is None and not POKEFLOW_LITE:
        t = threading.Thread(target=_aw_worker, daemon=True, name='PokeFlow-Autowelcome')
        _aw['thread'] = t
        t.start()


def find_fansmetric_window_cached():
    now = time.monotonic()
    if _dw.get('win_at', 0.0) + (0.7 if _dw.get('multi') else 3.0) < now:
        _dw['win'], _dw['win_at'] = find_fansmetric_window(), now
        try:
            _dw['multi'] = len(find_fansmetric_windows()) > 1      # 2 windows: re-check which one you are in more often
        except Exception:
            _dw['multi'] = False
    return _dw.get('win')


def _dup_watch_start():
    if _dw['thread'] is None:
        t = threading.Thread(target=_dup_watch_worker, daemon=True, name='PokeFlow-DupWatch')
        _dw['thread'] = t
        t.start()


def _pl_start():
    if _pl['thread'] is None:
        t = threading.Thread(target=_pl_worker, daemon=True, name='PokeFlow-Loading')
        _pl['thread'] = t
        t.start()




def _pb_screen_reader_flag():
    """Windows' 'a screen reader is running' flag. Chromium apps (FansMetric) that see it build their FULL accessibility tree
    straight away instead of piece by piece when somebody asks - that piece-by-piece build is the 'loading' delay after
    switching pages. PokeFlow switches it on while it runs and puts it back to what it was when it closes."""
    if _pb.get('sr_done'):
        return
    _pb['sr_done'] = True
    try:
        import atexit
        u = ctypes.windll.user32
        cur = ctypes.c_int(0)
        u.SystemParametersInfoW(0x0046, 0, ctypes.byref(cur), 0)          # SPI_GETSCREENREADER
        if cur.value:
            _pb_log('Screen-reader flag: already on')
            return
        ok = u.SystemParametersInfoW(0x0047, 1, None, 0x0002)             # SPI_SETSCREENREADER, SPIF_SENDCHANGE
        _pb_log('Screen-reader flag: switched on (ok=%s)' % bool(ok))
        def _restore():
            try: u.SystemParametersInfoW(0x0047, 0, None, 0x0002)
            except Exception: pass
        atexit.register(_restore)
    except Exception as exc:
        _pb_log('Screen-reader flag: not available (%s)' % repr(exc)[:80])


def _pb_start():
    try: _pb_screen_reader_flag()
    except Exception: pass
    if _pb['thread'] is None:
        t = threading.Thread(target=_pb_worker, daemon=True, name='PokeFlow-Badges')
        _pb['thread'] = t
        t.start()
    _pl_start()
    _dup_watch_start()
    _aw_start()
    if not POKEFLOW_LITE:
        threading.Thread(target=_acct_watch_worker, daemon=True, name='PokeFlow-Accounts').start()
    try: root.after(1500, _pop_follow_tick)
    except Exception: pass
    root.after(250, _pb_apply)
    def _ph_prebuild():
        try:
            if _ph.get('win') is None:
                _ph['win'] = _ph_build(_pop_theme())
        except Exception:
            pass
    root.after(900, _ph_prebuild)


def _prewarm_screen_ocr():
    """Initialize RapidOCR while the UI is idle so Ctrl+Q avoids first-use model delay."""
    sample = None
    try:
        _get_screen_ocr_engine()
        from PIL import Image as PILImage
        sample = PILImage.new('RGB', (320, 64), (13, 20, 32))
        _run_screen_ocr(sample)
    except Exception:
        # Keep the app launch available; Ctrl+Q will show the actionable OCR error.
        pass
    finally:
        if sample is not None:
            try: sample.close()
            except Exception: pass

# OCR is only a backup now (the reader does the work): it loads the first time a backup needs it, not at every start
# (it used 100-200 MB of RAM just sitting there).

# ---------------- Initial page and state ----------------
_set_startup_progress(93, 'Finishing workspace setup')
if not POKEFLOW_LITE:                        # Lite: no local AI, no animated background
    root.after(900, _ai_autostart_ollama)
    try: _set_theme_background(theme_mode)   # remembered theme: start with its loop already running
    except Exception: pass
    root.after(4000, _bg_watchdog)
root.after(1200, _art_preload)


_lag = {'last': None, 'logged': 0.0}


def _lag_tick():
    """Every 100 ms: if the window was frozen for a while (hovers lagging), write what was busy to badges_debug.txt."""
    now = time.monotonic()
    last = _lag['last']
    _lag['last'] = now
    if last is not None:
        late = (now - last - 0.1) * 1000
        try: _lag.setdefault('lates', []).append(max(0.0, late))
        except Exception: pass
        if late > 250 and now - _lag['logged'] > 2.0:
            _lag['logged'] = now
            busy = [t.name for t in threading.enumerate() if t.name.startswith('PokeFlow-') and t.is_alive()]
            try:
                _pb_log(f'UI froze {late:.0f} ms (page={page}, video={"on" if video_background_enabled else "off"}, '
                        f'autowelcome={"on" if autowelcome_on else "off"}, threads={",".join(sorted(set(busy)))[:200]})')
            except Exception:
                pass
    root.after(100, _lag_tick)


def _thread_cpu_ms():
    """{thread name: CPU ms used so far} for PokeFlow's threads + the window thread (Windows only)."""
    out = {}
    if os.name != 'nt':
        return out
    k = ctypes.windll.kernel32
    class _FT(ctypes.Structure):
        _fields_ = [('lo', ctypes.c_ulong), ('hi', ctypes.c_ulong)]
    for t in threading.enumerate():
        tid = getattr(t, 'native_id', None)
        if not tid:
            continue
        h = k.OpenThread(0x0800, False, tid)                 # THREAD_QUERY_LIMITED_INFORMATION
        if not h:
            continue
        try:
            c, e, kt, ut = _FT(), _FT(), _FT(), _FT()
            if k.GetThreadTimes(h, ctypes.byref(c), ctypes.byref(e), ctypes.byref(kt), ctypes.byref(ut)):
                ms = (((kt.hi << 32) | kt.lo) + ((ut.hi << 32) | ut.lo)) / 10000.0
                nm = 'WINDOW (main)' if t is threading.main_thread() else t.name
                out[nm] = out.get(nm, 0.0) + ms
        finally:
            k.CloseHandle(h)
    return out


def _perf_watch_worker():
    """Every 30 s: is the window sluggish (not frozen, just late)? Then log who used the CPU - so 'it's laggy' can be
    fixed from facts. Quiet when everything is smooth."""
    prev, prev_t = _thread_cpu_ms(), time.monotonic()
    while not _pb.get('stop'):
        time.sleep(30)
        try:
            lates = _lag.get('lates') or []
            _lag['lates'] = []
            cur, now = _thread_cpu_ms(), time.monotonic()
            span = max(1.0, (now - prev_t) * 1000)
            use = sorted(((n, (ms - prev.get(n, 0.0)) / span * 100) for n, ms in cur.items()), key=lambda x: -x[1])
            prev, prev_t = cur, now
            vc = _vid.get('cost') or []
            _vid['cost'] = []
            hv = _lag.get('hover') or []
            _lag['hover'] = []
            if not lates:
                continue
            avg = sum(lates) / len(lates)
            slow = sum(1 for x in lates if x > 60) * 100.0 / len(lates)
            busy = [(n, p) for n, p in use if p >= 3]
            if avg > 25 or slow > 10 or any(p > 40 for _n, p in busy) or len(hv) >= 3:
                vtxt = (f'video frame draw {sum(vc) / len(vc):.0f} ms avg / {max(vc):.0f} max ({len(vc)} frames)' if vc else 'video: no frames')
                htxt = (f'hover draw {sum(hv) / len(hv):.0f} ms avg / {max(hv):.0f} max ({len(hv)} hovers)' if hv else 'no hovers')
                _pb_log(f'Perf: window {avg:.0f} ms late on average, {slow:.0f}% of moments >60 ms late (page={page}, '
                        f'theme={theme_mode}, video={"on" if video_background_enabled else "off"}, '
                        f'autowelcome={"on" if autowelcome_on else "off"}) | {vtxt} | {htxt} | '
                        f'CPU of one core: ' + ', '.join(f'{n} {p:.0f}%' for n, p in busy[:7]))
        except Exception as exc:
            try: _pb_log(f'Perf watch error: {exc!r}'[:160])
            except Exception: pass


threading.Thread(target=_perf_watch_worker, daemon=True, name='PokeFlow-Perf').start()
root.after(3000, _lag_tick)
root.after(7000, _bug_crash_offer)
root.after(5000, _upd_after_start)
if not POKEFLOW_LITE:
    threading.Thread(target=_ai_poke_worker, daemon=True, name='PokeFlow-AIPokes').start()
draw_main()
if not POKEFLOW_LITE:
    root.after(1500, _ai_refresh_status)
poll_global_hotkeys()

# ---- badges / LOADING come back the moment a hotkey action is DONE ----
# Each action pauses the badges (8-15 s safety limit) so they cannot get in its screenshots. That pause used to run
# to the end even when the action took 1 s: after Ctrl+Q in a chat, the Fans page then had NO badges and NO LOADING
# for up to ~14 s - the 'delay after opening a chat' you kept seeing. Now the pause ends with the action.
def _pb_quiet_end():
    _pb['quiet_until'] = min(_pb['quiet_until'], time.monotonic() + 0.3)
    try: _pb_log('Badges: hotkey action finished - badges / LOADING back')
    except Exception: pass


def _pb_wrap_quiet(fn):
    def run(*a, **k):
        try:
            return fn(*a, **k)
        finally:
            _pb_quiet_end()
    run.__name__ = fn.__name__
    return run


personalize = _pb_wrap_quiet(personalize)
_send_current_message_impl = _pb_wrap_quiet(_send_current_message_impl)
fix_banned_words = _pb_wrap_quiet(fix_banned_words)
save_profile_id_and_start_repoke_timer = _pb_wrap_quiet(save_profile_id_and_start_repoke_timer)


_pb_start()
if not POKEFLOW_LITE:
    root.after(1500, _ks_tick)
root.protocol('WM_DELETE_WINDOW', minimize_to_tray)
_set_startup_progress(100, 'Ready')


def _lite_start():
    """PokeFlow Lite: no window. Tray icon (right-click -> Exit) + a short 'running' notice."""
    global _startup_active, tray_icon, shortcut_overlay_on, poke_badges_enabled
    _startup_active = False
    shortcut_overlay_on = False
    poke_badges_enabled = True
    try: _startup_canvas.destroy()
    except Exception: pass
    try: root.withdraw()
    except Exception: pass
    try:
        if TRAY_READY and TrayImage is not None and tray_icon is None:
            ico_path = ui_asset_dir / 'pokeflow_app.png'
            img = TrayImage.open(ico_path).convert('RGBA') if ico_path.exists() else TrayImage.new('RGBA', (64, 64), (10, 16, 25, 255))
            img = img.resize((64, 64))
            tray_icon = pystray.Icon('PokeFlow Lite', img, 'PokeFlow Lite - Ctrl+Q / Ctrl+S, hover a fan for his poke stage',
                                     pystray.Menu(pystray.MenuItem('Exit PokeFlow Lite', _tray_exit)))
            tray_icon.run_detached()
    except Exception:
        pass
    _pb_log('PokeFlow Lite started')
    try:
        _pop_show_toast('ai', 'PokeFlow Lite is running', 'Ctrl+Q / Ctrl+S in a chat \u2022 hover a fan for his poke stage \u2022 exit: tray icon',
                        [('pop_ok', lambda it: _pop_close_toast(it))], life=12)
    except Exception:
        pass


def _finish_startup_splash():
    """Dismiss splash after a short, polished minimum display time."""
    global _startup_active, _external_ready_started
    if POKEFLOW_LITE:
        _lite_start()
        return
    if _EXTERNAL_SPLASH_MODE:
        _startup_active = False
        _external_ready_started = time.monotonic()
        _write_external_splash_state(100, 'Ready', ready=True)
        try: _startup_canvas.destroy()  # the external launcher owns the visible splash
        except Exception: pass
        _wait_for_external_splash_dismiss()
        return
    elapsed = time.monotonic() - _startup_started
    if elapsed < 0.85:
        try: root.after(35, _finish_startup_splash)
        except Exception: pass
        return
    _startup_active = False
    try:
        _startup_canvas.destroy()
    except Exception:
        pass
    try:
        root.overrideredirect(False)
        # Keep the actual 900x600 client area and center the restored native window.
        root.geometry(f'{W}x{H}+{_root_x}+{_root_y}')
        root.deiconify()
        root.update_idletasks()
        _schedule_native_titlebar_theme(theme_mode)
    except Exception:
        try: root.deiconify()
        except Exception: pass


def _wait_for_external_splash_dismiss():
    """Keep the application hidden until the launcher's splash has closed."""
    dismissed = bool(_EXTERNAL_SPLASH_DISMISSED and _EXTERNAL_SPLASH_DISMISSED.exists())
    timed_out = _external_ready_started is not None and (time.monotonic() - _external_ready_started) > 10.0
    if dismissed or timed_out:
        try:
            if _EXTERNAL_SPLASH_SHOWN is not None:
                _EXTERNAL_SPLASH_SHOWN.parent.mkdir(parents=True, exist_ok=True)
                _EXTERNAL_SPLASH_SHOWN.write_text('shown', encoding='utf-8')
        except Exception:
            pass
        try:
            root.deiconify()
            root.update_idletasks()
            _schedule_native_titlebar_theme(theme_mode)
        except Exception:
            try: root.deiconify()
            except Exception: pass
        return
    try: root.after(45, _wait_for_external_splash_dismiss)
    except Exception:
        try: root.deiconify()
        except Exception: pass


root.after(30, _finish_startup_splash)
root.mainloop()
