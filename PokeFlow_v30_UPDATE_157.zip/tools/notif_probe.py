"""PokeFlow NOTIFICATIONS probe - read-only. Dumps EVERYTHING inside FansMetric's side panels (Notifications, or a chat
opened from a notification): also elements without a name (like the little message icon and the back arrow), with
their type, class, link and whether they can be pressed. Nothing is clicked, typed or changed.

Run:  RUN_NOTIF_PROBE.bat   -> writes notif_probe_result.txt next to the .bat
"""
import ctypes, subprocess, sys, time
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / 'notif_probe_result.txt'
lines = []
def log(*a):
    s = ' '.join(str(x) for x in a); print(s); lines.append(s)
def save():
    OUT.write_text('\n'.join(lines), encoding='utf-8')

try:
    import uiautomation as auto
except ImportError:
    subprocess.call([sys.executable, '-m', 'pip', 'install', '--quiet', 'uiautomation'])
    import uiautomation as auto
try:
    ctypes.windll.user32.SystemParametersInfoW(0x0047, 1, None, 0x0002)
except Exception:
    pass

log('PokeFlow notifications probe v3', time.strftime('%Y-%m-%d %H:%M:%S'))
for n in range(3, 0, -1):
    print(f'  reading FansMetric in {n} ...', end='\r'); time.sleep(1)
print()
class _PT(ctypes.Structure):
    _fields_ = [('x', ctypes.c_long), ('y', ctypes.c_long)]
_pt = _PT(); ctypes.windll.user32.GetCursorPos(ctypes.byref(_pt))
log(f'mouse at ({_pt.x},{_pt.y})')
win = None
try:                                                   # the FansMetric window under the mouse (2 accounts = 2 windows)
    u = ctypes.windll.user32
    u.WindowFromPoint.restype = ctypes.c_void_p
    h = u.GetAncestor(ctypes.c_void_p(u.WindowFromPoint(_pt)), 2)
    w = auto.ControlFromHandle(h)
    if w is not None and 'fansmetric' in (w.Name or '').lower():
        win = w
except Exception:
    pass
if win is None:
    for w in auto.GetRootControl().GetChildren():
        nm = (w.Name or '').lower()
        if 'fansmetric' in nm and 'pokeflow' not in nm:
            win = w; break
if win is None:
    log('FansMetric window not found'); save(); sys.exit(1)
log('window:', repr(win.Name))

PAT = (('invoke', 10000), ('value', 10002), ('scrollitem', 10017), ('toggle', 10015), ('legacy', 10018))
def info(c):
    e = c.Element
    try:
        r = c.BoundingRectangle; rect = f'({r.left},{r.top},{r.right},{r.bottom})'
    except Exception:
        rect = '?'
    extra = []
    try:
        if c.ClassName: extra.append(f"class={c.ClassName[:70]!r}")
    except Exception: pass
    try:
        if c.AutomationId: extra.append(f"id={c.AutomationId[:40]!r}")
    except Exception: pass
    try:
        v = e.GetCurrentPropertyValue(30093)            # LegacyIAccessible value = the link of a hyperlink
        if isinstance(v, str) and v: extra.append(f'link={v[:90]!r}')
    except Exception: pass
    try:
        v = e.GetCurrentPropertyValue(30045)
        if isinstance(v, str) and v: extra.append(f'value={v[:60]!r}')
    except Exception: pass
    pats = []
    for nm, pid in PAT:
        try:
            if e.GetCurrentPattern(pid): pats.append(nm)
        except Exception: pass
    try:
        if not c.IsEnabled: pats.append('DISABLED')
    except Exception: pass
    try:
        if e.CurrentIsOffscreen: pats.append('HIDDEN')
    except Exception: pass
    return f"{c.ControlTypeName} {c.Name[:80]!r} {rect} {' '.join(extra)} [{','.join(pats)}]"

count = [0]
def walk(c, depth, limit=2500):
    if count[0] >= limit or depth > 60:
        return
    count[0] += 1
    log('  ' * depth + info(c))
    try:
        for ch in c.GetChildren():
            walk(ch, depth + 1, limit)
    except Exception:
        pass

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import uia_reader as _ur                               # same way PokeFlow finds the panels (whole tree, any depth)
_rd = _ur.UiaReader()
_rd._load()
uia = _rd._iuia()
arr = win.Element.FindAll(4, uia.CreatePropertyCondition(30003, 50030))   # every web page (Document) inside FansMetric
docs = []
for i in range(arr.Length if arr is not None else 0):
    try:
        c = auto.Control.CreateControlFromElement(arr.GetElement(i))
        if (c.AutomationId or '') == 'RootWebArea':
            docs.append(c)
    except Exception:
        pass
log(f'{len(docs)} web pages inside FansMetric:')
for d in docs:
    r = d.BoundingRectangle
    log(f'  {d.Name!r} ({r.left},{r.top},{r.right},{r.bottom})')
for d in docs:
    nm = (d.Name or '').lower()
    if nm.startswith('client') or nm.startswith('messages'):
        continue                                          # the big main page / chat list: not needed here
    log('')
    log(f'===== {d.Name!r} - everything inside =====')
    count[0] = 0
    walk(d, 0)
log('')
log('3-second box text present:', any('allow 3 seconds' in l.lower() for l in lines))

# ---- what FansMetric says is UNDER THE MOUSE (point at a reply box PokeFlow could not use) ----
log('')
log(f'===== under the mouse ({_pt.x},{_pt.y}) - asked 3 times, 1 s apart =====')
from ctypes.wintypes import POINT
for n in range(3):
    try:
        e = uia.ElementFromPoint(POINT(_pt.x, _pt.y))
        c = auto.Control.CreateControlFromElement(e)
        log(f'ask {n + 1}:')
        for depth in range(7):
            if c is None:
                break
            log('    ' + '  ' * depth + info(c))
            c = c.GetParentControl()
    except Exception as exc:
        log(f'ask {n + 1}: failed {exc!r}')
    time.sleep(1)
try:                                                   # every reply box FansMetric reports in the whole window
    eds = win.Element.FindAll(4, uia.CreatePropertyCondition(30003, 50004))
    names = []
    for i in range(eds.Length if eds is not None else 0):
        try:
            c = auto.Control.CreateControlFromElement(eds.GetElement(i))
            r = c.BoundingRectangle
            names.append(f'{c.Name[:30]!r}@({r.left},{r.top})')
        except Exception:
            pass
    log(f'all text boxes in the window ({len(names)}): ' + ', '.join(names[:40]))
except Exception as exc:
    log(f'text box list failed {exc!r}')
save()
