@echo off
cd /d "%~dp0"
title PokeFlow notifications probe (read-only)
echo ============================================================
echo  PokeFlow NOTIFICATIONS probe - only READS FansMetric, changes nothing.
echo  Run it twice and send me notif_probe_result.txt each time:
echo   1. With the NOTIFICATIONS panel showing a new sub (with the little message icon).
echo   2. After clicking that little message icon (his chat open in that panel, arrow next to his name).
echo  Bonus: if the "Please allow 3 seconds." box is on screen, run it then too.
echo  NEW: a sub has a reply box on screen but PokeFlow says it can't quick-reply him?
echo       Press a key, then within 3 seconds put the MOUSE on his "Send a quick reply..." box and keep it there.
echo ============================================================
echo Press any key to read FansMetric (it reads after 3 seconds)...
pause >nul
set "PY=py -3"
py -3.12 -c "print(1)" >nul 2>&1 && set "PY=py -3.12"
%PY% -c "print(1)" >nul 2>&1 || set "PY=python"
%PY% tools\notif_probe.py
echo.
echo Done. Send me the file notif_probe_result.txt (it is in this folder).
pause
