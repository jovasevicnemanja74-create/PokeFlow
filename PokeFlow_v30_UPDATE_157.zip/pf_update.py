"""PokeFlow auto-update.

The owner publishes a GitHub release with two files:  PokeFlow_v30_UPDATE_N.zip  +  update.json  (made by SIGN_UPDATE.bat,
signed with the owner's private key). PokeFlow checks the latest release now and then, downloads a NEWER version,
checks the signature + the zip's fingerprint, and gets it ready. The launcher installs it on the next start
(old files backed up; if the new version does not start, the old one is put back). User data in %LOCALAPPDATA% is never
touched. Without a valid signature nothing is ever installed.
"""
import hashlib
import json
import os
import re
import shutil
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

import pf_ed25519 as _ed

REPO = 'jovasevicnemanja74-create/PokeFlow'
UPDATE_PUBLIC_KEY = ''                      # hex, filled in after MAKE_KEYS.bat (update_public_key.txt overrides it)
APP_DIR = Path(__file__).resolve().parent
_base = os.environ.get('LOCALAPPDATA')
DATA_DIR = (Path(_base) / 'PokeFlow') if _base else (Path.home() / '.pokeflow')
STAGE_DIR = DATA_DIR / 'update_staging'
BACKUP_DIR = DATA_DIR / 'update_backup'
STATE_PATH = DATA_DIR / 'update_state.json'
NEVER_REPLACE = {'START.bat', 'START.vbs', 'update_public_key.txt', 'update_token.txt'}   # START.bat is running while we install
UA = {'User-Agent': 'PokeFlow-Updater'}


def local_version(app_dir=APP_DIR):
    """Highest '=== UPDATE N ===' in CHANGES_THIS_BUILD.txt (0 if unknown)."""
    try:
        txt = (Path(app_dir) / 'CHANGES_THIS_BUILD.txt').read_text(encoding='utf-8', errors='replace')
        n = [int(x) for x in re.findall(r'=== UPDATE (\d+) ===', txt)]
        return max(n) if n else 0
    except Exception:
        return 0


def public_key(app_dir=APP_DIR):
    try:
        k = (Path(app_dir) / 'update_public_key.txt').read_text(encoding='utf-8').strip()
        if re.fullmatch(r'[0-9a-fA-F]{64}', k):
            return bytes.fromhex(k)
    except Exception:
        pass
    return bytes.fromhex(UPDATE_PUBLIC_KEY) if re.fullmatch(r'[0-9a-fA-F]{64}', UPDATE_PUBLIC_KEY or '') else None


def _token(app_dir=APP_DIR):
    try:
        t = (Path(app_dir) / 'update_token.txt').read_text(encoding='utf-8').strip()
        return t or None
    except Exception:
        return None


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def _get(url, accept='application/vnd.github+json', timeout=30):
    """GET with the GitHub token (private repository) - but the token is only ever sent to api.github.com: release
    files are handed over to GitHub's file storage by a redirect, and that storage refuses a second login."""
    h = dict(UA, Accept=accept)
    tok = _token()
    if tok and 'api.github.com' in url:
        h['Authorization'] = 'Bearer ' + tok
        opener = urllib.request.build_opener(_NoRedirect)
        try:
            with opener.open(urllib.request.Request(url, headers=h), timeout=timeout) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code in (301, 302, 303, 307, 308) and e.headers.get('Location'):
                with urllib.request.urlopen(urllib.request.Request(e.headers['Location'], headers=dict(UA, Accept=accept)),
                                            timeout=timeout) as r:
                    return r.read()
            raise
    with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout) as r:
        return r.read()


def _manifest_body(m):
    """The exact bytes that are signed: every field except the signature, sorted, compact."""
    body = {k: v for k, v in m.items() if k != 'signature'}
    return json.dumps(body, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')


def make_manifest(zip_path, seed, notes=''):
    """SIGN_UPDATE.bat: update.json for this update zip, signed with the owner's private key."""
    data = Path(zip_path).read_bytes()
    with zipfile.ZipFile(zip_path) as z:
        names = z.namelist()
        ch = next((n for n in names if n.split('/')[-1] == 'CHANGES_THIS_BUILD.txt'), None)
        txt = z.read(ch).decode('utf-8', errors='replace') if ch else ''
    nums = [int(x) for x in re.findall(r'=== UPDATE (\d+) ===', txt)]
    if not nums:
        raise ValueError('CHANGES_THIS_BUILD.txt with "=== UPDATE N ===" not found in the zip')
    ver = max(nums)
    if not notes:
        sect = txt.split(f'=== UPDATE {ver} ===', 1)[-1].split('=== UPDATE ', 1)[0].strip()
        notes = sect[:1500]
    m = {'app': 'PokeFlow', 'version': ver, 'zip': Path(zip_path).name, 'sha256': hashlib.sha256(data).hexdigest(),
         'size': len(data), 'notes': notes, 'signed_at': time.strftime('%Y-%m-%d %H:%M:%S')}
    m['signature'] = _ed.sign(seed, _manifest_body(m)).hex()
    return m


def check_manifest(m, pub):
    try:
        return bool(pub) and m.get('app') == 'PokeFlow' and _ed.verify(pub, _manifest_body(m), bytes.fromhex(m['signature']))
    except Exception:
        return False


def state():
    try:
        return json.loads(STATE_PATH.read_text(encoding='utf-8'))
    except Exception:
        return {}


def _save_state(st):
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        STATE_PATH.write_text(json.dumps(st, indent=1), encoding='utf-8')
    except Exception:
        pass


def staged_version():
    st = state()
    v = st.get('staged')
    if v and (STAGE_DIR / str(v) / 'update.zip').exists() and (STAGE_DIR / str(v) / 'update.json').exists():
        return int(v)
    return 0


def _sources(log):
    """Where updates can be: (1) the latest GitHub RELEASE, (2) the files on the repository's main branch
    (update.json + the zip, pushed straight into the repository). Yields (name, (manifest, fetch_zip(name)))."""
    try:
        rel = json.loads(_get(f'https://api.github.com/repos/{REPO}/releases/latest'))
        assets = {a.get('name'): a for a in rel.get('assets') or []}
        if 'update.json' in assets:
            def fetch(a):
                if _token():
                    return _get(a['url'], accept='application/octet-stream', timeout=300)
                return _get(a['browser_download_url'], accept='application/octet-stream', timeout=300)
            m = json.loads(fetch(assets['update.json']))
            yield 'release', (m, lambda name, _a=assets: fetch(_a[name]) if name in _a else None)
    except Exception as exc:
        if '404' not in repr(exc):
            log(f'Update check (release): {exc!r}'[:160])
    try:
        def raw(name):
            if _token():
                return _get(f'https://api.github.com/repos/{REPO}/contents/{name}?ref=main', accept='application/vnd.github.raw', timeout=300)
            return _get(f'https://raw.githubusercontent.com/{REPO}/main/{name}', accept='application/octet-stream', timeout=300)
        m = json.loads(raw('update.json'))
        def fetch_zip(name):
            try:
                return raw(name)
            except Exception:
                return None
        yield 'repository', (m, fetch_zip)
    except Exception as exc:
        if '404' not in repr(exc):
            log(f'Update check (repository): {exc!r}'[:160])


def check_and_download(log=print):
    """Look at the latest GitHub release. Newer + correctly signed -> downloaded and ready for the next start.
    Returns (version, notes) when an update is ready, None otherwise."""
    pub = public_key()
    if pub is None:
        log('Update check: no signing key in this PokeFlow yet (MAKE_KEYS.bat) - updates are off')
        return None
    cur = local_version()
    best = None                                              # (manifest, fetch-the-zip function) of the newest signed one
    for src, (m, fetch_zip) in _sources(log):
        if not check_manifest(m, pub):
            log(f'Update check ({src}): update.json is NOT signed with the PokeFlow key - ignored')
            continue
        if best is None or int(m.get('version', 0)) > int(best[0].get('version', 0)):
            best = (m, fetch_zip)
    if best is None:
        return None
    m, fetch_zip = best
    ver = int(m.get('version', 0))
    if ver <= cur or ver == state().get('skip'):
        return None                                          # not newer, or it failed to start here before
    if staged_version() == ver:
        return ver, m.get('notes', '')
    data = fetch_zip(m.get('zip'))
    if data is None:
        log(f"Update check: {m.get('zip')!r} not found next to its update.json")
        return None
    if hashlib.sha256(data).hexdigest() != m.get('sha256'):
        log('Update check: the downloaded zip does not match its signed fingerprint - ignored')
        return None
    d = STAGE_DIR / str(ver)
    shutil.rmtree(d, ignore_errors=True)
    d.mkdir(parents=True, exist_ok=True)
    (d / 'update.zip').write_bytes(data)
    (d / 'update.json').write_text(json.dumps(m, ensure_ascii=False), encoding='utf-8')
    st = state(); st['staged'] = ver; _save_state(st)
    log(f'Update {ver} downloaded and checked - installs on the next start')
    return ver, m.get('notes', '')


def _members(z):
    """Zip entries -> paths inside the app folder (a single top folder like 'PokeFlow/' is removed)."""
    names = [n for n in z.namelist() if not n.endswith('/')]
    tops = {n.split('/', 1)[0] for n in names}
    strip = len(tops) == 1 and all('/' in n for n in names)
    out = []
    for n in names:
        rel = n.split('/', 1)[1] if strip else n
        p = Path(rel)
        if p.is_absolute() or '..' in p.parts or not rel:
            continue                                         # never write outside the app folder
        out.append((n, rel))
    return out


def apply_staged(app_dir=APP_DIR, log=print):
    """Launcher, BEFORE PokeFlow starts: install a downloaded update (signature + fingerprint checked again).
    Old files go to the backup folder first. Returns the installed version or 0."""
    v = staged_version()
    if not v or v <= local_version(app_dir):
        return 0
    d = STAGE_DIR / str(v)
    try:
        m = json.loads((d / 'update.json').read_text(encoding='utf-8'))
        data = (d / 'update.zip').read_bytes()
        if not check_manifest(m, public_key(app_dir)) or hashlib.sha256(data).hexdigest() != m.get('sha256'):
            log('Update: staged files failed the check - deleted, not installed')
            shutil.rmtree(d, ignore_errors=True)
            return 0
        old = local_version(app_dir)
        bdir = BACKUP_DIR / str(old)
        shutil.rmtree(bdir, ignore_errors=True)
        bdir.mkdir(parents=True, exist_ok=True)
        new_files = []
        with zipfile.ZipFile(d / 'update.zip') as z:
            for name, rel in _members(z):
                if rel in NEVER_REPLACE:
                    continue
                dst = Path(app_dir) / rel
                if dst.exists():
                    (bdir / rel).parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(dst, bdir / rel)
                else:
                    new_files.append(rel)
            (bdir / '_new_files.json').write_text(json.dumps(new_files), encoding='utf-8')
            for name, rel in _members(z):
                if rel in NEVER_REPLACE:
                    continue
                dst = Path(app_dir) / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                tmp = dst.with_name(dst.name + '.pfnew')
                tmp.write_bytes(z.read(name))
                os.replace(tmp, dst)
        st = state()
        st.update(staged=None, just_installed=v, previous=old, notes=m.get('notes', ''), confirmed=False,
                  installed_at=time.strftime('%Y-%m-%d %H:%M:%S'))
        _save_state(st)
        shutil.rmtree(d, ignore_errors=True)
        log(f'Update: {old} -> {v} installed')
        return v
    except Exception as exc:
        log(f'Update: install failed ({exc!r}) - restoring')
        rollback(app_dir, log)
        return 0


def rollback(app_dir=APP_DIR, log=print):
    """Put the version from before the last update back (launcher: the new version did not start)."""
    st = state()
    old = st.get('previous')
    bdir = BACKUP_DIR / str(old) if old is not None else None
    if not bdir or not bdir.exists():
        return False
    try:
        new_files = json.loads((bdir / '_new_files.json').read_text(encoding='utf-8'))
    except Exception:
        new_files = []
    for p in bdir.rglob('*'):
        if p.is_file() and p.name != '_new_files.json':
            dst = Path(app_dir) / p.relative_to(bdir)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
    for rel in new_files:
        try: (Path(app_dir) / rel).unlink()
        except Exception: pass
    bad = st.get('just_installed')
    st.update(just_installed=None, confirmed=True, rolled_back_from=bad, skip=bad)
    _save_state(st)
    log(f'Update: {bad} did not start - version {old} put back')
    return True


def confirm_started():
    """PokeFlow, once it is up: the installed update works -> keep it, drop older backups."""
    st = state()
    if st.get('just_installed') and not st.get('confirmed'):
        st['confirmed'] = True
        _save_state(st)
        try:
            keep = str(st.get('previous'))
            for b in BACKUP_DIR.iterdir():
                if b.name != keep:
                    shutil.rmtree(b, ignore_errors=True)
        except Exception:
            pass
        return st.get('just_installed'), st.get('notes', '')
    return None
