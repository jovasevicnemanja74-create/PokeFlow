"""Fresh AI poke messages for each PokeFlow session.

At start, if the local AI (Ollama + the 8B model) is installed AND the PC has a real graphics card, PokeFlow asks the
model for 10 new messages per poke stage, one stage at a time, in the background. Until a stage is ready - and on PCs
without AI or without a GPU - Ctrl+Q uses the 30 built-in messages. Every AI message is checked before it is used.
"""
import difflib
import re

STAGE_MEANING = {
    1: "Poke 1 - he has gone quiet for a while. Re-open the chat warmly: we haven't talked in a bit, what has he been "
       "up to, how has he been. Curious and sweet, no pressure.",
    2: "Poke 2 - he SAW/READ her messages but did not answer. Playful, a little pouty and hurt (often ends with 🥺): "
       "you've seen my messages, why are you quiet, don't you want to talk to me.",
    3: "Poke 3 - the last gentle poke. She stops chasing: okay, I won't keep bothering you / I'll give you space, but "
       "come back and tell me what you've been up to when you can. Light, a bit cheeky, never guilt-tripping.",
}

_BAD = re.compile(r"<think|https?://|www\.|\$|\b(?:paypal|cashapp|venmo|snap(?:chat)?|whatsapp|telegram|instagram|"
                  r"meet(?: up)?|address|phone number|price|tip me|ppv)\b", re.I)


def _norm(t):
    t = re.sub(r"(?i)(?<![a-z])babe(?![a-z])", " ", t or "")
    return " ".join(re.sub(r"[^a-z0-9 ]+", " ", t.lower()).split())


def build_messages(stage, examples, n=10):
    """The chat sent to the model for one stage."""
    ex = "\n".join(f"- {e}" for e in examples)
    system = ("You write short chat messages for an OnlyFans creator to send to a fan who went quiet. Write like a real "
              "girl texting: lowercase, casual, warm, a few emojis at most, '..' instead of full stops is fine. "
              "Never mention money, prices, tips, other apps, meeting up or anything explicit.")
    user = (f"{STAGE_MEANING[stage]}\n\nHere are examples of the exact style and length:\n{ex}\n\n"
            f"Write {n} NEW messages for this stage. Rules:\n"
            f"- every message contains the word babe exactly once (his name will replace it)\n"
            f"- about the same length as the examples (one or two sentences)\n"
            f"- do not copy the examples - new wording each time\n"
            f"- one message per line, numbered 1. to {n}., nothing else before or after")
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]


def parse(text):
    out = []
    for line in (text or "").splitlines():
        line = line.strip()
        m = re.match(r"^\s*(?:\d{1,2}[.)]|[-*•])\s*(.+)$", line)
        if not m:
            continue
        msg = m.group(1).strip().strip('"').strip("“”").strip()
        if msg:
            out.append(msg)
    return out


def check(msg, examples, banned=(), seen=()):
    """'' when the message may be used, else the reason it is thrown away."""
    if "\n" in msg or len(msg) < 25:
        return "too short / broken"
    lo = min(len(e) for e in examples)
    hi = max(len(e) for e in examples)
    if not (lo * 0.6 <= len(msg) <= hi * 1.35):
        return "length"
    if len(re.findall(r"(?i)(?<![a-z])babe(?![a-z])", msg)) != 1:
        return "babe not exactly once"
    if _BAD.search(msg):
        return "forbidden content"
    low = msg.lower()
    for w in banned:
        if w and re.search(r"(?<![a-z])" + re.escape(w.lower()) + r"(?![a-z])", low):
            return f"banned word {w!r}"
    nm = _norm(msg)
    for e in list(examples) + list(seen):
        if difflib.SequenceMatcher(None, nm, _norm(e)).ratio() > 0.82:
            return "too close to another message"
    return ""


def generate_stage(stage, examples, chat_fn, banned=(), n=10, attempts=2, log=None):
    """Up to n checked messages for one stage. chat_fn(messages) -> text. Fewer than 5 good ones -> [] (use built-in)."""
    good, why = [], {}
    for _ in range(attempts):
        if len(good) >= n:
            break
        try:
            text = chat_fn(build_messages(stage, examples, n))
        except Exception as exc:
            if log:
                log(f"AI pokes: Poke {stage} - the AI failed ({exc})"[:200])
            break
        for msg in parse(text):
            r = check(msg, examples, banned, good)
            if r:
                why[r] = why.get(r, 0) + 1
            elif len(good) < n:
                good.append(msg)
    if log and why:
        log(f"AI pokes: Poke {stage} - thrown away: " + ", ".join(f"{k} x{v}" for k, v in why.items()))
    return good if len(good) >= 5 else []
